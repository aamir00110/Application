import React, { useState } from 'react';
import { SchoolProvider, useSchool } from './context/SchoolContext';
import { NavigationPage } from './types';
import { ApexHeader } from './components/common/ApexHeader';
import { ApexSidebar } from './components/common/ApexSidebar';

// Views
import { ExecutiveDashboard } from './components/dashboard/ExecutiveDashboard';
import { StudentDirectory } from './components/students/StudentDirectory';
import { StudentAdmissionForm } from './components/students/StudentAdmissionForm';
import { StudentPromotion } from './components/students/StudentPromotion';
import { ParentDirectory } from './components/parents/ParentDirectory';
import { ClassesSectionsMaster } from './components/academics/ClassesSectionsMaster';
import { SubjectCurriculum } from './components/academics/SubjectCurriculum';
import { TimetableMatrix } from './components/academics/TimetableMatrix';
import { HomeworkDiary } from './components/academics/HomeworkDiary';
import { StaffDirectory } from './components/staff/StaffDirectory';
import { StaffLeaveManager } from './components/staff/StaffLeaveManager';
import { DailyAttendanceRegister } from './components/attendance/DailyAttendanceRegister';
import { StaffAttendanceRegister } from './components/attendance/StaffAttendanceRegister';
import { ExamMaster } from './components/exams/ExamMaster';
import { BulkMarksEntry } from './components/exams/BulkMarksEntry';
import { OfficialReportCards } from './components/exams/OfficialReportCards';
import { FeeStructureSetup } from './components/fees/FeeStructureSetup';
import { FeeCollectionHub } from './components/fees/FeeCollectionHub';
import { OutstandingFeeLedger } from './components/fees/OutstandingFeeLedger';
import { PayrollHub } from './components/payroll/PayrollHub';
import { ExpenseManager } from './components/payroll/ExpenseManager';
import { LibraryDesk } from './components/logistics/LibraryDesk';
import { TransportManager } from './components/logistics/TransportManager';
import { InventoryManager } from './components/logistics/InventoryManager';
import { ComplaintsDesk } from './components/logistics/ComplaintsDesk';
import { CertificatesHub } from './components/logistics/CertificatesHub';
import { NoticesEventsHub } from './components/logistics/NoticesEventsHub';
import { UserRoleManager } from './components/admin/UserRoleManager';
import { InstitutionSettings } from './components/admin/InstitutionSettings';
import { AuditLogViewer } from './components/admin/AuditLogViewer';
import { OracleApexScriptsViewer } from './components/admin/OracleApexScriptsViewer';

const SchoolAppContent: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<NavigationPage>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const renderActivePage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <ExecutiveDashboard onNavigate={setCurrentPage} />;
      case 'students-list':
        return <StudentDirectory onNavigate={setCurrentPage} />;
      case 'students-admission':
        return <StudentAdmissionForm onNavigate={setCurrentPage} />;
      case 'students-promotion':
        return <StudentPromotion />;
      case 'parents-list':
        return <ParentDirectory />;
      case 'academics-classes':
        return <ClassesSectionsMaster />;
      case 'academics-subjects':
        return <SubjectCurriculum />;
      case 'academics-timetable':
        return <TimetableMatrix />;
      case 'academics-homework':
        return <HomeworkDiary />;
      case 'staff-list':
        return <StaffDirectory />;
      case 'staff-leaves':
        return <StaffLeaveManager />;
      case 'attendance-student':
        return <DailyAttendanceRegister />;
      case 'attendance-staff':
        return <StaffAttendanceRegister />;
      case 'exams-setup':
        return <ExamMaster />;
      case 'exams-marks':
        return <BulkMarksEntry />;
      case 'exams-report-cards':
        return <OfficialReportCards />;
      case 'fees-structure':
        return <FeeStructureSetup />;
      case 'fees-collection':
        return <FeeCollectionHub />;
      case 'fees-outstanding':
        return <OutstandingFeeLedger />;
      case 'payroll-salary':
        return <PayrollHub />;
      case 'payroll-expenses':
        return <ExpenseManager />;
      case 'logistics-library':
        return <LibraryDesk />;
      case 'logistics-transport':
        return <TransportManager />;
      case 'logistics-inventory':
        return <InventoryManager />;
      case 'logistics-complaints':
        return <ComplaintsDesk />;
      case 'logistics-certificates':
        return <CertificatesHub />;
      case 'logistics-notices':
        return <NoticesEventsHub />;
      case 'admin-users':
        return <UserRoleManager />;
      case 'admin-settings':
        return <InstitutionSettings />;
      case 'admin-audit-logs':
        return <AuditLogViewer />;
      case 'admin-sql-scripts':
        return <OracleApexScriptsViewer />;
      default:
        return <ExecutiveDashboard onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] flex flex-col text-slate-800 font-sans antialiased">
      {/* Oracle APEX Top Banner Header (hidden on print) */}
      <div className="no-print">
        <ApexHeader
          sidebarOpen={!sidebarCollapsed}
          setSidebarOpen={(open) => setSidebarCollapsed(!open)}
          onOpenArchitecture={() => setCurrentPage('admin-sql-scripts')}
        />
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Oracle APEX Universal Theme Sidebar Navigation (hidden on print) */}
        <div className="no-print">
          <ApexSidebar
            currentPage={currentPage as any}
            onNavigate={(page) => setCurrentPage(page as any)}
            isOpen={!sidebarCollapsed}
          />
        </div>

        {/* Dynamic Page Content Region */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-[#F8F9FA]">
          <div className="max-w-7xl mx-auto">
            {renderActivePage()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <SchoolProvider>
      <SchoolAppContent />
    </SchoolProvider>
  );
}
