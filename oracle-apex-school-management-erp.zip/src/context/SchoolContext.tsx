import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  UserRole,
  UserAccount,
  SchoolSettings,
  AcademicSession,
  SchoolClass,
  Section,
  Subject,
  TimetableSlot,
  Parent,
  Student,
  TeacherStaff,
  StudentAttendanceRecord,
  StaffAttendanceRecord,
  LeaveApplication,
  ExamType,
  ExamSchedule,
  StudentExamMark,
  GradingScale,
  FeeCategory,
  ClassFeeStructure,
  StudentFeeInvoice,
  FeePaymentReceipt,
  SalaryPayment,
  ExpenseRecord,
  HomeworkAssignment,
  NoticeAnnouncement,
  SchoolEvent,
  LibraryBook,
  BookIssueReturn,
  TransportVehicle,
  TransportRoute,
  InventoryItem,
  ComplaintRecord,
  StudentCertificate,
  AuditLog
} from '../types';

import {
  INITIAL_SETTINGS,
  INITIAL_SESSIONS,
  INITIAL_CLASSES,
  INITIAL_SECTIONS,
  INITIAL_SUBJECTS,
  INITIAL_TEACHERS_STAFF,
  INITIAL_PARENTS,
  INITIAL_STUDENTS,
  INITIAL_TIMETABLE,
  INITIAL_ATTENDANCE,
  INITIAL_STAFF_ATTENDANCE,
  INITIAL_LEAVE_APPLICATIONS,
  INITIAL_EXAM_TYPES,
  INITIAL_EXAM_SCHEDULES,
  INITIAL_GRADING_SCALES,
  INITIAL_STUDENT_MARKS,
  INITIAL_FEE_CATEGORIES,
  INITIAL_CLASS_FEE_STRUCTURE,
  INITIAL_STUDENT_INVOICES,
  INITIAL_FEE_RECEIPTS,
  INITIAL_SALARY_PAYMENTS,
  INITIAL_EXPENSES,
  INITIAL_HOMEWORK,
  INITIAL_NOTICES,
  INITIAL_EVENTS,
  INITIAL_BOOKS,
  INITIAL_BOOK_ISSUES,
  INITIAL_TRANSPORT_VEHICLES,
  INITIAL_TRANSPORT_ROUTES,
  INITIAL_INVENTORY,
  INITIAL_COMPLAINTS,
  INITIAL_CERTIFICATES,
  INITIAL_AUDIT_LOGS,
  INITIAL_USERS
} from '../data/initialData';

interface SchoolContextType {
  // Current user & authentication
  currentUser: UserAccount;
  switchUserRole: (role: UserRole) => void;
  users: UserAccount[];
  
  // Settings & Sessions
  settings: SchoolSettings;
  updateSettings: (newSettings: Partial<SchoolSettings>) => void;
  academicSessions: AcademicSession[];
  
  // Academics
  classes: SchoolClass[];
  sections: Section[];
  subjects: Subject[];
  timetable: TimetableSlot[];
  addClass: (cls: Omit<SchoolClass, 'id'>) => void;
  addSection: (sec: Omit<Section, 'id'>) => void;
  addSubject: (sub: Omit<Subject, 'id'>) => void;
  deleteSubject: (id: string) => void;
  saveTimetableSlot: (slot: TimetableSlot) => void;
  
  // Students & Parents
  students: Student[];
  parents: Parent[];
  addStudent: (studentData: Omit<Student, 'id' | 'admissionNo' | 'createdDate'>, parentData?: Omit<Parent, 'id'>) => Student;
  updateStudent: (id: string, updated: Partial<Student>) => void;
  deleteStudent: (id: string) => void;
  promoteStudents: (studentIds: string[], targetClassId: string, targetSectionId: string) => void;
  addParent: (parent: Omit<Parent, 'id'>) => Parent;
  
  // Staff & HR
  staff: TeacherStaff[];
  addStaff: (staff: Omit<TeacherStaff, 'id' | 'employeeCode'>) => TeacherStaff;
  updateStaff: (id: string, updated: Partial<TeacherStaff>) => void;
  deleteStaff: (id: string) => void;
  leaveApplications: LeaveApplication[];
  applyLeave: (leave: Omit<LeaveApplication, 'id' | 'appliedDate' | 'status'>) => void;
  reviewLeave: (id: string, status: 'APPROVED' | 'REJECTED', reviewRemarks?: string) => void;

  // Attendance
  studentAttendance: StudentAttendanceRecord[];
  staffAttendance: StaffAttendanceRecord[];
  markBulkStudentAttendance: (records: Omit<StudentAttendanceRecord, 'id'>[]) => void;
  markStaffAttendance: (records: Omit<StaffAttendanceRecord, 'id'>[]) => void;
  getStudentAttendancePercentage: (studentId: string) => number;

  // Examinations & Grading
  examTypes: ExamType[];
  examSchedules: ExamSchedule[];
  studentMarks: StudentExamMark[];
  gradingScales: GradingScale[];
  addExamType: (exam: Omit<ExamType, 'id'>) => void;
  saveStudentMarks: (marks: Omit<StudentExamMark, 'id'>[]) => void;
  calculateGradeAndGpa: (marksObtained: number, maxMarks: number) => { grade: string; gpa: number };

  // Financial Accounting
  feeCategories: FeeCategory[];
  classFeeStructures: ClassFeeStructure[];
  invoices: StudentFeeInvoice[];
  receipts: FeePaymentReceipt[];
  salaryPayments: SalaryPayment[];
  expenses: ExpenseRecord[];
  createInvoice: (invoiceData: Omit<StudentFeeInvoice, 'id' | 'invoiceNo' | 'issueDate' | 'paidAmount' | 'balanceAmount' | 'status'>) => StudentFeeInvoice;
  recordFeePayment: (invoiceId: string, amount: number, method: FeePaymentReceipt['paymentMethod'], refNo?: string, remarks?: string) => FeePaymentReceipt;
  createSalaryPayment: (salary: Omit<SalaryPayment, 'id' | 'voucherNo' | 'paymentDate' | 'status'>) => SalaryPayment;
  addExpense: (expense: Omit<ExpenseRecord, 'id' | 'voucherNo' | 'expenseDate'>) => ExpenseRecord;
  deleteExpense: (id: string) => void;

  // Ancillary Modules
  homework: HomeworkAssignment[];
  addHomework: (hw: Omit<HomeworkAssignment, 'id' | 'assignedDate'>) => void;
  notices: NoticeAnnouncement[];
  addNotice: (notice: Omit<NoticeAnnouncement, 'id' | 'publishDate'>) => void;
  events: SchoolEvent[];
  addEvent: (evt: Omit<SchoolEvent, 'id'>) => void;
  books: LibraryBook[];
  bookIssues: BookIssueReturn[];
  addBook: (book: Omit<LibraryBook, 'id'>) => void;
  issueBook: (bookId: string, borrowerType: 'STUDENT' | 'TEACHER', borrowerId: string, dueDate: string) => void;
  returnBook: (issueId: string) => void;
  transportVehicles: TransportVehicle[];
  transportRoutes: TransportRoute[];
  addTransportRoute: (route: Omit<TransportRoute, 'id'>) => void;
  inventory: InventoryItem[];
  addInventoryItem: (item: Omit<InventoryItem, 'id'>) => void;
  complaints: ComplaintRecord[];
  addComplaint: (complaint: Omit<ComplaintRecord, 'id' | 'submittedDate' | 'status'>) => void;
  resolveComplaint: (id: string, resolutionRemarks: string) => void;
  certificates: StudentCertificate[];
  issueCertificate: (cert: Omit<StudentCertificate, 'id' | 'certificateNo' | 'issueDate'>) => StudentCertificate;

  // System & Logs
  auditLogs: AuditLog[];
  logAuditAction: (action: AuditLog['action'], module: string, description: string) => void;
  resetToDefaultData: () => void;
}

const SchoolContext = createContext<SchoolContextType | null>(null);

const STORAGE_KEY = 'APEX_EDU_ERP_STATE_V1';

export const SchoolProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load state from localStorage or fallback to initial data
  const loadInitial = <T,>(key: string, fallback: T): T => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY}_${key}`);
      if (stored) return JSON.parse(stored);
    } catch (e) {
      console.error(`Failed to load ${key} from storage`, e);
    }
    return fallback;
  };

  const [users] = useState<UserAccount[]>(INITIAL_USERS);
  const [currentUser, setCurrentUser] = useState<UserAccount>(() => {
    return loadInitial('currentUser', INITIAL_USERS[0]);
  });

  const [settings, setSettings] = useState<SchoolSettings>(() => loadInitial('settings', INITIAL_SETTINGS));
  const [academicSessions] = useState<AcademicSession[]>(() => loadInitial('sessions', INITIAL_SESSIONS));
  const [classes, setClasses] = useState<SchoolClass[]>(() => loadInitial('classes', INITIAL_CLASSES));
  const [sections, setSections] = useState<Section[]>(() => loadInitial('sections', INITIAL_SECTIONS));
  const [subjects, setSubjects] = useState<Subject[]>(() => loadInitial('subjects', INITIAL_SUBJECTS));
  const [timetable, setTimetable] = useState<TimetableSlot[]>(() => loadInitial('timetable', INITIAL_TIMETABLE));
  const [parents, setParents] = useState<Parent[]>(() => loadInitial('parents', INITIAL_PARENTS));
  const [students, setStudents] = useState<Student[]>(() => loadInitial('students', INITIAL_STUDENTS));
  const [staff, setStaff] = useState<TeacherStaff[]>(() => loadInitial('staff', INITIAL_TEACHERS_STAFF));
  const [leaveApplications, setLeaveApplications] = useState<LeaveApplication[]>(() => loadInitial('leaves', INITIAL_LEAVE_APPLICATIONS));
  const [studentAttendance, setStudentAttendance] = useState<StudentAttendanceRecord[]>(() => loadInitial('studentAttendance', INITIAL_ATTENDANCE));
  const [staffAttendance, setStaffAttendance] = useState<StaffAttendanceRecord[]>(() => loadInitial('staffAttendance', INITIAL_STAFF_ATTENDANCE));
  const [examTypes, setExamTypes] = useState<ExamType[]>(() => loadInitial('examTypes', INITIAL_EXAM_TYPES));
  const [examSchedules] = useState<ExamSchedule[]>(() => loadInitial('examSchedules', INITIAL_EXAM_SCHEDULES));
  const [gradingScales] = useState<GradingScale[]>(() => loadInitial('gradingScales', INITIAL_GRADING_SCALES));
  const [studentMarks, setStudentMarks] = useState<StudentExamMark[]>(() => loadInitial('studentMarks', INITIAL_STUDENT_MARKS));
  const [feeCategories] = useState<FeeCategory[]>(() => loadInitial('feeCategories', INITIAL_FEE_CATEGORIES));
  const [classFeeStructures] = useState<ClassFeeStructure[]>(() => loadInitial('classFeeStructures', INITIAL_CLASS_FEE_STRUCTURE));
  const [invoices, setInvoices] = useState<StudentFeeInvoice[]>(() => loadInitial('invoices', INITIAL_STUDENT_INVOICES));
  const [receipts, setReceipts] = useState<FeePaymentReceipt[]>(() => loadInitial('receipts', INITIAL_FEE_RECEIPTS));
  const [salaryPayments, setSalaryPayments] = useState<SalaryPayment[]>(() => loadInitial('salaryPayments', INITIAL_SALARY_PAYMENTS));
  const [expenses, setExpenses] = useState<ExpenseRecord[]>(() => loadInitial('expenses', INITIAL_EXPENSES));
  const [homework, setHomework] = useState<HomeworkAssignment[]>(() => loadInitial('homework', INITIAL_HOMEWORK));
  const [notices, setNotices] = useState<NoticeAnnouncement[]>(() => loadInitial('notices', INITIAL_NOTICES));
  const [events, setEvents] = useState<SchoolEvent[]>(() => loadInitial('events', INITIAL_EVENTS));
  const [books, setBooks] = useState<LibraryBook[]>(() => loadInitial('books', INITIAL_BOOKS));
  const [bookIssues, setBookIssues] = useState<BookIssueReturn[]>(() => loadInitial('bookIssues', INITIAL_BOOK_ISSUES));
  const [transportVehicles] = useState<TransportVehicle[]>(() => loadInitial('transportVehicles', INITIAL_TRANSPORT_VEHICLES));
  const [transportRoutes, setTransportRoutes] = useState<TransportRoute[]>(() => loadInitial('transportRoutes', INITIAL_TRANSPORT_ROUTES));
  const [inventory, setInventory] = useState<InventoryItem[]>(() => loadInitial('inventory', INITIAL_INVENTORY));
  const [complaints, setComplaints] = useState<ComplaintRecord[]>(() => loadInitial('complaints', INITIAL_COMPLAINTS));
  const [certificates, setCertificates] = useState<StudentCertificate[]>(() => loadInitial('certificates', INITIAL_CERTIFICATES));
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => loadInitial('auditLogs', INITIAL_AUDIT_LOGS));

  // Sync state changes to localStorage
  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_currentUser`, JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_settings`, JSON.stringify(settings));
    localStorage.setItem(`${STORAGE_KEY}_students`, JSON.stringify(students));
    localStorage.setItem(`${STORAGE_KEY}_parents`, JSON.stringify(parents));
    localStorage.setItem(`${STORAGE_KEY}_staff`, JSON.stringify(staff));
    localStorage.setItem(`${STORAGE_KEY}_studentAttendance`, JSON.stringify(studentAttendance));
    localStorage.setItem(`${STORAGE_KEY}_studentMarks`, JSON.stringify(studentMarks));
    localStorage.setItem(`${STORAGE_KEY}_invoices`, JSON.stringify(invoices));
    localStorage.setItem(`${STORAGE_KEY}_receipts`, JSON.stringify(receipts));
    localStorage.setItem(`${STORAGE_KEY}_salaryPayments`, JSON.stringify(salaryPayments));
    localStorage.setItem(`${STORAGE_KEY}_expenses`, JSON.stringify(expenses));
    localStorage.setItem(`${STORAGE_KEY}_homework`, JSON.stringify(homework));
    localStorage.setItem(`${STORAGE_KEY}_notices`, JSON.stringify(notices));
    localStorage.setItem(`${STORAGE_KEY}_complaints`, JSON.stringify(complaints));
    localStorage.setItem(`${STORAGE_KEY}_certificates`, JSON.stringify(certificates));
    localStorage.setItem(`${STORAGE_KEY}_auditLogs`, JSON.stringify(auditLogs));
    localStorage.setItem(`${STORAGE_KEY}_classes`, JSON.stringify(classes));
    localStorage.setItem(`${STORAGE_KEY}_sections`, JSON.stringify(sections));
    localStorage.setItem(`${STORAGE_KEY}_subjects`, JSON.stringify(subjects));
    localStorage.setItem(`${STORAGE_KEY}_timetable`, JSON.stringify(timetable));
    localStorage.setItem(`${STORAGE_KEY}_leaves`, JSON.stringify(leaveApplications));
    localStorage.setItem(`${STORAGE_KEY}_examTypes`, JSON.stringify(examTypes));
    localStorage.setItem(`${STORAGE_KEY}_books`, JSON.stringify(books));
    localStorage.setItem(`${STORAGE_KEY}_bookIssues`, JSON.stringify(bookIssues));
    localStorage.setItem(`${STORAGE_KEY}_transportRoutes`, JSON.stringify(transportRoutes));
    localStorage.setItem(`${STORAGE_KEY}_inventory`, JSON.stringify(inventory));
  }, [
    settings, students, parents, staff, studentAttendance, studentMarks, invoices,
    receipts, salaryPayments, expenses, homework, notices, complaints, certificates,
    auditLogs, classes, sections, subjects, timetable, leaveApplications, examTypes,
    books, bookIssues, transportRoutes, inventory
  ]);

  const logAuditAction = (action: AuditLog['action'], module: string, description: string) => {
    const newLog: AuditLog = {
      id: `LOG-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      userName: currentUser.fullName,
      userRole: currentUser.role,
      action,
      module,
      description,
      ipAddress: '127.0.0.1 (Session Client)'
    };
    setAuditLogs(prev => [newLog, ...prev]);
  };

  const switchUserRole = (role: UserRole) => {
    const targetUser = users.find(u => u.role === role) || {
      id: `USR-TMP-${role}`,
      username: role.toLowerCase(),
      fullName: `${role.replace('_', ' ')} (Active User)`,
      email: `${role.toLowerCase()}@apexacademy.edu`,
      role,
      isActive: true,
      createdDate: '2026-01-01'
    };
    setCurrentUser(targetUser);
    logAuditAction('LOGIN', 'AUTH_SWITCH', `Switched active profile session to ${role}`);
  };

  const updateSettings = (newSettings: Partial<SchoolSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
    logAuditAction('UPDATE', 'SETTINGS', 'Updated institutional system configurations');
  };

  const addClass = (cls: Omit<SchoolClass, 'id'>) => {
    const newCls: SchoolClass = { ...cls, id: `CLS-${Date.now().toString().slice(-4)}` };
    setClasses(prev => [...prev, newCls]);
    logAuditAction('CREATE', 'ACADEMICS_CLASS', `Created academic class: ${newCls.name}`);
  };

  const addSection = (sec: Omit<Section, 'id'>) => {
    const newSec: Section = { ...sec, id: `SEC-${Date.now().toString().slice(-4)}` };
    setSections(prev => [...prev, newSec]);
    logAuditAction('CREATE', 'ACADEMICS_SECTION', `Created section: ${newSec.name}`);
  };

  const addSubject = (sub: Omit<Subject, 'id'>) => {
    const newSub: Subject = { ...sub, id: `SUB-${Date.now().toString().slice(-4)}` };
    setSubjects(prev => [...prev, newSub]);
    logAuditAction('CREATE', 'ACADEMICS_SUBJECT', `Created subject: ${newSub.name} (${newSub.code})`);
  };

  const deleteSubject = (id: string) => {
    setSubjects(prev => prev.filter(s => s.id !== id));
    logAuditAction('DELETE', 'ACADEMICS_SUBJECT', `Deleted subject id: ${id}`);
  };

  const saveTimetableSlot = (slot: TimetableSlot) => {
    setTimetable(prev => {
      const idx = prev.findIndex(t => t.id === slot.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = slot;
        return copy;
      }
      return [...prev, slot];
    });
    logAuditAction('UPDATE', 'TIMETABLE', `Saved timetable slot ${slot.dayOfWeek} Period ${slot.periodNumber}`);
  };

  const addParent = (parentData: Omit<Parent, 'id'>): Parent => {
    const newParent: Parent = {
      ...parentData,
      id: `PAR-${(parents.length + 1).toString().padStart(2, '0')}`
    };
    setParents(prev => [...prev, newParent]);
    logAuditAction('CREATE', 'PARENTS', `Registered parent guardian: ${newParent.fatherName}`);
    return newParent;
  };

  const addStudent = (studentData: Omit<Student, 'id' | 'admissionNo' | 'createdDate'>, parentData?: Omit<Parent, 'id'>): Student => {
    let parentId = studentData.parentId;
    if (parentData && !parentId) {
      const createdParent = addParent(parentData);
      parentId = createdParent.id;
    }

    const nextIdNum = students.length + 1;
    const admissionNo = `${settings.admissionPrefix}${nextIdNum.toString().padStart(4, '0')}`;
    const newStudent: Student = {
      ...studentData,
      id: `STU-${nextIdNum.toString().padStart(2, '0')}`,
      admissionNo,
      parentId: parentId || 'PAR-01',
      fullName: `${studentData.firstName} ${studentData.lastName}`,
      createdDate: new Date().toISOString().split('T')[0]
    };

    setStudents(prev => [newStudent, ...prev]);

    // Auto generate August Fee Invoice for the student
    const classFee = classFeeStructures.find(c => c.classId === newStudent.classId);
    const tuitionAmount = classFee?.amount || 400;
    const newInvoice: StudentFeeInvoice = {
      id: `INV-2026-${nextIdNum.toString().padStart(4, '0')}`,
      invoiceNo: `INV-2026-${nextIdNum.toString().padStart(4, '0')}`,
      studentId: newStudent.id,
      classId: newStudent.classId,
      academicSessionId: newStudent.academicSessionId || 'SES-2026',
      monthOrTerm: 'August 2026',
      issueDate: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 10 * 86400000).toISOString().split('T')[0],
      totalAmount: tuitionAmount + 100, // tuition + admission
      discountAmount: 0,
      fineAmount: 0,
      netPayable: tuitionAmount + 100,
      paidAmount: 0,
      balanceAmount: tuitionAmount + 100,
      status: 'UNPAID',
      items: [
        { feeCategoryId: 'FC-01', categoryName: 'Monthly Tuition Fee', amount: tuitionAmount },
        { feeCategoryId: 'FC-04', categoryName: 'Admission Registration Fee', amount: 100 }
      ]
    };
    setInvoices(prev => [newInvoice, ...prev]);

    logAuditAction('CREATE', 'STUDENT_ADMISSION', `Admitted new student: ${newStudent.fullName} (${newStudent.admissionNo})`);
    return newStudent;
  };

  const updateStudent = (id: string, updated: Partial<Student>) => {
    setStudents(prev => prev.map(s => {
      if (s.id === id) {
        const merged = { ...s, ...updated };
        if (updated.firstName || updated.lastName) {
          merged.fullName = `${merged.firstName} ${merged.lastName}`;
        }
        return merged;
      }
      return s;
    }));
    logAuditAction('UPDATE', 'STUDENT_MGMT', `Updated student record ID: ${id}`);
  };

  const deleteStudent = (id: string) => {
    const student = students.find(s => s.id === id);
    setStudents(prev => prev.filter(s => s.id !== id));
    logAuditAction('DELETE', 'STUDENT_MGMT', `Removed student ${student?.fullName || id}`);
  };

  const promoteStudents = (studentIds: string[], targetClassId: string, targetSectionId: string) => {
    const targetClass = classes.find(c => c.id === targetClassId);
    const targetSection = sections.find(s => s.id === targetSectionId);
    setStudents(prev => prev.map(s => {
      if (studentIds.includes(s.id)) {
        return {
          ...s,
          classId: targetClassId,
          sectionId: targetSectionId,
          rollNo: `${targetSection?.name || 'A'}-${s.rollNo.split('-')[1] || '01'}`
        };
      }
      return s;
    }));
    logAuditAction('UPDATE', 'STUDENT_PROMOTION', `Promoted ${studentIds.length} student(s) to ${targetClass?.name} (${targetSection?.name})`);
  };

  const addStaff = (staffData: Omit<TeacherStaff, 'id' | 'employeeCode'>): TeacherStaff => {
    const nextIdNum = staff.length + 1;
    const newStaff: TeacherStaff = {
      ...staffData,
      id: `STF-${nextIdNum.toString().padStart(2, '0')}`,
      employeeCode: `EMP-${1000 + nextIdNum}`,
      fullName: `${staffData.firstName} ${staffData.lastName}`
    };
    setStaff(prev => [...prev, newStaff]);
    logAuditAction('CREATE', 'STAFF_HR', `Appointed faculty/staff: ${newStaff.fullName} (${newStaff.designation})`);
    return newStaff;
  };

  const updateStaff = (id: string, updated: Partial<TeacherStaff>) => {
    setStaff(prev => prev.map(s => {
      if (s.id === id) {
        const merged = { ...s, ...updated };
        if (updated.firstName || updated.lastName) {
          merged.fullName = `${merged.firstName} ${merged.lastName}`;
        }
        return merged;
      }
      return s;
    }));
    logAuditAction('UPDATE', 'STAFF_HR', `Updated staff record ID: ${id}`);
  };

  const deleteStaff = (id: string) => {
    setStaff(prev => prev.filter(s => s.id !== id));
    logAuditAction('DELETE', 'STAFF_HR', `Removed staff member ID: ${id}`);
  };

  const applyLeave = (leave: Omit<LeaveApplication, 'id' | 'appliedDate' | 'status'>) => {
    const newLeave: LeaveApplication = {
      ...leave,
      id: `LEV-${Date.now().toString().slice(-4)}`,
      appliedDate: new Date().toISOString().split('T')[0],
      status: 'PENDING'
    };
    setLeaveApplications(prev => [newLeave, ...prev]);
    logAuditAction('CREATE', 'LEAVE_MGMT', `Submitted leave request for ${leave.applicantType} (${leave.leaveType})`);
  };

  const reviewLeave = (id: string, status: 'APPROVED' | 'REJECTED', reviewRemarks?: string) => {
    setLeaveApplications(prev => prev.map(l => {
      if (l.id === id) {
        return {
          ...l,
          status,
          reviewedBy: currentUser.fullName,
          reviewRemarks
        };
      }
      return l;
    }));
    logAuditAction('UPDATE', 'LEAVE_MGMT', `${status} leave application ID: ${id}`);
  };

  const markBulkStudentAttendance = (records: Omit<StudentAttendanceRecord, 'id'>[]) => {
    const today = records[0]?.date || new Date().toISOString().split('T')[0];
    const targetStudentIds = records.map(r => r.studentId);

    setStudentAttendance(prev => {
      // Remove any existing records for these students on that date
      const filtered = prev.filter(r => !(r.date === today && targetStudentIds.includes(r.studentId)));
      const newItems: StudentAttendanceRecord[] = records.map((r, i) => ({
        ...r,
        id: `ATT-${Date.now()}-${i}`
      }));
      return [...newItems, ...filtered];
    });

    logAuditAction('CREATE', 'ATTENDANCE_BULK', `Logged attendance register for ${records.length} students on ${today}`);
  };

  const markStaffAttendance = (records: Omit<StaffAttendanceRecord, 'id'>[]) => {
    const today = records[0]?.date || new Date().toISOString().split('T')[0];
    const targetStaffIds = records.map(r => r.staffId);

    setStaffAttendance(prev => {
      const filtered = prev.filter(r => !(r.date === today && targetStaffIds.includes(r.staffId)));
      const newItems: StaffAttendanceRecord[] = records.map((r, i) => ({
        ...r,
        id: `SATT-${Date.now()}-${i}`
      }));
      return [...newItems, ...filtered];
    });

    logAuditAction('CREATE', 'STAFF_ATTENDANCE', `Recorded staff attendance on ${today}`);
  };

  const getStudentAttendancePercentage = (studentId: string): number => {
    const records = studentAttendance.filter(r => r.studentId === studentId);
    if (records.length === 0) return 100;
    const presentCount = records.filter(r => r.status === 'PRESENT' || r.status === 'LATE' || r.status === 'HALF_DAY').length;
    return Math.round((presentCount / records.length) * 100);
  };

  const addExamType = (exam: Omit<ExamType, 'id'>) => {
    const newExam: ExamType = {
      ...exam,
      id: `EXM-${(examTypes.length + 1).toString().padStart(2, '0')}`
    };
    setExamTypes(prev => [...prev, newExam]);
    logAuditAction('CREATE', 'EXAM_MASTER', `Created examination session: ${newExam.name}`);
  };

  const calculateGradeAndGpa = (marksObtained: number, maxMarks: number): { grade: string; gpa: number } => {
    if (maxMarks <= 0) return { grade: 'F', gpa: 0 };
    const pct = (marksObtained / maxMarks) * 100;
    if (pct >= 90) return { grade: 'A+', gpa: 4.0 };
    if (pct >= 80) return { grade: 'A', gpa: 3.7 };
    if (pct >= 70) return { grade: 'B', gpa: 3.0 };
    if (pct >= 60) return { grade: 'C', gpa: 2.0 };
    if (pct >= 40) return { grade: 'D', gpa: 1.0 };
    return { grade: 'F', gpa: 0.0 };
  };

  const saveStudentMarks = (marks: Omit<StudentExamMark, 'id'>[]) => {
    setStudentMarks(prev => {
      const keys = marks.map(m => `${m.examTypeId}_${m.studentId}_${m.subjectId}`);
      const filtered = prev.filter(p => !keys.includes(`${p.examTypeId}_${p.studentId}_${p.subjectId}`));
      const newItems: StudentExamMark[] = marks.map((m, i) => {
        const { grade, gpa } = calculateGradeAndGpa(m.marksObtained, m.maxMarks);
        return {
          ...m,
          id: `MRK-${Date.now()}-${i}`,
          grade: m.isAbsent ? 'ABS' : grade,
          gpa: m.isAbsent ? 0 : gpa
        };
      });
      return [...filtered, ...newItems];
    });

    logAuditAction('MARKS_ENTERED', 'EXAM_MARKS', `Submitted marks entry for ${marks.length} student subject records`);
  };

  const createInvoice = (invoiceData: Omit<StudentFeeInvoice, 'id' | 'invoiceNo' | 'issueDate' | 'paidAmount' | 'balanceAmount' | 'status'>): StudentFeeInvoice => {
    const nextId = invoices.length + 1;
    const invoiceNo = `INV-2026-${nextId.toString().padStart(4, '0')}`;
    const newInvoice: StudentFeeInvoice = {
      ...invoiceData,
      id: invoiceNo,
      invoiceNo,
      issueDate: new Date().toISOString().split('T')[0],
      paidAmount: 0,
      balanceAmount: invoiceData.netPayable,
      status: 'UNPAID'
    };
    setInvoices(prev => [newInvoice, ...prev]);
    logAuditAction('CREATE', 'FEE_INVOICE', `Generated fee challan ${invoiceNo} for student ${invoiceData.studentId}`);
    return newInvoice;
  };

  const recordFeePayment = (
    invoiceId: string,
    amount: number,
    method: FeePaymentReceipt['paymentMethod'],
    refNo?: string,
    remarks?: string
  ): FeePaymentReceipt => {
    const invoice = invoices.find(i => i.id === invoiceId);
    if (!invoice) throw new Error("Invoice not found");

    const nextReceiptNum = receipts.length + 1;
    const receiptNo = `${settings.receiptPrefix}${nextReceiptNum.toString().padStart(4, '0')}`;

    const newReceipt: FeePaymentReceipt = {
      id: `REC-${nextReceiptNum.toString().padStart(2, '0')}`,
      receiptNo,
      invoiceId,
      studentId: invoice.studentId,
      paymentDate: new Date().toISOString().split('T')[0],
      amountPaid: amount,
      paymentMethod: method,
      referenceNo: refNo || `TX-${Date.now().toString().slice(-6)}`,
      collectedBy: currentUser.fullName,
      remarks: remarks || `Fee payment towards ${invoice.monthOrTerm}`
    };

    setReceipts(prev => [newReceipt, ...prev]);

    // Update invoice paid & balance amount
    const newPaid = invoice.paidAmount + amount;
    const newBalance = Math.max(0, invoice.netPayable - newPaid);
    const newStatus = newBalance === 0 ? 'PAID' : 'PARTIALLY_PAID';

    setInvoices(prev => prev.map(inv => {
      if (inv.id === invoiceId) {
        return {
          ...inv,
          paidAmount: newPaid,
          balanceAmount: newBalance,
          status: newStatus
        };
      }
      return inv;
    }));

    logAuditAction('PAYMENT_PROCESSED', 'FEE_COLLECTION', `Collected ${settings.currencySymbol}${amount} (Receipt: ${receiptNo})`);
    return newReceipt;
  };

  const createSalaryPayment = (salary: Omit<SalaryPayment, 'id' | 'voucherNo' | 'paymentDate' | 'status'>): SalaryPayment => {
    const nextNum = salaryPayments.length + 1;
    const voucherNo = `SAL-2026-${nextNum.toString().padStart(4, '0')}`;
    const newSalary: SalaryPayment = {
      ...salary,
      id: `SAL-${nextNum.toString().padStart(2, '0')}`,
      voucherNo,
      paymentDate: new Date().toISOString().split('T')[0],
      status: 'PAID'
    };
    setSalaryPayments(prev => [newSalary, ...prev]);
    logAuditAction('PAYMENT_PROCESSED', 'PAYROLL', `Disbursed monthly salary ${settings.currencySymbol}${salary.netSalary} (Voucher: ${voucherNo})`);
    return newSalary;
  };

  const addExpense = (expense: Omit<ExpenseRecord, 'id' | 'voucherNo' | 'expenseDate'>): ExpenseRecord => {
    const nextNum = expenses.length + 1;
    const voucherNo = `EXP-2026-${nextNum.toString().padStart(3, '0')}`;
    const newExpense: ExpenseRecord = {
      ...expense,
      id: `EXP-${nextNum.toString().padStart(2, '0')}`,
      voucherNo,
      expenseDate: new Date().toISOString().split('T')[0]
    };
    setExpenses(prev => [newExpense, ...prev]);
    logAuditAction('CREATE', 'EXPENSES', `Logged expenditure ${settings.currencySymbol}${expense.amount} for ${expense.title}`);
    return newExpense;
  };

  const deleteExpense = (id: string) => {
    setExpenses(prev => prev.filter(e => e.id !== id));
    logAuditAction('DELETE', 'EXPENSES', `Deleted expense voucher ID: ${id}`);
  };

  const addHomework = (hw: Omit<HomeworkAssignment, 'id' | 'assignedDate'>) => {
    const newHw: HomeworkAssignment = {
      ...hw,
      id: `HW-${Date.now().toString().slice(-4)}`,
      assignedDate: new Date().toISOString().split('T')[0]
    };
    setHomework(prev => [newHw, ...prev]);
    logAuditAction('CREATE', 'HOMEWORK', `Assigned homework: ${newHw.title}`);
  };

  const addNotice = (notice: Omit<NoticeAnnouncement, 'id' | 'publishDate'>) => {
    const newNotice: NoticeAnnouncement = {
      ...notice,
      id: `NOT-${Date.now().toString().slice(-4)}`,
      publishDate: new Date().toISOString().split('T')[0]
    };
    setNotices(prev => [newNotice, ...prev]);
    logAuditAction('CREATE', 'NOTICE_BOARD', `Published circular: ${newNotice.title}`);
  };

  const addEvent = (evt: Omit<SchoolEvent, 'id'>) => {
    const newEvt: SchoolEvent = {
      ...evt,
      id: `EVT-${Date.now().toString().slice(-4)}`
    };
    setEvents(prev => [...prev, newEvt]);
    logAuditAction('CREATE', 'EVENTS', `Created calendar event: ${newEvt.title}`);
  };

  const addBook = (book: Omit<LibraryBook, 'id'>) => {
    const newBook: LibraryBook = {
      ...book,
      id: `BK-${(books.length + 1).toString().padStart(2, '0')}`
    };
    setBooks(prev => [...prev, newBook]);
    logAuditAction('CREATE', 'LIBRARY', `Catalogued book: ${newBook.title} (${newBook.isbn})`);
  };

  const issueBook = (bookId: string, borrowerType: 'STUDENT' | 'TEACHER', borrowerId: string, dueDate: string) => {
    const newIssue: BookIssueReturn = {
      id: `ISS-${Date.now().toString().slice(-4)}`,
      bookId,
      borrowerType,
      borrowerId,
      issueDate: new Date().toISOString().split('T')[0],
      dueDate,
      fineAmount: 0,
      status: 'ISSUED'
    };
    setBookIssues(prev => [newIssue, ...prev]);
    setBooks(prev => prev.map(b => b.id === bookId ? { ...b, availableCopies: Math.max(0, b.availableCopies - 1) } : b));
    logAuditAction('CREATE', 'LIBRARY_ISSUE', `Issued book ${bookId} to ${borrowerType} ${borrowerId}`);
  };

  const returnBook = (issueId: string) => {
    const issue = bookIssues.find(i => i.id === issueId);
    if (!issue) return;
    setBookIssues(prev => prev.map(i => i.id === issueId ? { ...i, returnDate: new Date().toISOString().split('T')[0], status: 'RETURNED' } : i));
    setBooks(prev => prev.map(b => b.id === issue.bookId ? { ...b, availableCopies: b.availableCopies + 1 } : b));
    logAuditAction('UPDATE', 'LIBRARY_RETURN', `Processed book return for issue ID: ${issueId}`);
  };

  const addTransportRoute = (route: Omit<TransportRoute, 'id'>) => {
    const newRoute: TransportRoute = {
      ...route,
      id: `RT-${(transportRoutes.length + 1).toString().padStart(2, '0')}`
    };
    setTransportRoutes(prev => [...prev, newRoute]);
    logAuditAction('CREATE', 'TRANSPORT', `Added bus route: ${newRoute.routeName}`);
  };

  const addInventoryItem = (item: Omit<InventoryItem, 'id'>) => {
    const newItem: InventoryItem = {
      ...item,
      id: `INV-${(inventory.length + 1).toString().padStart(2, '0')}`
    };
    setInventory(prev => [...prev, newItem]);
    logAuditAction('CREATE', 'INVENTORY', `Added asset item: ${newItem.itemName}`);
  };

  const addComplaint = (complaint: Omit<ComplaintRecord, 'id' | 'submittedDate' | 'status'>) => {
    const newComplaint: ComplaintRecord = {
      ...complaint,
      id: `CMP-${Date.now().toString().slice(-4)}`,
      submittedDate: new Date().toISOString().split('T')[0],
      status: 'PENDING'
    };
    setComplaints(prev => [newComplaint, ...prev]);
    logAuditAction('CREATE', 'GRIEVANCES', `Lodged grievance: ${newComplaint.title}`);
  };

  const resolveComplaint = (id: string, resolutionRemarks: string) => {
    setComplaints(prev => prev.map(c => {
      if (c.id === id) {
        return {
          ...c,
          status: 'RESOLVED',
          resolutionRemarks,
          resolvedDate: new Date().toISOString().split('T')[0]
        };
      }
      return c;
    }));
    logAuditAction('UPDATE', 'GRIEVANCES', `Resolved complaint ID: ${id}`);
  };

  const issueCertificate = (cert: Omit<StudentCertificate, 'id' | 'certificateNo' | 'issueDate'>): StudentCertificate => {
    const nextNum = certificates.length + 1;
    const certificateNo = `CERT-2026-${nextNum.toString().padStart(4, '0')}`;
    const newCert: StudentCertificate = {
      ...cert,
      id: `CERT-${nextNum.toString().padStart(2, '0')}`,
      certificateNo,
      issueDate: new Date().toISOString().split('T')[0]
    };
    setCertificates(prev => [newCert, ...prev]);
    logAuditAction('CREATE', 'CERTIFICATES', `Issued ${cert.type} certificate (${certificateNo})`);
    return newCert;
  };

  const resetToDefaultData = () => {
    localStorage.clear();
    setSettings(INITIAL_SETTINGS);
    setClasses(INITIAL_CLASSES);
    setSections(INITIAL_SECTIONS);
    setSubjects(INITIAL_SUBJECTS);
    setTimetable(INITIAL_TIMETABLE);
    setParents(INITIAL_PARENTS);
    setStudents(INITIAL_STUDENTS);
    setStaff(INITIAL_TEACHERS_STAFF);
    setStudentAttendance(INITIAL_ATTENDANCE);
    setStaffAttendance(INITIAL_STAFF_ATTENDANCE);
    setLeaveApplications(INITIAL_LEAVE_APPLICATIONS);
    setExamTypes(INITIAL_EXAM_TYPES);
    setStudentMarks(INITIAL_STUDENT_MARKS);
    setInvoices(INITIAL_STUDENT_INVOICES);
    setReceipts(INITIAL_FEE_RECEIPTS);
    setSalaryPayments(INITIAL_SALARY_PAYMENTS);
    setExpenses(INITIAL_EXPENSES);
    setHomework(INITIAL_HOMEWORK);
    setNotices(INITIAL_NOTICES);
    setEvents(INITIAL_EVENTS);
    setBooks(INITIAL_BOOKS);
    setBookIssues(INITIAL_BOOK_ISSUES);
    setTransportRoutes(INITIAL_TRANSPORT_ROUTES);
    setInventory(INITIAL_INVENTORY);
    setComplaints(INITIAL_COMPLAINTS);
    setCertificates(INITIAL_CERTIFICATES);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setCurrentUser(INITIAL_USERS[0]);
    logAuditAction('UPDATE', 'SYSTEM_RESET', 'Database restored to clean enterprise factory state');
  };

  return (
    <SchoolContext.Provider
      value={{
        currentUser,
        switchUserRole,
        users,
        settings,
        updateSettings,
        academicSessions,
        classes,
        sections,
        subjects,
        timetable,
        addClass,
        addSection,
        addSubject,
        deleteSubject,
        saveTimetableSlot,
        students,
        parents,
        addStudent,
        updateStudent,
        deleteStudent,
        promoteStudents,
        addParent,
        staff,
        addStaff,
        updateStaff,
        deleteStaff,
        leaveApplications,
        applyLeave,
        reviewLeave,
        studentAttendance,
        staffAttendance,
        markBulkStudentAttendance,
        markStaffAttendance,
        getStudentAttendancePercentage,
        examTypes,
        examSchedules,
        studentMarks,
        gradingScales,
        addExamType,
        saveStudentMarks,
        calculateGradeAndGpa,
        feeCategories,
        classFeeStructures,
        invoices,
        receipts,
        salaryPayments,
        expenses,
        createInvoice,
        recordFeePayment,
        createSalaryPayment,
        addExpense,
        deleteExpense,
        homework,
        addHomework,
        notices,
        addNotice,
        events,
        addEvent,
        books,
        bookIssues,
        addBook,
        issueBook,
        returnBook,
        transportVehicles,
        transportRoutes,
        addTransportRoute,
        inventory,
        addInventoryItem,
        complaints,
        addComplaint,
        resolveComplaint,
        certificates,
        issueCertificate,
        auditLogs,
        logAuditAction,
        resetToDefaultData
      }}
    >
      {children}
    </SchoolContext.Provider>
  );
};

export const useSchool = () => {
  const context = useContext(SchoolContext);
  if (!context) {
    throw new Error('useSchool must be used within a SchoolProvider');
  }
  return context;
};
