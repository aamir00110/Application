import {
  SchoolSettings,
  AcademicSession,
  SchoolClass,
  Section,
  Subject,
  ClassSubjectTeacher,
  TimetableSlot,
  Parent,
  Student,
  TeacherStaff,
  StudentAttendanceRecord,
  StaffAttendanceRecord,
  LeaveApplication,
  ExamType,
  ExamSchedule,
  StudentExamMark,
  GradingScale,
  FeeCategory,
  ClassFeeStructure,
  StudentFeeInvoice,
  FeePaymentReceipt,
  SalaryPayment,
  ExpenseRecord,
  HomeworkAssignment,
  NoticeAnnouncement,
  SchoolEvent,
  LibraryBook,
  BookIssueReturn,
  TransportVehicle,
  TransportRoute,
  InventoryItem,
  ComplaintRecord,
  StudentCertificate,
  AuditLog,
  UserAccount
} from '../types';

export const INITIAL_SETTINGS: SchoolSettings = {
  schoolName: "Apex International Academy & College",
  schoolCode: "AIA-EDU-092",
  tagline: "Inspiring Excellence, Character & Innovation",
  logoUrl: "https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=120&auto=format&fit=crop&q=80",
  address: "742 Knowledge Avenue, Academic Enclave, Sector 4-B",
  city: "Metropolis",
  state: "Capital Region",
  country: "United States",
  postalCode: "10021",
  phone: "+1 (555) 234-8900",
  email: "admin@apexacademy.edu",
  website: "https://apexacademy.edu",
  currentAcademicSession: "2026-2027",
  currencySymbol: "$",
  currencyCode: "USD",
  gradingScheme: "GPA_4_0",
  receiptPrefix: "REC-2026-",
  admissionPrefix: "ADM-2026-",
  attendanceThresholdPercent: 75
};

export const INITIAL_SESSIONS: AcademicSession[] = [
  {
    id: "SES-2026",
    name: "2026-2027",
    startDate: "2026-08-01",
    endDate: "2027-06-30",
    isCurrent: true,
    status: "ACTIVE"
  },
  {
    id: "SES-2025",
    name: "2025-2026",
    startDate: "2025-08-01",
    endDate: "2026-06-30",
    isCurrent: false,
    status: "ARCHIVED"
  }
];

export const INITIAL_CLASSES: SchoolClass[] = [
  { id: "CLS-10", name: "Grade 10 (Senior High)", numericLevel: 10, capacity: 80, description: "Senior Secondary Matric/O-Level Board Examination Year" },
  { id: "CLS-09", name: "Grade 9 (High School)", numericLevel: 9, capacity: 80, description: "Secondary High School Sciences & Humanities Track" },
  { id: "CLS-08", name: "Grade 8 (Middle School)", numericLevel: 8, capacity: 70, description: "Middle School Pre-Secondary Foundation" },
  { id: "CLS-07", name: "Grade 7 (Middle School)", numericLevel: 7, capacity: 70, description: "Middle School Core Disciplines" },
  { id: "CLS-06", name: "Grade 6 (Middle School)", numericLevel: 6, capacity: 60, description: "Middle School Entry Year" }
];

export const INITIAL_SECTIONS: Section[] = [
  { id: "SEC-10A", classId: "CLS-10", name: "Section A (Science Stars)", classTeacherId: "STF-01", roomNumber: "Lab Wing 301", capacity: 40 },
  { id: "SEC-10B", classId: "CLS-10", name: "Section B (Math Olympiad)", classTeacherId: "STF-02", roomNumber: "Main Wing 302", capacity: 40 },
  { id: "SEC-09A", classId: "CLS-09", name: "Section A (Robotics & Tech)", classTeacherId: "STF-03", roomNumber: "Tech Hall 201", capacity: 40 },
  { id: "SEC-08A", classId: "CLS-08", name: "Section A (Foundation)", classTeacherId: "STF-04", roomNumber: "Junior Block 101", capacity: 35 }
];

export const INITIAL_SUBJECTS: Subject[] = [
  { id: "SUB-101", code: "MTH-10", name: "Advanced Mathematics & Calculus", classId: "CLS-10", type: "CORE", credits: 4, totalMarks: 100, passMarks: 40 },
  { id: "SUB-102", code: "PHY-10", name: "Physics & Applied Mechanics", classId: "CLS-10", type: "CORE", credits: 4, totalMarks: 100, passMarks: 40 },
  { id: "SUB-103", code: "CHM-10", name: "Chemistry & Laboratory", classId: "CLS-10", type: "CORE", credits: 4, totalMarks: 100, passMarks: 40 },
  { id: "SUB-104", code: "ENG-10", name: "English Literature & Composition", classId: "CLS-10", type: "CORE", credits: 3, totalMarks: 100, passMarks: 40 },
  { id: "SUB-105", code: "CSC-10", name: "Computer Science & Python", classId: "CLS-10", type: "ELECTIVE", credits: 3, totalMarks: 100, passMarks: 40 },
  { id: "SUB-091", code: "MTH-09", name: "Algebra & Geometry 9", classId: "CLS-09", type: "CORE", credits: 4, totalMarks: 100, passMarks: 40 },
  { id: "SUB-092", code: "SCI-09", name: "General Science 9", classId: "CLS-09", type: "CORE", credits: 4, totalMarks: 100, passMarks: 40 },
  { id: "SUB-081", code: "MTH-08", name: "Pre-Algebra Mathematics 8", classId: "CLS-08", type: "CORE", credits: 4, totalMarks: 100, passMarks: 40 }
];

export const INITIAL_TEACHERS_STAFF: TeacherStaff[] = [
  {
    id: "STF-01",
    employeeCode: "EMP-1001",
    firstName: "Dr. Robert",
    lastName: "Sterling",
    fullName: "Dr. Robert Sterling",
    gender: "MALE",
    designation: "Senior Professor & HOD Physics",
    department: "ACADEMICS",
    qualification: "Ph.D. in Applied Physics (MIT)",
    experienceYears: 14,
    dateOfJoining: "2018-08-15",
    dateOfBirth: "1982-04-12",
    phone: "+1 (555) 432-1101",
    email: "robert.sterling@apexacademy.edu",
    address: "88 University Crescent, Suite 4",
    cnic: "35201-9874521-1",
    basicSalary: 6200,
    avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
    status: "ACTIVE"
  },
  {
    id: "STF-02",
    employeeCode: "EMP-1002",
    firstName: "Eleanor",
    lastName: "Vance",
    fullName: "Eleanor Vance",
    gender: "FEMALE",
    designation: "Lead Mathematics Lecturer",
    department: "ACADEMICS",
    qualification: "M.Sc. Mathematics & Statistics (Stanford)",
    experienceYears: 10,
    dateOfJoining: "2020-01-10",
    dateOfBirth: "1988-11-23",
    phone: "+1 (555) 432-1102",
    email: "eleanor.vance@apexacademy.edu",
    address: "12 Pine Ridge Blvd",
    cnic: "35201-1123445-2",
    basicSalary: 5500,
    avatarUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80",
    status: "ACTIVE"
  },
  {
    id: "STF-03",
    employeeCode: "EMP-1003",
    firstName: "Marcus",
    lastName: "Chen",
    fullName: "Marcus Chen",
    gender: "MALE",
    designation: "Computer Science & Robotics Lead",
    department: "ACADEMICS",
    qualification: "B.S. Software Engineering (UC Berkeley)",
    experienceYears: 7,
    dateOfJoining: "2021-07-01",
    dateOfBirth: "1992-06-18",
    phone: "+1 (555) 432-1103",
    email: "marcus.chen@apexacademy.edu",
    address: "404 Silicon Way",
    cnic: "35201-4433221-3",
    basicSalary: 5300,
    avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
    status: "ACTIVE"
  },
  {
    id: "STF-04",
    employeeCode: "EMP-1004",
    firstName: "Sarah",
    lastName: "Jenkins",
    fullName: "Sarah Jenkins",
    gender: "FEMALE",
    designation: "English Department Head",
    department: "ACADEMICS",
    qualification: "M.A. English Literature (Oxford)",
    experienceYears: 12,
    dateOfJoining: "2019-09-01",
    dateOfBirth: "1985-02-14",
    phone: "+1 (555) 432-1104",
    email: "sarah.jenkins@apexacademy.edu",
    address: "15 Stratford Lane",
    cnic: "35201-7788990-4",
    basicSalary: 5400,
    avatarUrl: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80",
    status: "ACTIVE"
  },
  {
    id: "STF-05",
    employeeCode: "EMP-1005",
    firstName: "David",
    lastName: "Alvarez",
    fullName: "David Alvarez",
    gender: "MALE",
    designation: "Chief Financial Accountant",
    department: "ACCOUNTS",
    qualification: "CPA / M.Com Finance",
    experienceYears: 15,
    dateOfJoining: "2017-03-15",
    dateOfBirth: "1980-09-30",
    phone: "+1 (555) 432-1105",
    email: "accountant@apexacademy.edu",
    address: "200 Wall Street Terraces",
    cnic: "35201-9988776-5",
    basicSalary: 5800,
    avatarUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80",
    status: "ACTIVE"
  },
  {
    id: "STF-06",
    employeeCode: "EMP-1006",
    firstName: "Clara",
    lastName: "Oswald",
    fullName: "Clara Oswald",
    gender: "FEMALE",
    designation: "Front Desk & Public Relations Officer",
    department: "ADMINISTRATION",
    qualification: "B.A. Mass Communication",
    experienceYears: 5,
    dateOfJoining: "2022-04-01",
    dateOfBirth: "1995-12-05",
    phone: "+1 (555) 432-1106",
    email: "reception@apexacademy.edu",
    address: "73 Rosebud Avenue",
    cnic: "35201-6655443-6",
    basicSalary: 3800,
    avatarUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80",
    status: "ACTIVE"
  }
];

export const INITIAL_PARENTS: Parent[] = [
  {
    id: "PAR-01",
    fatherName: "Jonathan Hayes",
    motherName: "Katherine Hayes",
    fatherOccupation: "Senior Civil Engineer",
    motherOccupation: "Pediatrician",
    primaryPhone: "+1 (555) 789-0101",
    secondaryPhone: "+1 (555) 789-0102",
    email: "jonathan.hayes@gmail.com",
    cnicBForm: "35202-1234567-1",
    address: "45 Meadowlands Circle, North Heights",
    emergencyContact: "Katherine Hayes (Mother)",
    emergencyPhone: "+1 (555) 789-0102"
  },
  {
    id: "PAR-02",
    fatherName: "Tariq Mahmood",
    motherName: "Ayesha Tariq",
    fatherOccupation: "Chartered Accountant",
    motherOccupation: "Architect",
    primaryPhone: "+1 (555) 789-0201",
    email: "tariq.mahmood@corp.com",
    cnicBForm: "35202-7654321-2",
    address: "88 Kensington Park, Block C",
    emergencyContact: "Tariq Mahmood",
    emergencyPhone: "+1 (555) 789-0201"
  },
  {
    id: "PAR-03",
    fatherName: "Arthur Pendelton",
    motherName: "Claire Pendelton",
    fatherOccupation: "Managing Director, Logistics",
    motherOccupation: "Homemaker",
    primaryPhone: "+1 (555) 789-0301",
    email: "arthur.pendelton@apexmail.com",
    cnicBForm: "35202-9876543-3",
    address: "102 Harbor View Avenue",
    emergencyContact: "Arthur Pendelton",
    emergencyPhone: "+1 (555) 789-0301"
  },
  {
    id: "PAR-04",
    fatherName: "Dr. Vikram Seth",
    motherName: "Sunita Seth",
    fatherOccupation: "Cardiologist",
    motherOccupation: "Professor of Economics",
    primaryPhone: "+1 (555) 789-0401",
    email: "vikram.seth@metrohealth.org",
    cnicBForm: "35202-5544332-4",
    address: "14 Medical Enclave, Sector 9",
    emergencyContact: "Sunita Seth",
    emergencyPhone: "+1 (555) 789-0402"
  }
];

export const INITIAL_STUDENTS: Student[] = [
  {
    id: "STU-01",
    admissionNo: "ADM-2026-0001",
    rollNo: "10A-01",
    firstName: "Alexander",
    lastName: "Hayes",
    fullName: "Alexander Hayes",
    gender: "MALE",
    dateOfBirth: "2010-05-14",
    cnicBForm: "35202-1234567-9",
    bloodGroup: "O+",
    religion: "Christian",
    admissionDate: "2024-08-15",
    classId: "CLS-10",
    sectionId: "SEC-10A",
    academicSessionId: "SES-2026",
    parentId: "PAR-01",
    email: "alexander.hayes@student.apex.edu",
    phone: "+1 (555) 998-001",
    address: "45 Meadowlands Circle, North Heights",
    city: "Metropolis",
    previousSchool: "St. Jude Grammar Academy",
    medicalConditions: "Mild pollen allergy (has inhaler)",
    avatarUrl: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80",
    transportRequired: true,
    transportRouteId: "RT-01",
    status: "ACTIVE",
    createdDate: "2024-08-15"
  },
  {
    id: "STU-02",
    admissionNo: "ADM-2026-0002",
    rollNo: "10A-02",
    firstName: "Zainab",
    lastName: "Tariq",
    fullName: "Zainab Tariq",
    gender: "FEMALE",
    dateOfBirth: "2010-09-21",
    cnicBForm: "35202-7654321-8",
    bloodGroup: "A+",
    religion: "Islam",
    admissionDate: "2024-08-15",
    classId: "CLS-10",
    sectionId: "SEC-10A",
    academicSessionId: "SES-2026",
    parentId: "PAR-02",
    email: "zainab.tariq@student.apex.edu",
    phone: "+1 (555) 998-002",
    address: "88 Kensington Park, Block C",
    city: "Metropolis",
    previousSchool: "Beacon City School",
    medicalConditions: "None",
    avatarUrl: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80",
    transportRequired: true,
    transportRouteId: "RT-02",
    status: "ACTIVE",
    createdDate: "2024-08-15"
  },
  {
    id: "STU-03",
    admissionNo: "ADM-2026-0003",
    rollNo: "10A-03",
    firstName: "Oliver",
    lastName: "Pendelton",
    fullName: "Oliver Pendelton",
    gender: "MALE",
    dateOfBirth: "2010-03-02",
    cnicBForm: "35202-9876543-7",
    bloodGroup: "B+",
    religion: "Christian",
    admissionDate: "2024-08-15",
    classId: "CLS-10",
    sectionId: "SEC-10A",
    academicSessionId: "SES-2026",
    parentId: "PAR-03",
    email: "oliver.pendelton@student.apex.edu",
    phone: "+1 (555) 998-003",
    address: "102 Harbor View Avenue",
    city: "Metropolis",
    previousSchool: "St. Paul High School",
    medicalConditions: "None",
    avatarUrl: "https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?w=150&auto=format&fit=crop&q=80",
    transportRequired: false,
    status: "ACTIVE",
    createdDate: "2024-08-15"
  },
  {
    id: "STU-04",
    admissionNo: "ADM-2026-0004",
    rollNo: "10B-01",
    firstName: "Aarav",
    lastName: "Seth",
    fullName: "Aarav Seth",
    gender: "MALE",
    dateOfBirth: "2010-12-10",
    cnicBForm: "35202-5544332-6",
    bloodGroup: "AB+",
    religion: "Hindu",
    admissionDate: "2024-08-15",
    classId: "CLS-10",
    sectionId: "SEC-10B",
    academicSessionId: "SES-2026",
    parentId: "PAR-04",
    email: "aarav.seth@student.apex.edu",
    phone: "+1 (555) 998-004",
    address: "14 Medical Enclave, Sector 9",
    city: "Metropolis",
    previousSchool: "National Public School",
    medicalConditions: "Spectacles (-2.5 D)",
    avatarUrl: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80",
    transportRequired: true,
    transportRouteId: "RT-01",
    status: "ACTIVE",
    createdDate: "2024-08-15"
  },
  {
    id: "STU-05",
    admissionNo: "ADM-2026-0005",
    rollNo: "09A-01",
    firstName: "Sophie",
    lastName: "Hayes",
    fullName: "Sophie Hayes",
    gender: "FEMALE",
    dateOfBirth: "2011-08-19",
    cnicBForm: "35202-1234567-5",
    bloodGroup: "O+",
    religion: "Christian",
    admissionDate: "2025-08-15",
    classId: "CLS-09",
    sectionId: "SEC-09A",
    academicSessionId: "SES-2026",
    parentId: "PAR-01",
    email: "sophie.hayes@student.apex.edu",
    address: "45 Meadowlands Circle, North Heights",
    city: "Metropolis",
    previousSchool: "St. Jude Grammar Academy",
    avatarUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80",
    transportRequired: true,
    transportRouteId: "RT-01",
    status: "ACTIVE",
    createdDate: "2025-08-15"
  }
];

export const INITIAL_TIMETABLE: TimetableSlot[] = [
  { id: "TT-01", classId: "CLS-10", sectionId: "SEC-10A", dayOfWeek: "MONDAY", periodNumber: 1, startTime: "08:30", endTime: "09:15", subjectId: "SUB-101", teacherId: "STF-02", roomNumber: "Lab Wing 301" },
  { id: "TT-02", classId: "CLS-10", sectionId: "SEC-10A", dayOfWeek: "MONDAY", periodNumber: 2, startTime: "09:15", endTime: "10:00", subjectId: "SUB-102", teacherId: "STF-01", roomNumber: "Physics Lab 1" },
  { id: "TT-03", classId: "CLS-10", sectionId: "SEC-10A", dayOfWeek: "MONDAY", periodNumber: 3, startTime: "10:15", endTime: "11:00", subjectId: "SUB-103", teacherId: "STF-01", roomNumber: "Chemistry Lab 2" },
  { id: "TT-04", classId: "CLS-10", sectionId: "SEC-10A", dayOfWeek: "MONDAY", periodNumber: 4, startTime: "11:00", endTime: "11:45", subjectId: "SUB-104", teacherId: "STF-04", roomNumber: "Room 301" },
  { id: "TT-05", classId: "CLS-10", sectionId: "SEC-10A", dayOfWeek: "MONDAY", periodNumber: 5, startTime: "12:30", endTime: "01:15", subjectId: "SUB-105", teacherId: "STF-03", roomNumber: "Computer Lab A" },
  { id: "TT-06", classId: "CLS-10", sectionId: "SEC-10A", dayOfWeek: "TUESDAY", periodNumber: 1, startTime: "08:30", endTime: "09:15", subjectId: "SUB-102", teacherId: "STF-01", roomNumber: "Physics Lab 1" },
  { id: "TT-07", classId: "CLS-10", sectionId: "SEC-10A", dayOfWeek: "TUESDAY", periodNumber: 2, startTime: "09:15", endTime: "10:00", subjectId: "SUB-101", teacherId: "STF-02", roomNumber: "Lab Wing 301" },
  { id: "TT-08", classId: "CLS-10", sectionId: "SEC-10A", dayOfWeek: "WEDNESDAY", periodNumber: 1, startTime: "08:30", endTime: "09:15", subjectId: "SUB-105", teacherId: "STF-03", roomNumber: "Computer Lab A" }
];

export const INITIAL_ATTENDANCE: StudentAttendanceRecord[] = [
  { id: "ATT-01", studentId: "STU-01", classId: "CLS-10", sectionId: "SEC-10A", date: "2026-08-23", status: "PRESENT", recordedBy: "Dr. Robert Sterling" },
  { id: "ATT-02", studentId: "STU-02", classId: "CLS-10", sectionId: "SEC-10A", date: "2026-08-23", status: "PRESENT", recordedBy: "Dr. Robert Sterling" },
  { id: "ATT-03", studentId: "STU-03", classId: "CLS-10", sectionId: "SEC-10A", date: "2026-08-23", status: "LATE", remarks: "Traffic delay at Route 1", recordedBy: "Dr. Robert Sterling" },
  { id: "ATT-04", studentId: "STU-04", classId: "CLS-10", sectionId: "SEC-10B", date: "2026-08-23", status: "PRESENT", recordedBy: "Eleanor Vance" },
  { id: "ATT-05", studentId: "STU-05", classId: "CLS-09", sectionId: "SEC-09A", date: "2026-08-23", status: "PRESENT", recordedBy: "Marcus Chen" },
  
  // Historical yesterday
  { id: "ATT-06", studentId: "STU-01", classId: "CLS-10", sectionId: "SEC-10A", date: "2026-08-22", status: "PRESENT", recordedBy: "Dr. Robert Sterling" },
  { id: "ATT-07", studentId: "STU-02", classId: "CLS-10", sectionId: "SEC-10A", date: "2026-08-22", status: "PRESENT", recordedBy: "Dr. Robert Sterling" },
  { id: "ATT-08", studentId: "STU-03", classId: "CLS-10", sectionId: "SEC-10A", date: "2026-08-22", status: "PRESENT", recordedBy: "Dr. Robert Sterling" },
  { id: "ATT-09", studentId: "STU-04", classId: "CLS-10", sectionId: "SEC-10B", date: "2026-08-22", status: "EXCUSED", remarks: "Dentist appointment", recordedBy: "Eleanor Vance" },
  { id: "ATT-10", studentId: "STU-05", classId: "CLS-09", sectionId: "SEC-09A", date: "2026-08-22", status: "PRESENT", recordedBy: "Marcus Chen" }
];

export const INITIAL_STAFF_ATTENDANCE: StaffAttendanceRecord[] = [
  { id: "SATT-01", staffId: "STF-01", date: "2026-08-23", status: "PRESENT", checkInTime: "07:45 AM", checkOutTime: "03:30 PM" },
  { id: "SATT-02", staffId: "STF-02", date: "2026-08-23", status: "PRESENT", checkInTime: "07:50 AM", checkOutTime: "03:30 PM" },
  { id: "SATT-03", staffId: "STF-03", date: "2026-08-23", status: "PRESENT", checkInTime: "08:00 AM" },
  { id: "SATT-04", staffId: "STF-04", date: "2026-08-23", status: "PRESENT", checkInTime: "07:55 AM" },
  { id: "SATT-05", staffId: "STF-05", date: "2026-08-23", status: "PRESENT", checkInTime: "08:10 AM" },
  { id: "SATT-06", staffId: "STF-06", date: "2026-08-23", status: "PRESENT", checkInTime: "07:30 AM" }
];

export const INITIAL_LEAVE_APPLICATIONS: LeaveApplication[] = [
  {
    id: "LEV-01",
    applicantType: "STUDENT",
    applicantId: "STU-04",
    leaveType: "SICK",
    startDate: "2026-08-26",
    endDate: "2026-08-27",
    reason: "Scheduled minor laser eye checkup procedure",
    status: "APPROVED",
    appliedDate: "2026-08-22",
    reviewedBy: "Principal Dr. Harrison",
    reviewRemarks: "Approved. Please submit doctor note on return."
  },
  {
    id: "LEV-02",
    applicantType: "STAFF",
    applicantId: "STF-04",
    leaveType: "CASUAL",
    startDate: "2026-08-29",
    endDate: "2026-08-29",
    reason: "Family wedding attendance",
    status: "PENDING",
    appliedDate: "2026-08-23"
  }
];

export const INITIAL_EXAM_TYPES: ExamType[] = [
  { id: "EXM-01", name: "Mid-Term Examination 2026", academicSessionId: "SES-2026", startDate: "2026-10-10", endDate: "2026-10-22", weightagePercent: 30, status: "RESULTS_PUBLISHED" },
  { id: "EXM-02", name: "Pre-Board Mock Assessment", academicSessionId: "SES-2026", startDate: "2026-12-05", endDate: "2026-12-18", weightagePercent: 20, status: "UPCOMING" },
  { id: "EXM-03", name: "Annual Final Board Examination", academicSessionId: "SES-2026", startDate: "2027-03-01", endDate: "2027-03-20", weightagePercent: 50, status: "UPCOMING" }
];

export const INITIAL_EXAM_SCHEDULES: ExamSchedule[] = [
  { id: "SCH-01", examTypeId: "EXM-01", classId: "CLS-10", subjectId: "SUB-101", examDate: "2026-10-10", startTime: "09:00 AM", endTime: "12:00 PM", maxMarks: 100, passMarks: 40, roomNumber: "Exam Hall A" },
  { id: "SCH-02", examTypeId: "EXM-01", classId: "CLS-10", subjectId: "SUB-102", examDate: "2026-10-12", startTime: "09:00 AM", endTime: "12:00 PM", maxMarks: 100, passMarks: 40, roomNumber: "Exam Hall A" },
  { id: "SCH-03", examTypeId: "EXM-01", classId: "CLS-10", subjectId: "SUB-103", examDate: "2026-10-15", startTime: "09:00 AM", endTime: "12:00 PM", maxMarks: 100, passMarks: 40, roomNumber: "Exam Hall A" },
  { id: "SCH-04", examTypeId: "EXM-01", classId: "CLS-10", subjectId: "SUB-104", examDate: "2026-10-18", startTime: "09:00 AM", endTime: "12:00 PM", maxMarks: 100, passMarks: 40, roomNumber: "Exam Hall A" },
  { id: "SCH-05", examTypeId: "EXM-01", classId: "CLS-10", subjectId: "SUB-105", examDate: "2026-10-21", startTime: "09:00 AM", endTime: "12:00 PM", maxMarks: 100, passMarks: 40, roomNumber: "Computer Lab A" }
];

export const INITIAL_GRADING_SCALES: GradingScale[] = [
  { id: "GRD-1", grade: "A+", minPercent: 90, maxPercent: 100, gpaPoint: 4.0, description: "Outstanding / Exceptional Mastery" },
  { id: "GRD-2", grade: "A", minPercent: 80, maxPercent: 89.99, gpaPoint: 3.7, description: "Excellent Performance" },
  { id: "GRD-3", grade: "B", minPercent: 70, maxPercent: 79.99, gpaPoint: 3.0, description: "Good / Above Average" },
  { id: "GRD-4", grade: "C", minPercent: 60, maxPercent: 69.99, gpaPoint: 2.0, description: "Satisfactory / Average" },
  { id: "GRD-5", grade: "D", minPercent: 40, maxPercent: 59.99, gpaPoint: 1.0, description: "Pass / Needs Improvement" },
  { id: "GRD-6", grade: "F", minPercent: 0, maxPercent: 39.99, gpaPoint: 0.0, description: "Fail / Academic Warning" }
];

export const INITIAL_STUDENT_MARKS: StudentExamMark[] = [
  // Alexander Hayes (STU-01) - High achiever
  { id: "MRK-01", examTypeId: "EXM-01", studentId: "STU-01", classId: "CLS-10", subjectId: "SUB-101", marksObtained: 94, maxMarks: 100, passMarks: 40, grade: "A+", gpa: 4.0, isAbsent: false, remarks: "Top score in Calculus" },
  { id: "MRK-02", examTypeId: "EXM-01", studentId: "STU-01", classId: "CLS-10", subjectId: "SUB-102", marksObtained: 91, maxMarks: 100, passMarks: 40, grade: "A+", gpa: 4.0, isAbsent: false },
  { id: "MRK-03", examTypeId: "EXM-01", studentId: "STU-01", classId: "CLS-10", subjectId: "SUB-103", marksObtained: 88, maxMarks: 100, passMarks: 40, grade: "A", gpa: 3.7, isAbsent: false },
  { id: "MRK-04", examTypeId: "EXM-01", studentId: "STU-01", classId: "CLS-10", subjectId: "SUB-104", marksObtained: 85, maxMarks: 100, passMarks: 40, grade: "A", gpa: 3.7, isAbsent: false },
  { id: "MRK-05", examTypeId: "EXM-01", studentId: "STU-01", classId: "CLS-10", subjectId: "SUB-105", marksObtained: 97, maxMarks: 100, passMarks: 40, grade: "A+", gpa: 4.0, isAbsent: false, remarks: "Flawless code project" },

  // Zainab Tariq (STU-02) - Rank 2
  { id: "MRK-06", examTypeId: "EXM-01", studentId: "STU-02", classId: "CLS-10", subjectId: "SUB-101", marksObtained: 89, maxMarks: 100, passMarks: 40, grade: "A", gpa: 3.7, isAbsent: false },
  { id: "MRK-07", examTypeId: "EXM-01", studentId: "STU-02", classId: "CLS-10", subjectId: "SUB-102", marksObtained: 93, maxMarks: 100, passMarks: 40, grade: "A+", gpa: 4.0, isAbsent: false },
  { id: "MRK-08", examTypeId: "EXM-01", studentId: "STU-02", classId: "CLS-10", subjectId: "SUB-103", marksObtained: 92, maxMarks: 100, passMarks: 40, grade: "A+", gpa: 4.0, isAbsent: false },
  { id: "MRK-09", examTypeId: "EXM-01", studentId: "STU-02", classId: "CLS-10", subjectId: "SUB-104", marksObtained: 90, maxMarks: 100, passMarks: 40, grade: "A+", gpa: 4.0, isAbsent: false },
  { id: "MRK-10", examTypeId: "EXM-01", studentId: "STU-02", classId: "CLS-10", subjectId: "SUB-105", marksObtained: 89, maxMarks: 100, passMarks: 40, grade: "A", gpa: 3.7, isAbsent: false },

  // Oliver Pendelton (STU-03)
  { id: "MRK-11", examTypeId: "EXM-01", studentId: "STU-03", classId: "CLS-10", subjectId: "SUB-101", marksObtained: 76, maxMarks: 100, passMarks: 40, grade: "B", gpa: 3.0, isAbsent: false },
  { id: "MRK-12", examTypeId: "EXM-01", studentId: "STU-03", classId: "CLS-10", subjectId: "SUB-102", marksObtained: 81, maxMarks: 100, passMarks: 40, grade: "A", gpa: 3.7, isAbsent: false },
  { id: "MRK-13", examTypeId: "EXM-01", studentId: "STU-03", classId: "CLS-10", subjectId: "SUB-103", marksObtained: 74, maxMarks: 100, passMarks: 40, grade: "B", gpa: 3.0, isAbsent: false },
  { id: "MRK-14", examTypeId: "EXM-01", studentId: "STU-03", classId: "CLS-10", subjectId: "SUB-104", marksObtained: 88, maxMarks: 100, passMarks: 40, grade: "A", gpa: 3.7, isAbsent: false },
  { id: "MRK-15", examTypeId: "EXM-01", studentId: "STU-03", classId: "CLS-10", subjectId: "SUB-105", marksObtained: 82, maxMarks: 100, passMarks: 40, grade: "A", gpa: 3.7, isAbsent: false }
];

export const INITIAL_FEE_CATEGORIES: FeeCategory[] = [
  { id: "FC-01", name: "Monthly Tuition Fee", frequency: "MONTHLY", description: "Regular instructional and laboratory tuition" },
  { id: "FC-02", name: "Science & Computer Lab Fee", frequency: "TERM_WISE", description: "Consumables, software licenses, lab materials" },
  { id: "FC-03", name: "Transport Facility Fee", frequency: "MONTHLY", description: "Air-conditioned GPS bus pick and drop service" },
  { id: "FC-04", name: "Annual Admission & Exam Fee", frequency: "ANNUAL", description: "Board registration and comprehensive exam processing" },
  { id: "FC-05", name: "Sports & Extracurricular Club", frequency: "TERM_WISE", description: "Athletics, swimming pool, and club memberships" }
];

export const INITIAL_CLASS_FEE_STRUCTURE: ClassFeeStructure[] = [
  { id: "CFS-01", classId: "CLS-10", feeCategoryId: "FC-01", amount: 450, academicSessionId: "SES-2026" },
  { id: "CFS-02", classId: "CLS-10", feeCategoryId: "FC-02", amount: 90, academicSessionId: "SES-2026" },
  { id: "CFS-03", classId: "CLS-10", feeCategoryId: "FC-03", amount: 120, academicSessionId: "SES-2026" },
  { id: "CFS-04", classId: "CLS-09", feeCategoryId: "FC-01", amount: 420, academicSessionId: "SES-2026" },
  { id: "CFS-05", classId: "CLS-08", feeCategoryId: "FC-01", amount: 380, academicSessionId: "SES-2026" }
];

export const INITIAL_STUDENT_INVOICES: StudentFeeInvoice[] = [
  {
    id: "INV-2026-0001",
    invoiceNo: "INV-2026-0001",
    studentId: "STU-01",
    classId: "CLS-10",
    academicSessionId: "SES-2026",
    monthOrTerm: "August 2026",
    issueDate: "2026-08-01",
    dueDate: "2026-08-10",
    totalAmount: 660,
    discountAmount: 60, // Academic Merit Scholarship
    fineAmount: 0,
    netPayable: 600,
    paidAmount: 600,
    balanceAmount: 0,
    status: "PAID",
    items: [
      { feeCategoryId: "FC-01", categoryName: "Monthly Tuition Fee", amount: 450 },
      { feeCategoryId: "FC-02", categoryName: "Science & Computer Lab Fee", amount: 90 },
      { feeCategoryId: "FC-03", categoryName: "Transport Facility Fee", amount: 120 }
    ]
  },
  {
    id: "INV-2026-0002",
    invoiceNo: "INV-2026-0002",
    studentId: "STU-02",
    classId: "CLS-10",
    academicSessionId: "SES-2026",
    monthOrTerm: "August 2026",
    issueDate: "2026-08-01",
    dueDate: "2026-08-10",
    totalAmount: 660,
    discountAmount: 0,
    fineAmount: 0,
    netPayable: 660,
    paidAmount: 660,
    balanceAmount: 0,
    status: "PAID",
    items: [
      { feeCategoryId: "FC-01", categoryName: "Monthly Tuition Fee", amount: 450 },
      { feeCategoryId: "FC-02", categoryName: "Science & Computer Lab Fee", amount: 90 },
      { feeCategoryId: "FC-03", categoryName: "Transport Facility Fee", amount: 120 }
    ]
  },
  {
    id: "INV-2026-0003",
    invoiceNo: "INV-2026-0003",
    studentId: "STU-03",
    classId: "CLS-10",
    academicSessionId: "SES-2026",
    monthOrTerm: "August 2026",
    issueDate: "2026-08-01",
    dueDate: "2026-08-10",
    totalAmount: 540,
    discountAmount: 0,
    fineAmount: 25, // Late payment fine
    netPayable: 565,
    paidAmount: 200,
    balanceAmount: 365,
    status: "PARTIALLY_PAID",
    items: [
      { feeCategoryId: "FC-01", categoryName: "Monthly Tuition Fee", amount: 450 },
      { feeCategoryId: "FC-02", categoryName: "Science & Computer Lab Fee", amount: 90 }
    ]
  },
  {
    id: "INV-2026-0004",
    invoiceNo: "INV-2026-0004",
    studentId: "STU-04",
    classId: "CLS-10",
    academicSessionId: "SES-2026",
    monthOrTerm: "August 2026",
    issueDate: "2026-08-01",
    dueDate: "2026-08-10",
    totalAmount: 660,
    discountAmount: 0,
    fineAmount: 30,
    netPayable: 690,
    paidAmount: 0,
    balanceAmount: 690,
    status: "OVERDUE",
    items: [
      { feeCategoryId: "FC-01", categoryName: "Monthly Tuition Fee", amount: 450 },
      { feeCategoryId: "FC-02", categoryName: "Science & Computer Lab Fee", amount: 90 },
      { feeCategoryId: "FC-03", categoryName: "Transport Facility Fee", amount: 120 }
    ]
  }
];

export const INITIAL_FEE_RECEIPTS: FeePaymentReceipt[] = [
  {
    id: "REC-01",
    receiptNo: "REC-2026-0001",
    invoiceId: "INV-2026-0001",
    studentId: "STU-01",
    paymentDate: "2026-08-05",
    amountPaid: 600,
    paymentMethod: "ONLINE_TRANSFER",
    referenceNo: "CHASE-TX-88741",
    collectedBy: "David Alvarez (Accountant)",
    remarks: "Full fee settlement with merit scholarship"
  },
  {
    id: "REC-02",
    receiptNo: "REC-2026-0002",
    invoiceId: "INV-2026-0002",
    studentId: "STU-02",
    paymentDate: "2026-08-06",
    amountPaid: 660,
    paymentMethod: "BANK_CHALLAN",
    referenceNo: "HABIB-CHL-0091",
    collectedBy: "David Alvarez (Accountant)",
    remarks: "Bank deposit branch cleared"
  },
  {
    id: "REC-03",
    receiptNo: "REC-2026-0003",
    invoiceId: "INV-2026-0003",
    studentId: "STU-03",
    paymentDate: "2026-08-12",
    amountPaid: 200,
    paymentMethod: "CASH",
    referenceNo: "CASH-REC-0012",
    collectedBy: "David Alvarez (Accountant)",
    remarks: "Partial payment received at cashier desk"
  }
];

export const INITIAL_SALARY_PAYMENTS: SalaryPayment[] = [
  {
    id: "SAL-01",
    voucherNo: "SAL-2026-08-01",
    staffId: "STF-01",
    monthYear: "August 2026",
    basicSalary: 6200,
    allowances: 800, // Research & Seniority Allowance
    deductions: 250, // Health insurance & Tax
    netSalary: 6750,
    paymentDate: "2026-08-20",
    paymentMethod: "BANK_TRANSFER",
    status: "PAID",
    remarks: "Direct deposit to Wells Fargo Account"
  },
  {
    id: "SAL-02",
    voucherNo: "SAL-2026-08-02",
    staffId: "STF-02",
    monthYear: "August 2026",
    basicSalary: 5500,
    allowances: 500,
    deductions: 200,
    netSalary: 5800,
    paymentDate: "2026-08-20",
    paymentMethod: "BANK_TRANSFER",
    status: "PAID"
  },
  {
    id: "SAL-03",
    voucherNo: "SAL-2026-08-03",
    staffId: "STF-03",
    monthYear: "August 2026",
    basicSalary: 5300,
    allowances: 450,
    deductions: 180,
    netSalary: 5570,
    paymentDate: "2026-08-20",
    paymentMethod: "BANK_TRANSFER",
    status: "PAID"
  }
];

export const INITIAL_EXPENSES: ExpenseRecord[] = [
  {
    id: "EXP-01",
    voucherNo: "EXP-2026-010",
    title: "High-Speed Campus Fiber Internet & Cloud Server Hosting",
    category: "UTILITIES",
    amount: 850,
    expenseDate: "2026-08-02",
    paidTo: "Metro Fiber & AWS Cloud Services",
    paymentMethod: "BANK_TRANSFER",
    approvedBy: "Principal Dr. Harrison",
    description: "Monthly campus gigabit connectivity"
  },
  {
    id: "EXP-02",
    voucherNo: "EXP-2026-011",
    title: "Physics & Chemistry Lab Reagents and Glassware",
    category: "LAB_EQUIPMENT",
    amount: 1450,
    expenseDate: "2026-08-10",
    paidTo: "Apex Scientific Supplies Co.",
    paymentMethod: "CHEQUE",
    approvedBy: "Principal Dr. Harrison",
    description: "Annual consumable replenishment for Senior Labs"
  },
  {
    id: "EXP-03",
    voucherNo: "EXP-2026-012",
    title: "School Fleet Diesel Fuel & Vehicle Maintenance",
    category: "TRANSPORT",
    amount: 920,
    expenseDate: "2026-08-18",
    paidTo: "City Transport Fuel Station",
    paymentMethod: "CASH",
    approvedBy: "David Alvarez (Accountant)"
  }
];

export const INITIAL_HOMEWORK: HomeworkAssignment[] = [
  {
    id: "HW-01",
    title: "Calculus - Derivatives & Chain Rule Problem Set 4.2",
    classId: "CLS-10",
    sectionId: "SEC-10A",
    subjectId: "SUB-101",
    teacherId: "STF-02",
    assignedDate: "2026-08-22",
    dueDate: "2026-08-26",
    description: "Complete exercises 1 to 15 from Chapter 4 in Advanced Calculus Workbook. Show all step-by-step limits.",
    maxPoints: 25
  },
  {
    id: "HW-02",
    title: "Electromagnetic Induction Lab Report & Observations",
    classId: "CLS-10",
    sectionId: "SEC-10A",
    subjectId: "SUB-102",
    teacherId: "STF-01",
    assignedDate: "2026-08-21",
    dueDate: "2026-08-25",
    description: "Write a 3-page formal laboratory report analyzing Faraday's Law experiment conducted in Friday's lab.",
    maxPoints: 30
  }
];

export const INITIAL_NOTICES: NoticeAnnouncement[] = [
  {
    id: "NOT-01",
    title: "Annual STEM Innovation & Robotics Expo 2026",
    content: "We are thrilled to announce our Annual STEM & Robotics Fair on October 14th. All high school science projects must be registered with Dr. Sterling by Sept 15.",
    targetAudience: "ALL",
    priority: "HIGH",
    publishDate: "2026-08-20",
    authorName: "Principal Dr. Harrison",
    isPinned: true
  },
  {
    id: "NOT-02",
    title: "Parent-Teacher Conference (Term 1 Review)",
    content: "The Parent-Teacher Meeting for Grades 8, 9, and 10 will be held on Saturday, September 5th from 9:00 AM to 1:00 PM in the Main Auditorium.",
    targetAudience: "PARENTS",
    priority: "HIGH",
    publishDate: "2026-08-22",
    authorName: "Academic Administration",
    isPinned: true
  },
  {
    id: "NOT-03",
    title: "Library Book Amnesty Week - Zero Late Fines",
    content: "Return any overdue library books between August 25 and August 31 with 100% fine waiver. Please check your student portal for issued books.",
    targetAudience: "STUDENTS",
    priority: "MEDIUM",
    publishDate: "2026-08-23",
    authorName: "Head Librarian",
    isPinned: false
  }
];

export const INITIAL_EVENTS: SchoolEvent[] = [
  {
    id: "EVT-01",
    title: "Inter-School Swimming Championship",
    category: "SPORTS",
    startDate: "2026-09-12",
    endDate: "2026-09-13",
    location: "Olympic Aquatic Center",
    description: "Annual regional school swimming gala featuring 16 competing academies.",
    targetAudience: "All Students & Staff"
  },
  {
    id: "EVT-02",
    title: "Mid-Term Examination Commencement",
    category: "EXAM",
    startDate: "2026-10-10",
    endDate: "2026-10-22",
    location: "Academic Examination Halls",
    description: "Comprehensive mid-year examinations for all classes.",
    targetAudience: "Grade 6 to Grade 10"
  }
];

export const INITIAL_BOOKS: LibraryBook[] = [
  { id: "BK-01", isbn: "978-0134685991", title: "Effective Java (3rd Edition)", author: "Joshua Bloch", publisher: "Addison-Wesley", category: "COMPUTER", totalCopies: 8, availableCopies: 5, rackLocation: "CS-Rack-04", price: 55 },
  { id: "BK-02", isbn: "978-0471198260", title: "Fundamentals of Physics (Halliday & Resnick)", author: "David Halliday", publisher: "Wiley", category: "SCIENCE", totalCopies: 12, availableCopies: 8, rackLocation: "SCI-Rack-02", price: 110 },
  { id: "BK-03", isbn: "978-0071375771", title: "Schaum's Outline of Calculus", author: "Frank Ayres", publisher: "McGraw-Hill", category: "MATHEMATICS", totalCopies: 15, availableCopies: 11, rackLocation: "MTH-Rack-01", price: 32 },
  { id: "BK-04", isbn: "978-0141439518", title: "Pride and Prejudice", author: "Jane Austen", publisher: "Penguin Classics", category: "LITERATURE", totalCopies: 10, availableCopies: 9, rackLocation: "LIT-Rack-03", price: 14 }
];

export const INITIAL_BOOK_ISSUES: BookIssueReturn[] = [
  { id: "ISS-01", bookId: "BK-02", borrowerType: "STUDENT", borrowerId: "STU-01", issueDate: "2026-08-10", dueDate: "2026-08-24", fineAmount: 0, status: "ISSUED" },
  { id: "ISS-02", bookId: "BK-03", borrowerType: "STUDENT", borrowerId: "STU-02", issueDate: "2026-08-01", dueDate: "2026-08-15", returnDate: "2026-08-14", fineAmount: 0, status: "RETURNED" }
];

export const INITIAL_TRANSPORT_VEHICLES: TransportVehicle[] = [
  { id: "VH-01", vehicleNo: "BUS-01", registrationNo: "MET-8842", capacity: 42, driverName: "Michael O'Connor", driverPhone: "+1 (555) 321-7701", driverLicenseNo: "DL-COMM-9981", status: "ACTIVE" },
  { id: "VH-02", vehicleNo: "BUS-02", registrationNo: "MET-8843", capacity: 36, driverName: "Samuel Brooks", driverPhone: "+1 (555) 321-7702", driverLicenseNo: "DL-COMM-9982", status: "ACTIVE" }
];

export const INITIAL_TRANSPORT_ROUTES: TransportRoute[] = [
  { id: "RT-01", routeName: "Route 1 (North Heights & Meadowlands)", startPoint: "North Gate Station", endPoint: "Apex Academy Campus", stops: ["North Gate", "Meadowlands Circle", "Pine Ridge", "Medical Enclave", "School"], vehicleId: "VH-01", monthlyFee: 120 },
  { id: "RT-02", routeName: "Route 2 (Kensington & East Bay)", startPoint: "East Bay Terminal", endPoint: "Apex Academy Campus", stops: ["East Bay", "Kensington Park", "Harbor View", "Rosebud Ave", "School"], vehicleId: "VH-02", monthlyFee: 120 }
];

export const INITIAL_INVENTORY: InventoryItem[] = [
  { id: "INV-01", itemCode: "AST-FUR-0101", itemName: "Ergonomic Student Dual Desk & Chair Set", category: "FURNITURE", quantity: 180, unit: "Sets", locationRoom: "Classrooms 101-305", condition: "GOOD", purchaseDate: "2023-06-15" },
  { id: "INV-02", itemCode: "AST-IT-0204", itemName: "Dell OptiPlex Core i7 Workstation (Lab Setup)", category: "IT_HARDWARE", quantity: 45, unit: "Units", locationRoom: "Computer Lab A", condition: "GOOD", purchaseDate: "2024-01-20" },
  { id: "INV-03", itemCode: "AST-SCI-0301", itemName: "Binocular Optical Compound Microscope (1000x)", category: "LAB_EQUIPMENT", quantity: 24, unit: "Pieces", locationRoom: "Biology Lab", condition: "NEW", purchaseDate: "2025-08-10" }
];

export const INITIAL_COMPLAINTS: ComplaintRecord[] = [
  {
    id: "CMP-01",
    complainantType: "PARENT",
    complainantName: "Jonathan Hayes",
    complainantPhone: "+1 (555) 789-0101",
    title: "Air Conditioning performance in Physics Lab 1",
    description: "During recent hot days, the AC unit in Lab 1 was tripping repeatedly during the afternoon double period.",
    category: "FACILITY",
    priority: "MEDIUM",
    status: "RESOLVED",
    submittedDate: "2026-08-18",
    resolutionRemarks: "HVAC maintenance team replaced compressor capacitor on Aug 19. Tested working at 21C.",
    resolvedDate: "2026-08-19"
  },
  {
    id: "CMP-02",
    complainantType: "STUDENT",
    complainantName: "Oliver Pendelton",
    title: "Request for additional Python algorithm practice books in Library",
    description: "The 3 copies of modern algorithm books are always reserved. Would love 2 more copies.",
    category: "ACADEMIC",
    priority: "LOW",
    status: "INVESTIGATING",
    submittedDate: "2026-08-21"
  }
];

export const INITIAL_CERTIFICATES: StudentCertificate[] = [
  {
    id: "CERT-01",
    certificateNo: "CERT-2026-0042",
    studentId: "STU-01",
    type: "BONAFIDE",
    issueDate: "2026-08-15",
    purpose: "Passport renewal & international student visa application",
    signedBy: "Principal Dr. Harrison",
    remarks: "Certified bonafide student of Grade 10-A for Academic Session 2026-2027"
  },
  {
    id: "CERT-02",
    certificateNo: "CERT-2026-0043",
    studentId: "STU-02",
    type: "CHARACTER",
    issueDate: "2026-08-16",
    purpose: "National Youth Leadership Award application",
    signedBy: "Principal Dr. Harrison",
    remarks: "Exemplary conduct, academic leadership, and high civic responsibility"
  }
];

export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  { id: "LOG-01", timestamp: "2026-08-23 08:30:12", userName: "superadmin", userRole: "SUPER_ADMIN", action: "LOGIN", module: "AUTH", description: "Successful login from authorized terminal", ipAddress: "192.168.1.10" },
  { id: "LOG-02", timestamp: "2026-08-23 08:45:00", userName: "Dr. Robert Sterling", userRole: "TEACHER", action: "CREATE", module: "ATTENDANCE", description: "Submitted daily attendance for Grade 10-A (3 Present, 1 Late)", ipAddress: "192.168.1.45" },
  { id: "LOG-03", timestamp: "2026-08-23 09:12:40", userName: "David Alvarez", userRole: "ACCOUNTANT", action: "PAYMENT_PROCESSED", module: "FEE_COLLECTION", description: "Processed Receipt REC-2026-0003 for Oliver Pendelton ($200.00)", ipAddress: "192.168.1.22" },
  { id: "LOG-04", timestamp: "2026-08-23 09:50:18", userName: "Principal Dr. Harrison", userRole: "PRINCIPAL", action: "UPDATE", module: "LEAVE", description: "Approved sick leave application LEV-01 for Aarav Seth", ipAddress: "192.168.1.12" }
];

export const INITIAL_USERS: UserAccount[] = [
  {
    id: "USR-01",
    username: "superadmin",
    fullName: "Chief Enterprise Administrator",
    email: "superadmin@apexacademy.edu",
    role: "SUPER_ADMIN",
    phone: "+1 (555) 999-0001",
    isActive: true,
    createdDate: "2024-01-01",
    lastLogin: "Just now"
  },
  {
    id: "USR-02",
    username: "schooladmin",
    fullName: "Claire Crawford (Campus Admin)",
    email: "admin@apexacademy.edu",
    role: "SCHOOL_ADMIN",
    phone: "+1 (555) 999-0002",
    isActive: true,
    createdDate: "2024-01-01",
    lastLogin: "10 mins ago"
  },
  {
    id: "USR-03",
    username: "principal",
    fullName: "Dr. Harrison Vance (Principal)",
    email: "principal@apexacademy.edu",
    role: "PRINCIPAL",
    phone: "+1 (555) 999-0003",
    isActive: true,
    createdDate: "2024-01-01",
    lastLogin: "25 mins ago"
  },
  {
    id: "USR-04",
    username: "teacher.robert",
    fullName: "Dr. Robert Sterling (Physics)",
    email: "robert.sterling@apexacademy.edu",
    role: "TEACHER",
    linkedEntityId: "STF-01",
    phone: "+1 (555) 432-1101",
    isActive: true,
    createdDate: "2024-01-01",
    lastLogin: "Today 08:30 AM"
  },
  {
    id: "USR-05",
    username: "accountant",
    fullName: "David Alvarez (Head Accountant)",
    email: "accountant@apexacademy.edu",
    role: "ACCOUNTANT",
    linkedEntityId: "STF-05",
    phone: "+1 (555) 432-1105",
    isActive: true,
    createdDate: "2024-01-01",
    lastLogin: "Today 08:15 AM"
  },
  {
    id: "USR-06",
    username: "receptionist",
    fullName: "Clara Oswald (Front Desk)",
    email: "reception@apexacademy.edu",
    role: "RECEPTIONIST",
    linkedEntityId: "STF-06",
    phone: "+1 (555) 432-1106",
    isActive: true,
    createdDate: "2024-01-01",
    lastLogin: "Today 07:30 AM"
  },
  {
    id: "USR-07",
    username: "student.alex",
    fullName: "Alexander Hayes (Student 10-A)",
    email: "alexander.hayes@student.apex.edu",
    role: "STUDENT",
    linkedEntityId: "STU-01",
    phone: "+1 (555) 998-001",
    isActive: true,
    createdDate: "2024-08-15",
    lastLogin: "Yesterday"
  },
  {
    id: "USR-08",
    username: "parent.hayes",
    fullName: "Jonathan Hayes (Parent)",
    email: "jonathan.hayes@gmail.com",
    role: "PARENT",
    linkedEntityId: "PAR-01",
    phone: "+1 (555) 789-0101",
    isActive: true,
    createdDate: "2024-08-15",
    lastLogin: "2 days ago"
  }
];

export function calculateGradeAndGPA(marksObtained: number, maxMarks: number = 100): { grade: string; gpa: number } {
  const percentage = maxMarks > 0 ? (marksObtained / maxMarks) * 100 : 0;
  if (percentage >= 80) return { grade: 'A+', gpa: 4.0 };
  if (percentage >= 70) return { grade: 'A', gpa: 3.7 };
  if (percentage >= 60) return { grade: 'B', gpa: 3.0 };
  if (percentage >= 50) return { grade: 'C', gpa: 2.0 };
  if (percentage >= 40) return { grade: 'D', gpa: 1.0 };
  return { grade: 'F', gpa: 0.0 };
}
