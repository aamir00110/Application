import React, { useState } from 'react';
import {
  FileText,
  Search,
  ShieldAlert,
  Clock,
  User,
  Database,
  Filter
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { AuditLog } from '../../types';
import { InteractiveReport, ColumnDef } from '../common/InteractiveReport';

export const AuditLogViewer: React.FC = () => {
  const { auditLogs } = useSchool();

  const columns: ColumnDef<AuditLog>[] = [
    {
      header: "Timestamp",
      accessorKey: "timestamp",
      cell: (log: AuditLog) => (
        <span className="font-mono text-slate-600 text-[11px] whitespace-nowrap">
          {new Date(log.timestamp).toLocaleString()}
        </span>
      )
    },
    {
      header: "Action Performed",
      accessorKey: "action",
      cell: (log: AuditLog) => {
        const actionColors: Record<string, string> = {
          CREATE: 'bg-emerald-100 text-emerald-800 border-emerald-200',
          UPDATE: 'bg-blue-100 text-blue-800 border-blue-200',
          DELETE: 'bg-rose-100 text-rose-800 border-rose-200',
          LOGIN: 'bg-purple-100 text-purple-800 border-purple-200',
          DISBURSE: 'bg-amber-100 text-amber-800 border-amber-200',
          ENROLL: 'bg-cyan-100 text-cyan-800 border-cyan-200'
        };

        return (
          <span className={`px-2 py-0.5 rounded font-mono text-[10px] font-bold border ${actionColors[log.action] || 'bg-slate-100 text-slate-800'}`}>
            {log.action}
          </span>
        );
      }
    },
    {
      header: "Target Entity / Table",
      accessorKey: "entity",
      cell: (log: AuditLog) => (
        <span className="font-mono font-semibold text-slate-800 bg-slate-100 px-2 py-0.5 rounded text-[11px]">
          {log.entity}
        </span>
      )
    },
    {
      header: "Audit Narrative / Record",
      accessorKey: "details",
      cell: (log: AuditLog) => <span className="text-slate-800 font-medium text-xs">{log.details}</span>
    },
    {
      header: "Executed By",
      accessorKey: "userName",
      cell: (log: AuditLog) => (
        <span className="font-semibold text-slate-700 text-xs flex items-center space-x-1">
          <User className="w-3 h-3 text-slate-400" />
          <span>{log.userName}</span>
        </span>
      )
    }
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <ShieldAlert className="w-5 h-5 text-blue-600" />
            <span>Database Security Audit Log Trail (Page 170)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX PL/SQL Autonomous Audit Trigger Stream: Recording every INSERT, UPDATE, DELETE, and administrative privilege escalation.
          </p>
        </div>
      </div>

      <InteractiveReport
        title="Audit Trail Log"
        data={auditLogs}
        columns={columns}
        searchPlaceholder="Search audit logs by action, table, details, or user..."
        searchFilterKeys={['action', 'entity', 'details', 'userName']}
      />
    </div>
  );
};
