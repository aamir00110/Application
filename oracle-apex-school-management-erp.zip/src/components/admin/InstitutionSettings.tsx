import React, { useState } from 'react';
import {
  Settings,
  Save,
  CheckCircle2,
  School,
  DollarSign,
  Calendar,
  Globe
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { ApexCard } from '../common/ApexCard';

export const InstitutionSettings: React.FC = () => {
  const { settings, updateSettings } = useSchool();
  const [form, setForm] = useState(settings);
  const [saved, setSaved] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings(form);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <Settings className="w-5 h-5 text-blue-600" />
            <span>Institution Profile & Global APEX Parameters (Page 160)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Global Application Items & Preferences: School name, currency symbol, grading scales, and academic session.
          </p>
        </div>

        <button
          onClick={handleSubmit}
          className="px-4 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center space-x-1.5 transition-colors"
        >
          <Save className="w-4 h-4" />
          <span>Save System Settings</span>
        </button>
      </div>

      {saved && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 flex items-center space-x-2 text-xs animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-bold">Settings saved successfully to Oracle APEX Global Configuration (TBL_SETTINGS).</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* School Profile */}
        <ApexCard title="Institution Identity" icon={<School className="w-4 h-4" />}>
          <div className="space-y-3 text-xs">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Institution Name</label>
              <input
                type="text"
                value={form.schoolName}
                onChange={e => setForm({ ...form, schoolName: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 font-bold"
              />
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">Street Address</label>
              <input
                type="text"
                value={form.address}
                onChange={e => setForm({ ...form, address: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold mb-1 text-slate-700">City / State</label>
                <input
                  type="text"
                  value={form.city}
                  onChange={e => setForm({ ...form, city: e.target.value })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1 text-slate-700">Phone</label>
                <input
                  type="text"
                  value={form.phone}
                  onChange={e => setForm({ ...form, phone: e.target.value })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold mb-1 text-slate-700">Email Address</label>
                <input
                  type="email"
                  value={form.email}
                  onChange={e => setForm({ ...form, email: e.target.value })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1 text-slate-700">Website URL</label>
                <input
                  type="text"
                  value={form.website}
                  onChange={e => setForm({ ...form, website: e.target.value })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>
        </ApexCard>

        {/* Global Academic & Financial Params */}
        <ApexCard title="Academic & Financial Defaults" icon={<Calendar className="w-4 h-4" />}>
          <div className="space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold mb-1 text-slate-700">Current Academic Session</label>
                <input
                  type="text"
                  value={form.currentAcademicSession}
                  onChange={e => setForm({ ...form, currentAcademicSession: e.target.value })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 font-mono font-bold"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1 text-slate-700">Currency Symbol</label>
                <input
                  type="text"
                  value={form.currencySymbol}
                  onChange={e => setForm({ ...form, currencySymbol: e.target.value })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 font-bold font-mono text-center"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">Grading System</label>
              <select
                value={form.gradingSystem}
                onChange={e => setForm({ ...form, gradingSystem: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                <option value="GPA_4_POINT">Standard 4.0 GPA Scale (A+, A, B, C, F)</option>
                <option value="PERCENTAGE">Direct Percentage (0-100%)</option>
                <option value="LETTER_GRADE">Letter Grade (A, B, C, D, F)</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">Attendance Minimum Threshold (%)</label>
              <input
                type="number"
                value={form.attendanceThresholdPercentage}
                onChange={e => setForm({ ...form, attendanceThresholdPercentage: Number(e.target.value) })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 font-bold"
              />
              <p className="text-[10px] text-slate-500 mt-1">
                Students below this percentage will be flagged as attendance defaulters for exam admit cards.
              </p>
            </div>
          </div>
        </ApexCard>
      </form>
    </div>
  );
};
