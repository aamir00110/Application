import React, { useState } from 'react';
import {
  Users,
  Shield,
  Plus,
  KeyRound,
  CheckCircle,
  XCircle,
  Lock,
  UserCheck
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { User, UserRole } from '../../types';
import { InteractiveReport, ColumnDef } from '../common/InteractiveReport';
import { ApexModal } from '../common/ApexModal';

export const UserRoleManager: React.FC = () => {
  const { allUsers, currentUser, addUser, toggleUserStatus, resetUserPassword } = useSchool();
  const [modalOpen, setModalOpen] = useState(false);
  const [resetModalOpen, setResetModalOpen] = useState(false);
  const [targetUser, setTargetUser] = useState<User | null>(null);
  const [newPassword, setNewPassword] = useState('Password123#');

  const [newUser, setNewUser] = useState({
    username: '',
    fullName: '',
    email: '',
    role: 'TEACHER' as UserRole,
    password: 'Password123#'
  });

  const columns: ColumnDef<User>[] = [
    {
      header: "User Details",
      accessorKey: "fullName",
      cell: (u: User) => (
        <div className="flex items-center space-x-3">
          <img
            src={u.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'}
            alt={u.fullName}
            className="w-8 h-8 rounded-full object-cover border border-slate-200"
          />
          <div>
            <div className="font-bold text-slate-900">{u.fullName}</div>
            <div className="text-[11px] text-slate-500 font-mono">@{u.username} • {u.email}</div>
          </div>
        </div>
      )
    },
    {
      header: "Role Authorization",
      accessorKey: "role",
      cell: (u: User) => {
        const roleColors: Record<UserRole, string> = {
          SUPER_ADMIN: 'bg-rose-100 text-rose-900 border-rose-200',
          SCHOOL_ADMIN: 'bg-purple-100 text-purple-900 border-purple-200',
          PRINCIPAL: 'bg-blue-100 text-blue-900 border-blue-200',
          TEACHER: 'bg-emerald-100 text-emerald-900 border-emerald-200',
          ACCOUNTANT: 'bg-amber-100 text-amber-900 border-amber-200',
          RECEPTIONIST: 'bg-cyan-100 text-cyan-900 border-cyan-200',
          STUDENT: 'bg-indigo-100 text-indigo-900 border-indigo-200',
          PARENT: 'bg-teal-100 text-teal-900 border-teal-200'
        };

        return (
          <span className={`px-2 py-0.5 rounded text-[11px] font-bold border font-mono ${roleColors[u.role]}`}>
            {u.role}
          </span>
        );
      }
    },
    {
      header: "Last Sign In",
      accessorKey: "lastLogin",
      cell: (u: User) => (
        <span className="text-[11px] text-slate-600 font-mono">{u.lastLogin || 'Never'}</span>
      )
    },
    {
      header: "Account State",
      accessorKey: "isActive",
      cell: (u: User) => (
        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
          u.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'
        }`}>
          {u.isActive ? 'Active' : 'Locked'}
        </span>
      )
    },
    {
      header: "Security Actions",
      align: "center",
      cell: (u: User) => {
        if (u.id === currentUser.id) {
          return <span className="text-slate-400 text-[10px]">Current Session</span>;
        }

        return (
          <div className="flex items-center justify-center space-x-1.5">
            <button
              onClick={() => toggleUserStatus(u.id)}
              className={`p-1 rounded ${u.isActive ? 'text-rose-600 hover:bg-rose-50' : 'text-emerald-600 hover:bg-emerald-50'}`}
              title={u.isActive ? 'Lock User' : 'Unlock User'}
            >
              {u.isActive ? <Lock className="w-3.5 h-3.5" /> : <CheckCircle className="w-3.5 h-3.5" />}
            </button>
            <button
              onClick={() => {
                setTargetUser(u);
                setResetModalOpen(true);
              }}
              className="p-1 text-blue-600 hover:bg-blue-50 rounded"
              title="Reset Credentials"
            >
              <KeyRound className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      }
    }
  ];

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUser.username.trim() || !newUser.fullName.trim()) return;

    addUser({
      username: newUser.username.toLowerCase(),
      fullName: newUser.fullName,
      email: newUser.email,
      role: newUser.role,
      password: newUser.password,
      isActive: true
    });

    setModalOpen(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <Shield className="w-5 h-5 text-blue-600" />
            <span>User Authentication & RBAC Permissions (Page 150)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Security Schema: Role schemes, password encryption hashes, and session access control.
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="px-3.5 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center space-x-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>Provision User Account</span>
        </button>
      </div>

      <InteractiveReport
        title="System Users"
        data={allUsers}
        columns={columns}
        searchPlaceholder="Search users by name, username, or role..."
        searchFilterKeys={['fullName', 'username', 'email', 'role']}
      />

      {/* Add User Modal */}
      <ApexModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Provision APEX User Account"
        subtitle="Insert user into Oracle APEX TBL_USERS"
      >
        <form onSubmit={handleSaveUser} className="space-y-3 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Username *</label>
              <input
                type="text"
                required
                value={newUser.username}
                onChange={e => setNewUser({ ...newUser, username: e.target.value })}
                placeholder="e.g. jsmith"
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Full Name *</label>
              <input
                type="text"
                required
                value={newUser.fullName}
                onChange={e => setNewUser({ ...newUser, fullName: e.target.value })}
                placeholder="e.g. John Smith"
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Email Address</label>
              <input
                type="email"
                value={newUser.email}
                onChange={e => setNewUser({ ...newUser, email: e.target.value })}
                placeholder="user@school.edu"
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Security Role *</label>
              <select
                value={newUser.role}
                onChange={e => setNewUser({ ...newUser, role: e.target.value as UserRole })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white font-bold"
              >
                <option value="SUPER_ADMIN">Super Admin (Full Root)</option>
                <option value="SCHOOL_ADMIN">School Admin</option>
                <option value="PRINCIPAL">Principal</option>
                <option value="TEACHER">Teacher / Faculty</option>
                <option value="ACCOUNTANT">Accountant / Bursar</option>
                <option value="RECEPTIONIST">Receptionist / Front Desk</option>
                <option value="STUDENT">Student</option>
                <option value="PARENT">Parent / Guardian</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700">Temporary Password</label>
            <input
              type="text"
              required
              value={newUser.password}
              onChange={e => setNewUser({ ...newUser, password: e.target.value })}
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 font-mono"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-bold bg-blue-600 hover:bg-blue-700 text-white rounded shadow-sm"
            >
              Provision Account
            </button>
          </div>
        </form>
      </ApexModal>

      {/* Password Reset Modal */}
      <ApexModal
        isOpen={resetModalOpen}
        onClose={() => setResetModalOpen(false)}
        title="Reset User Password"
        subtitle={`User: ${targetUser?.fullName} (@${targetUser?.username})`}
      >
        <div className="space-y-3 text-xs">
          <div>
            <label className="block font-semibold mb-1 text-slate-700">Set New Password</label>
            <input
              type="text"
              value={newPassword}
              onChange={e => setNewPassword(e.target.value)}
              className="w-full px-3 py-1.5 border border-slate-300 rounded font-mono"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setResetModalOpen(false)}
              className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={() => {
                if (targetUser) {
                  resetUserPassword(targetUser.id, newPassword);
                  alert(`Password updated for ${targetUser.username}`);
                  setResetModalOpen(false);
                }
              }}
              className="px-4 py-1.5 font-bold bg-blue-600 hover:bg-blue-700 text-white rounded shadow-sm"
            >
              Save New Password
            </button>
          </div>
        </div>
      </ApexModal>
    </div>
  );
};
