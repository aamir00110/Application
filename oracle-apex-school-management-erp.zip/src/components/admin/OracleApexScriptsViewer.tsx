import React, { useState } from 'react';
import {
  Database,
  Copy,
  Check,
  Code2,
  FileCode2,
  Cpu,
  Layers,
  Sparkles,
  ExternalLink,
  BookOpen,
  Terminal
} from 'lucide-react';
import {
  ORACLE_DDL_SCHEMA,
  ORACLE_PLSQL_PACKAGES,
  ORACLE_TRIGGERS,
  ORACLE_SAMPLE_DATA,
  APEX_APP_DEFINITION_GUIDE
} from '../../data/oracleApexScripts';

export const OracleApexScriptsViewer: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'DDL' | 'PACKAGES' | 'TRIGGERS' | 'SAMPLE_DATA' | 'APEX_PAGES'>('DDL');
  const [copied, setCopied] = useState(false);

  const scriptMap = {
    DDL: {
      title: "1. Oracle Database Schema DDL (Tables, Indexes, Foreign Keys, Sequences)",
      desc: "Run this script first in SQL Workshop > SQL Commands to create all 20+ tables, constraints, sequences, and indexes.",
      code: ORACLE_DDL_SCHEMA
    },
    PACKAGES: {
      title: "2. PL/SQL Stored Packages (PKG_SCHOOL_ENGINE & PKG_SCHOOL_SECURITY)",
      desc: "Full business logic engine for GPA calculation, batch fee invoicing, attendance aggregation, and sha256 authentication.",
      code: ORACLE_PLSQL_PACKAGES
    },
    TRIGGERS: {
      title: "3. Oracle Database Autonomous Audit & ID Triggers",
      desc: "Row-level triggers for automatic sequence key population and autonomous security audit trail logging.",
      code: ORACLE_TRIGGERS
    },
    SAMPLE_DATA: {
      title: "4. Seed & Initial Demonstration Data SQL Insert Script",
      desc: "Pre-populates academic sessions, classes, subjects, faculty staff, students, fees, and system users.",
      code: ORACLE_SAMPLE_DATA
    },
    APEX_PAGES: {
      title: "5. Oracle APEX Application Architecture & Page Construction Guide",
      desc: "Complete 42-page blueprint mapping APEX page numbers, region types, items, dynamic actions, and process bindings.",
      code: APEX_APP_DEFINITION_GUIDE
    }
  };

  const current = scriptMap[activeTab];

  const handleCopy = () => {
    navigator.clipboard.writeText(current.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <Database className="w-5 h-5 text-blue-600" />
            <span>Oracle APEX Full SQL DDL & PL/SQL Code Repository (Page 180)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Production-grade Oracle Database artifacts ready to copy-paste into Oracle SQL Developer or APEX SQL Workshop.
          </p>
        </div>

        <button
          onClick={handleCopy}
          className="px-4 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center space-x-2 transition-colors shrink-0"
        >
          {copied ? <Check className="w-4 h-4 text-white" /> : <Copy className="w-4 h-4" />}
          <span>{copied ? 'Copied to Clipboard!' : 'Copy Active SQL Script'}</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap border-b border-slate-200 gap-1">
        {[
          { id: 'DDL', label: '1. Schema DDL', icon: Database },
          { id: 'PACKAGES', label: '2. PL/SQL Packages', icon: Code2 },
          { id: 'TRIGGERS', label: '3. DB Triggers', icon: Cpu },
          { id: 'SAMPLE_DATA', label: '4. Sample Data', icon: Layers },
          { id: 'APEX_PAGES', label: '5. APEX Page Blueprint', icon: BookOpen }
        ].map(tab => {
          const Icon = tab.icon;
          const isSelected = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id as any);
                setCopied(false);
              }}
              className={`px-3.5 py-2 text-xs font-bold border-b-2 flex items-center space-x-1.5 transition-all ${
                isSelected
                  ? 'border-blue-600 text-blue-600 bg-blue-50/50'
                  : 'border-transparent text-slate-500 hover:text-slate-700'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Info Card */}
      <div className="p-4 bg-slate-900 text-white rounded-xl border border-slate-800 shadow-md space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-amber-300 font-mono flex items-center space-x-2">
            <Terminal className="w-4 h-4" />
            <span>{current.title}</span>
          </h3>
          <span className="text-[10px] font-mono text-slate-400">
            {current.code.split('\n').length} lines
          </span>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">{current.desc}</p>
      </div>

      {/* Code Editor Box */}
      <div className="relative rounded-xl border border-slate-800 bg-[#0f172a] shadow-xl overflow-hidden">
        <div className="flex items-center justify-between px-4 py-2 bg-slate-950/80 border-b border-slate-800 text-[11px] font-mono text-slate-400 select-none">
          <div className="flex items-center space-x-2">
            <div className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
            <div className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
            <span className="ml-2 font-bold text-slate-300">
              {activeTab === 'APEX_PAGES' ? 'APEX_PAGE_BLUEPRINT.md' : `${activeTab.toLowerCase()}_oracle_script.sql`}
            </span>
          </div>

          <button
            onClick={handleCopy}
            className="hover:text-white flex items-center space-x-1 transition-colors"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
        </div>

        <pre className="p-4 text-xs font-mono text-emerald-400/90 overflow-x-auto max-h-[550px] leading-relaxed select-text">
          <code>{current.code}</code>
        </pre>
      </div>
    </div>
  );
};
