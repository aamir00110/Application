import React, { useState } from 'react';
import {
  Award,
  Printer,
  Search,
  GraduationCap,
  Calendar,
  School,
  CheckCircle2
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { ApexCard } from '../common/ApexCard';

export const OfficialReportCards: React.FC = () => {
  const {
    students,
    classes,
    sections,
    subjects,
    examTypes,
    studentMarks,
    parents,
    getStudentAttendancePercentage,
    settings
  } = useSchool();

  const [selectedStudentId, setSelectedStudentId] = useState<string>(students[0]?.id || '');
  const [selectedExamId, setSelectedExamId] = useState<string>(examTypes[0]?.id || '');

  const student = students.find(s => s.id === selectedStudentId);
  const studentClass = classes.find(c => c.id === student?.classId);
  const studentSection = sections.find(sec => sec.id === student?.sectionId);
  const parent = parents.find(p => p.id === student?.parentId);
  const exam = examTypes.find(e => e.id === selectedExamId);

  // Student Marks for this Exam
  const marks = studentMarks.filter(
    m => m.studentId === selectedStudentId && m.examTypeId === selectedExamId
  );

  const totalObtained = marks.reduce((sum, m) => sum + m.marksObtained, 0);
  const totalMax = marks.reduce((sum, m) => sum + m.maxMarks, 0);
  const overallPct = totalMax > 0 ? Math.round((totalObtained / totalMax) * 100) : 0;
  const overallGpa = marks.length > 0
    ? (marks.reduce((sum, m) => sum + m.gpa, 0) / marks.length).toFixed(2)
    : '0.00';

  const attPct = student ? getStudentAttendancePercentage(student.id) : 100;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Control Bar (hidden during print) */}
      <div className="no-print flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
        <div className="flex flex-wrap items-center gap-3 text-xs flex-1">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Select Student</label>
            <select
              value={selectedStudentId}
              onChange={e => setSelectedStudentId(e.target.value)}
              className="px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 font-medium bg-white"
            >
              {students.map(s => {
                const c = classes.find(cls => cls.id === s.classId);
                return (
                  <option key={s.id} value={s.id}>
                    {s.fullName} ({c?.name} • Roll {s.rollNo})
                  </option>
                );
              })}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Examination Term</label>
            <select
              value={selectedExamId}
              onChange={e => setSelectedExamId(e.target.value)}
              className="px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 font-medium bg-white"
            >
              {examTypes.map(e => (
                <option key={e.id} value={e.id}>{e.name}</option>
              ))}
            </select>
          </div>
        </div>

        <button
          id="btn-print-report-card"
          onClick={handlePrint}
          className="px-4 py-2 text-xs font-bold bg-slate-900 hover:bg-slate-800 text-white rounded-lg shadow-sm flex items-center space-x-2 transition-colors shrink-0"
        >
          <Printer className="w-4 h-4" />
          <span>Print Official Transcript</span>
        </button>
      </div>

      {/* Official Report Card Printable Canvas */}
      {student && (
        <div
          id="official-report-card"
          className="bg-white rounded-xl border border-slate-300 shadow-lg p-8 max-w-4xl mx-auto space-y-6 print:shadow-none print:border-none print:p-0 print:m-0"
        >
          {/* Official Letterhead Header */}
          <div className="text-center pb-5 border-b-2 border-slate-900 relative">
            <div className="flex items-center justify-center space-x-3 mb-1">
              <div className="w-12 h-12 rounded-lg bg-blue-900 text-amber-300 flex items-center justify-center font-black text-2xl shadow-sm">
                <School className="w-8 h-8" />
              </div>
              <div className="text-left">
                <h1 className="text-2xl font-black tracking-tight text-slate-900 uppercase">
                  {settings.schoolName}
                </h1>
                <p className="text-xs text-slate-600 font-medium tracking-wide">
                  {settings.address}, {settings.city} • Contact: {settings.phone} • {settings.email}
                </p>
              </div>
            </div>
            <div className="mt-3 inline-block px-4 py-1 bg-slate-900 text-white text-xs font-black uppercase tracking-widest rounded-full">
              Official Academic Transcript & Progress Report
            </div>
            <p className="text-xs font-bold text-blue-900 mt-1">
              {exam?.name} — Academic Session {settings.currentAcademicSession}
            </p>
          </div>

          {/* Student & Guardian Particulars */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-slate-50 rounded-lg border border-slate-200 text-xs">
            <div>
              <span className="text-slate-500 text-[10px] uppercase font-bold">Student Name</span>
              <p className="font-bold text-slate-900 text-sm">{student.fullName}</p>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] uppercase font-bold">Admission ID</span>
              <p className="font-mono font-bold text-blue-800">{student.admissionNo}</p>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] uppercase font-bold">Class & Section</span>
              <p className="font-bold text-slate-900">{studentClass?.name} ({studentSection?.name})</p>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] uppercase font-bold">Roll Number</span>
              <p className="font-mono font-bold text-slate-900">{student.rollNo}</p>
            </div>

            <div>
              <span className="text-slate-500 text-[10px] uppercase font-bold">Father / Guardian</span>
              <p className="font-medium text-slate-800">{parent?.fatherName || 'Guardian'}</p>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] uppercase font-bold">Date of Birth</span>
              <p className="font-medium text-slate-800">{student.dateOfBirth}</p>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] uppercase font-bold">Term Attendance</span>
              <p className="font-bold text-emerald-700">{attPct}% (Official Days)</p>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] uppercase font-bold">Result Status</span>
              <p className="font-bold text-emerald-700 uppercase">
                {overallPct >= 40 ? 'PASSED / PROMOTED' : 'FAILED'}
              </p>
            </div>
          </div>

          {/* Marks Breakdown Table */}
          <div>
            <table className="w-full text-left text-xs border-collapse border border-slate-300">
              <thead>
                <tr className="bg-slate-800 text-white font-bold">
                  <th className="p-2.5 border border-slate-600">Subject Name</th>
                  <th className="p-2.5 border border-slate-600 font-mono">Code</th>
                  <th className="p-2.5 border border-slate-600 text-center">Max Marks</th>
                  <th className="p-2.5 border border-slate-600 text-center">Marks Obtained</th>
                  <th className="p-2.5 border border-slate-600 text-center">Percentage</th>
                  <th className="p-2.5 border border-slate-600 text-center">Grade</th>
                  <th className="p-2.5 border border-slate-600 text-center">GPA</th>
                  <th className="p-2.5 border border-slate-600">Remarks</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-slate-800">
                {marks.length > 0 ? (
                  marks.map(m => {
                    const sub = subjects.find(s => s.id === m.subjectId);
                    const pct = Math.round((m.marksObtained / m.maxMarks) * 100);
                    return (
                      <tr key={m.id} className="hover:bg-slate-50">
                        <td className="p-2.5 border border-slate-300 font-bold">{sub?.name}</td>
                        <td className="p-2.5 border border-slate-300 font-mono text-slate-600">{sub?.code}</td>
                        <td className="p-2.5 border border-slate-300 text-center font-mono">{m.maxMarks}</td>
                        <td className="p-2.5 border border-slate-300 text-center font-mono font-bold text-blue-900">{m.marksObtained}</td>
                        <td className="p-2.5 border border-slate-300 text-center font-mono">{pct}%</td>
                        <td className="p-2.5 border border-slate-300 text-center font-bold font-mono">{m.grade}</td>
                        <td className="p-2.5 border border-slate-300 text-center font-mono font-bold">{m.gpa.toFixed(2)}</td>
                        <td className="p-2.5 border border-slate-300 italic text-[11px] text-slate-600">{m.remarks || 'Satisfactory'}</td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={8} className="p-6 text-center text-slate-400 italic">
                      No examination marks uploaded for this student.
                    </td>
                  </tr>
                )}
              </tbody>
              <tfoot>
                <tr className="bg-slate-100 font-bold text-slate-900 border-t-2 border-slate-400">
                  <td colSpan={2} className="p-2.5 border border-slate-300 uppercase">Cumulative Aggregate</td>
                  <td className="p-2.5 border border-slate-300 text-center font-mono">{totalMax}</td>
                  <td className="p-2.5 border border-slate-300 text-center font-mono text-blue-900">{totalObtained}</td>
                  <td className="p-2.5 border border-slate-300 text-center font-mono text-emerald-700">{overallPct}%</td>
                  <td className="p-2.5 border border-slate-300 text-center font-mono font-black text-blue-900">
                    {overallPct >= 80 ? 'A+' : overallPct >= 70 ? 'A' : overallPct >= 60 ? 'B' : 'C'}
                  </td>
                  <td className="p-2.5 border border-slate-300 text-center font-mono font-black text-blue-900">{overallGpa}</td>
                  <td className="p-2.5 border border-slate-300 text-emerald-700">Excellent Standing</td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Grading Scale Guide & Comments */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="p-3 bg-slate-50 rounded border border-slate-200 space-y-1">
              <span className="font-bold text-slate-800 uppercase tracking-wide text-[10px]">Official Grading Scale</span>
              <div className="grid grid-cols-4 gap-1 text-[10px] font-mono text-slate-600 pt-1">
                <div>A+ : 80-100% (4.0)</div>
                <div>A : 70-79% (3.7)</div>
                <div>B : 60-69% (3.0)</div>
                <div>C : 50-59% (2.0)</div>
              </div>
            </div>

            <div className="p-3 bg-blue-50 rounded border border-blue-100 space-y-1">
              <span className="font-bold text-blue-900 uppercase tracking-wide text-[10px]">Principal's Endorsement</span>
              <p className="text-[11px] text-blue-800 italic">
                "{student.fullName} has demonstrated commendable academic performance and leadership potential across all subject disciplines."
              </p>
            </div>
          </div>

          {/* Signature Boxes */}
          <div className="pt-12 grid grid-cols-3 gap-8 text-center text-xs text-slate-700">
            <div className="border-t border-slate-400 pt-1.5">
              <p className="font-bold">Class Teacher</p>
              <p className="text-[10px] text-slate-500">Signature & Date</p>
            </div>
            <div className="border-t border-slate-400 pt-1.5">
              <p className="font-bold">Controller of Examinations</p>
              <p className="text-[10px] text-slate-500">Official Seal</p>
            </div>
            <div className="border-t border-slate-400 pt-1.5">
              <p className="font-bold">Principal / Head of Institution</p>
              <p className="text-[10px] text-slate-500">{settings.schoolName}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
