import React, { useState, useEffect } from 'react';
import {
  FileText,
  Save,
  CheckCircle2,
  Award,
  Sparkles,
  Calculator,
  AlertCircle
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { calculateGradeAndGPA } from '../../data/initialData';

export const BulkMarksEntry: React.FC = () => {
  const { classes, sections, subjects, examTypes, students, studentMarks, saveBulkMarks } = useSchool();

  const [selectedExamId, setSelectedExamId] = useState<string>(examTypes[0]?.id || '');
  const [selectedClassId, setSelectedClassId] = useState<string>(classes[0]?.id || '');
  const [selectedSectionId, setSelectedSectionId] = useState<string>(sections[0]?.id || '');
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>(subjects[0]?.id || '');

  // Map of studentId -> marksObtained, remarks
  const [marksState, setMarksState] = useState<Record<string, { marksObtained: number; remarks: string }>>({});
  const [savedSuccess, setSavedSuccess] = useState(false);

  const currentSubject = subjects.find(s => s.id === selectedSubjectId);
  const maxMarks = currentSubject?.totalMarks || 100;

  // Filter students in selected class & section
  const cohortStudents = students.filter(
    s => s.classId === selectedClassId && s.sectionId === selectedSectionId && s.status === 'ACTIVE'
  );

  // Load existing marks into state
  useEffect(() => {
    const nextState: Record<string, { marksObtained: number; remarks: string }> = {};

    cohortStudents.forEach(s => {
      const existing = studentMarks.find(
        m => m.studentId === s.id && m.examTypeId === selectedExamId && m.subjectId === selectedSubjectId
      );
      if (existing) {
        nextState[s.id] = { marksObtained: existing.marksObtained, remarks: existing.remarks || '' };
      } else {
        nextState[s.id] = { marksObtained: 75, remarks: '' };
      }
    });

    setMarksState(nextState);
    setSavedSuccess(false);
  }, [selectedExamId, selectedClassId, selectedSectionId, selectedSubjectId, students, studentMarks]);

  const handleMarksChange = (studentId: string, val: number) => {
    const clamped = Math.max(0, Math.min(maxMarks, val));
    setMarksState(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        marksObtained: clamped
      }
    }));
  };

  const handleRemarksChange = (studentId: string, remarks: string) => {
    setMarksState(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        remarks
      }
    }));
  };

  const handleSave = () => {
    const records = cohortStudents.map(s => {
      const obtained = marksState[s.id]?.marksObtained ?? 75;
      const { grade, gpa } = calculateGradeAndGPA(obtained, maxMarks);

      return {
        studentId: s.id,
        examTypeId: selectedExamId,
        subjectId: selectedSubjectId,
        marksObtained: obtained,
        maxMarks: maxMarks,
        grade,
        gpa,
        remarks: marksState[s.id]?.remarks || undefined
      };
    });

    saveBulkMarks(records);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <FileText className="w-5 h-5 text-blue-600" />
            <span>Bulk Examination Marks Entry Sheet (Page 61)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Dynamic Spreadsheet: Real-time PL/SQL GPA calculation trigger on tabular score update.
          </p>
        </div>

        <button
          id="btn-save-marks"
          onClick={handleSave}
          disabled={cohortStudents.length === 0}
          className="px-4 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-lg shadow-sm flex items-center space-x-2 transition-colors"
        >
          <Save className="w-4 h-4" />
          <span>Save & Compute Grades</span>
        </button>
      </div>

      {savedSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 flex items-center space-x-2 text-xs animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-bold">Exam marks recorded! Grades and GPAs recalculated by Oracle DB trigger.</span>
        </div>
      )}

      {/* Filter Bar */}
      <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
        <div>
          <label className="block font-semibold mb-1 text-slate-700">Exam Term *</label>
          <select
            value={selectedExamId}
            onChange={e => setSelectedExamId(e.target.value)}
            className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white font-medium"
          >
            {examTypes.map(e => (
              <option key={e.id} value={e.id}>{e.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block font-semibold mb-1 text-slate-700">Class *</label>
          <select
            value={selectedClassId}
            onChange={e => {
              const newCId = e.target.value;
              setSelectedClassId(newCId);
              const sec = sections.find(s => s.classId === newCId);
              setSelectedSectionId(sec?.id || '');
            }}
            className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white font-medium"
          >
            {classes.map(c => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block font-semibold mb-1 text-slate-700">Section *</label>
          <select
            value={selectedSectionId}
            onChange={e => setSelectedSectionId(e.target.value)}
            className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
          >
            {sections.filter(s => s.classId === selectedClassId).map(s => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block font-semibold mb-1 text-slate-700">Subject *</label>
          <select
            value={selectedSubjectId}
            onChange={e => setSelectedSubjectId(e.target.value)}
            className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white font-medium"
          >
            {subjects.map(s => (
              <option key={s.id} value={s.id}>{s.name} (Max: {s.totalMarks})</option>
            ))}
          </select>
        </div>
      </div>

      {/* Marks Sheet Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 select-none">
              <th className="p-3 w-16">Roll</th>
              <th className="p-3">Student Name</th>
              <th className="p-3">Admission ID</th>
              <th className="p-3 w-32 text-center">Marks Obtained (Max: {maxMarks})</th>
              <th className="p-3 w-20 text-center">Percentage</th>
              <th className="p-3 w-20 text-center">Grade</th>
              <th className="p-3 w-20 text-center">GPA</th>
              <th className="p-3">Teacher Remarks</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-800">
            {cohortStudents.length > 0 ? (
              cohortStudents.map(student => {
                const obtained = marksState[student.id]?.marksObtained ?? 0;
                const remarks = marksState[student.id]?.remarks || '';
                const { grade, gpa } = calculateGradeAndGPA(obtained, maxMarks);
                const pct = Math.round((obtained / maxMarks) * 100);

                return (
                  <tr key={student.id} className="hover:bg-slate-50 transition-colors">
                    <td className="p-3 font-mono font-bold text-slate-700">{student.rollNo}</td>
                    <td className="p-3 font-bold text-slate-900">{student.fullName}</td>
                    <td className="p-3 font-mono text-blue-700">{student.admissionNo}</td>
                    <td className="p-3 text-center">
                      <input
                        type="number"
                        min={0}
                        max={maxMarks}
                        value={obtained}
                        onChange={e => handleMarksChange(student.id, Number(e.target.value))}
                        className="w-24 px-2 py-1 text-center font-bold font-mono border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
                      />
                    </td>
                    <td className="p-3 text-center font-mono font-bold text-slate-700">
                      {pct}%
                    </td>
                    <td className="p-3 text-center">
                      <span className={`px-2 py-0.5 rounded font-bold font-mono text-[11px] ${
                        grade === 'A+' || grade === 'A'
                          ? 'bg-emerald-100 text-emerald-800'
                          : grade === 'B'
                          ? 'bg-blue-100 text-blue-800'
                          : grade === 'C'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}>
                        {grade}
                      </span>
                    </td>
                    <td className="p-3 text-center font-mono font-bold text-slate-900">
                      {gpa.toFixed(2)}
                    </td>
                    <td className="p-3">
                      <input
                        type="text"
                        value={remarks}
                        onChange={e => handleRemarksChange(student.id, e.target.value)}
                        placeholder="e.g. Excellent analytical thinking"
                        className="w-full px-2 py-1 border border-slate-200 rounded focus:ring-1 focus:ring-blue-500"
                      />
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={8} className="p-8 text-center text-slate-400 italic">
                  No active students found in this cohort.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
