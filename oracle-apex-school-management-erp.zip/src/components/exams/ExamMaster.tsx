import React, { useState } from 'react';
import {
  Award,
  Plus,
  Calendar,
  FileCheck,
  Percent
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { ExamType } from '../../types';
import { InteractiveReport, ColumnDef } from '../common/InteractiveReport';
import { ApexModal } from '../common/ApexModal';

export const ExamMaster: React.FC = () => {
  const { examTypes, addExamType } = useSchool();
  const [modalOpen, setModalOpen] = useState(false);

  const [newExam, setNewExam] = useState({
    name: '',
    academicSessionId: 'SES-2026',
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(Date.now() + 86400000 * 10).toISOString().split('T')[0],
    weightagePercent: 40,
    status: 'UPCOMING' as any
  });

  const columns: ColumnDef<ExamType>[] = [
    {
      header: "Examination Name",
      accessorKey: "name",
      cell: (e: ExamType) => (
        <div>
          <div className="font-bold text-slate-900">{e.name}</div>
          <div className="text-[11px] text-slate-500 font-mono">ID: {e.id}</div>
        </div>
      )
    },
    {
      header: "Schedule Period",
      cell: (e: ExamType) => (
        <span className="text-slate-800 font-medium">
          {e.startDate} <span className="text-slate-400">to</span> {e.endDate}
        </span>
      )
    },
    {
      header: "Weightage",
      accessorKey: "weightagePercent",
      align: "center",
      cell: (e: ExamType) => (
        <span className="font-mono font-bold bg-blue-50 text-blue-700 px-2 py-0.5 rounded border border-blue-100">
          {e.weightagePercent}% of Annual Grade
        </span>
      )
    },
    {
      header: "Status",
      accessorKey: "status",
      cell: (e: ExamType) => (
        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
          e.status === 'COMPLETED' || e.status === 'RESULTS_PUBLISHED'
            ? 'bg-emerald-100 text-emerald-800'
            : e.status === 'ONGOING'
            ? 'bg-blue-100 text-blue-800'
            : 'bg-amber-100 text-amber-800'
        }`}>
          {e.status}
        </span>
      )
    }
  ];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newExam.name.trim()) {
      alert("Please provide Exam Name.");
      return;
    }
    addExamType(newExam);
    setModalOpen(false);
    setNewExam({
      name: '',
      code: '',
      academicSessionId: 'SES-2026',
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date(Date.now() + 86400000 * 10).toISOString().split('T')[0],
      weightagePercentage: 40,
      status: 'ACTIVE'
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <Award className="w-5 h-5 text-blue-600" />
            <span>Examinations Master Setup (Page 60)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Exam Definitions: Assessment terms, date schedules, and grade weighting rules.
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="px-3.5 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center space-x-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>Create Examination</span>
        </button>
      </div>

      <InteractiveReport
        title="Examinations List"
        data={examTypes}
        columns={columns}
        searchPlaceholder="Search exams..."
        searchFilterKeys={['name', 'status']}
      />

      <ApexModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Create Examination Assessment"
        subtitle="Record examination in Oracle APEX TBL_EXAM_TYPES"
      >
        <form onSubmit={handleSave} className="space-y-3 text-xs">
          <div>
            <label className="block font-semibold mb-1 text-slate-700">Exam Title *</label>
            <input
              type="text"
              required
              value={newExam.name}
              onChange={e => setNewExam({ ...newExam, name: e.target.value })}
              placeholder="e.g. Midterm Examination 2026"
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Exam Code *</label>
              <input
                type="text"
                required
                value={newExam.code}
                onChange={e => setNewExam({ ...newExam, code: e.target.value })}
                placeholder="e.g. MID-2026"
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Weightage (%) *</label>
              <input
                type="number"
                required
                min={1}
                max={100}
                value={newExam.weightagePercentage}
                onChange={e => setNewExam({ ...newExam, weightagePercentage: Number(e.target.value) })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Start Date *</label>
              <input
                type="date"
                required
                value={newExam.startDate}
                onChange={e => setNewExam({ ...newExam, startDate: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">End Date *</label>
              <input
                type="date"
                required
                value={newExam.endDate}
                onChange={e => setNewExam({ ...newExam, endDate: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-bold bg-blue-600 hover:bg-blue-700 text-white rounded shadow-sm"
            >
              Save Examination
            </button>
          </div>
        </form>
      </ApexModal>
    </div>
  );
};
