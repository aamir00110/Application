import React, { useState } from 'react';
import {
  Users,
  Phone,
  Mail,
  MapPin,
  GraduationCap,
  Plus,
  Search,
  Briefcase
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { Parent, Student } from '../../types';
import { InteractiveReport, ColumnDef } from '../common/InteractiveReport';
import { ApexModal } from '../common/ApexModal';

export const ParentDirectory: React.FC = () => {
  const { parents, students, addParent, classes } = useSchool();
  const [modalOpen, setModalOpen] = useState(false);
  const [newParent, setNewParent] = useState({
    fatherName: '',
    motherName: '',
    fatherOccupation: '',
    motherOccupation: '',
    primaryPhone: '',
    email: '',
    cnicBForm: '',
    address: '',
    emergencyContact: '',
    emergencyPhone: ''
  });

  const columns: ColumnDef<Parent>[] = [
    {
      header: "Father / Guardian",
      accessorKey: "fatherName",
      cell: (p: Parent) => (
        <div>
          <div className="font-bold text-slate-900">{p.fatherName}</div>
          <div className="text-[11px] text-slate-500 flex items-center space-x-1">
            <Briefcase className="w-3 h-3 text-slate-400" />
            <span>{p.fatherOccupation || 'Private Business'}</span>
          </div>
        </div>
      )
    },
    {
      header: "Mother's Name",
      accessorKey: "motherName",
      cell: (p: Parent) => (
        <span className="font-medium text-slate-700">{p.motherName || 'N/A'}</span>
      )
    },
    {
      header: "Contact Info",
      accessorKey: "primaryPhone",
      cell: (p: Parent) => (
        <div>
          <div className="flex items-center space-x-1 text-slate-800 font-medium">
            <Phone className="w-3 h-3 text-blue-600" />
            <span>{p.primaryPhone}</span>
          </div>
          <div className="text-[11px] text-slate-500">{p.email}</div>
        </div>
      )
    },
    {
      header: "CNIC / Identity",
      accessorKey: "cnicBForm",
      cell: (p: Parent) => (
        <span className="font-mono text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded text-[11px]">
          {p.cnicBForm}
        </span>
      )
    },
    {
      header: "Enrolled Wards / Students",
      cell: (p: Parent) => {
        const wards = students.filter(s => s.parentId === p.id);
        return (
          <div className="flex flex-wrap gap-1">
            {wards.length > 0 ? (
              wards.map(w => {
                const c = classes.find(cls => cls.id === w.classId);
                return (
                  <span
                    key={w.id}
                    className="inline-flex items-center space-x-1 px-2 py-0.5 bg-blue-50 text-blue-700 rounded-md border border-blue-200 text-[10px] font-semibold"
                  >
                    <GraduationCap className="w-3 h-3" />
                    <span>{w.fullName} ({c?.name})</span>
                  </span>
                );
              })
            ) : (
              <span className="text-slate-400 italic text-[11px]">No active wards</span>
            )}
          </div>
        );
      }
    },
    {
      header: "Address / City",
      accessorKey: "address",
      cell: (p: Parent) => (
        <span className="text-[11px] text-slate-600 truncate max-w-[200px] block">
          {p.address}
        </span>
      )
    }
  ];

  const handleSaveParent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newParent.fatherName || !newParent.primaryPhone) {
      alert("Please provide Father's Name and Primary Phone Number.");
      return;
    }

    addParent({
      fatherName: newParent.fatherName,
      motherName: newParent.motherName,
      fatherOccupation: newParent.fatherOccupation,
      motherOccupation: newParent.motherOccupation,
      primaryPhone: newParent.primaryPhone,
      email: newParent.email,
      cnicBForm: newParent.cnicBForm || '35202-0000000-0',
      address: newParent.address,
      emergencyContact: newParent.emergencyContact || newParent.fatherName,
      emergencyPhone: newParent.emergencyPhone || newParent.primaryPhone
    });

    setModalOpen(false);
    setNewParent({
      fatherName: '',
      motherName: '',
      fatherOccupation: '',
      motherOccupation: '',
      primaryPhone: '',
      email: '',
      cnicBForm: '',
      address: '',
      emergencyContact: '',
      emergencyPhone: ''
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <Users className="w-5 h-5 text-blue-600" />
            <span>Parent & Guardian Registry (Page 20)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Family profiles linked with enrolled students, contact channels, and fee guarantors.
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="px-3.5 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm transition-colors flex items-center space-x-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>Add Parent Profile</span>
        </button>
      </div>

      <InteractiveReport
        title="Parents Directory"
        data={parents}
        columns={columns}
        searchPlaceholder="Search by Father Name, Phone, Ward, or CNIC..."
        searchFilterKeys={['fatherName', 'motherName', 'primaryPhone', 'email', 'cnicBForm']}
      />

      {/* Add Parent Modal */}
      <ApexModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Add New Parent / Guardian"
        subtitle="Register guardian identity into Oracle APEX TBL_PARENTS"
      >
        <form onSubmit={handleSaveParent} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Father's Full Name *</label>
              <input
                type="text"
                required
                value={newParent.fatherName}
                onChange={e => setNewParent({ ...newParent, fatherName: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Mother's Full Name</label>
              <input
                type="text"
                value={newParent.motherName}
                onChange={e => setNewParent({ ...newParent, motherName: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Primary Phone *</label>
              <input
                type="tel"
                required
                value={newParent.primaryPhone}
                onChange={e => setNewParent({ ...newParent, primaryPhone: e.target.value })}
                placeholder="+1 (555) 000-0000"
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Email Address</label>
              <input
                type="email"
                value={newParent.email}
                onChange={e => setNewParent({ ...newParent, email: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Father's Occupation</label>
              <input
                type="text"
                value={newParent.fatherOccupation}
                onChange={e => setNewParent({ ...newParent, fatherOccupation: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">CNIC / ID Card</label>
              <input
                type="text"
                value={newParent.cnicBForm}
                onChange={e => setNewParent({ ...newParent, cnicBForm: e.target.value })}
                placeholder="35202-XXXXXXX-X"
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block font-semibold mb-1 text-slate-700">Residential Address</label>
              <input
                type="text"
                value={newParent.address}
                onChange={e => setNewParent({ ...newParent, address: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-bold bg-blue-600 hover:bg-blue-700 text-white rounded shadow-sm"
            >
              Save Parent
            </button>
          </div>
        </form>
      </ApexModal>
    </div>
  );
};
