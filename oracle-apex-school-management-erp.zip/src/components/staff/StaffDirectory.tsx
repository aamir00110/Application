import React, { useState } from 'react';
import {
  Briefcase,
  Plus,
  Phone,
  Mail,
  Calendar,
  DollarSign,
  UserCheck,
  CheckCircle,
  Clock,
  Layers
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { Staff } from '../../types';
import { InteractiveReport, ColumnDef } from '../common/InteractiveReport';
import { ApexModal } from '../common/ApexModal';

export const StaffDirectory: React.FC = () => {
  const { staff, addStaff, settings, currentUser } = useSchool();
  const [modalOpen, setModalOpen] = useState(false);

  const [newStaff, setNewStaff] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '+1 (555) 333-1122',
    designation: 'Senior Faculty',
    department: 'ACADEMICS' as any,
    joiningDate: new Date().toISOString().split('T')[0],
    qualification: 'M.Sc. Mathematics',
    basicSalary: 65000,
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80'
  });

  const columns: ColumnDef<Staff>[] = [
    {
      header: "Staff Member",
      accessorKey: "fullName",
      cell: (s: Staff) => (
        <div className="flex items-center space-x-3">
          <img
            src={s.avatarUrl || 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80'}
            alt={s.fullName}
            className="w-9 h-9 rounded-full object-cover border border-slate-200"
          />
          <div>
            <div className="font-bold text-slate-900">{s.fullName}</div>
            <div className="text-[11px] text-slate-500 font-medium">
              {s.designation} • <span className="text-blue-600">{s.department}</span>
            </div>
          </div>
        </div>
      )
    },
    {
      header: "Employee ID",
      accessorKey: "employeeNo",
      cell: (s: Staff) => (
        <span className="font-mono font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded text-[11px]">
          {s.employeeNo}
        </span>
      )
    },
    {
      header: "Qualification",
      accessorKey: "qualification",
      cell: (s: Staff) => <span className="font-medium text-slate-700">{s.qualification}</span>
    },
    {
      header: "Contact Info",
      accessorKey: "phone",
      cell: (s: Staff) => (
        <div>
          <div className="text-slate-800 font-medium">{s.phone}</div>
          <div className="text-[11px] text-slate-500">{s.email}</div>
        </div>
      )
    },
    {
      header: "Basic Salary",
      accessorKey: "basicSalary",
      cell: (s: Staff) => (
        <span className="font-mono font-bold text-slate-900">
          {settings.currencySymbol}{s.basicSalary.toLocaleString()}
        </span>
      )
    },
    {
      header: "Status",
      accessorKey: "status",
      cell: (s: Staff) => (
        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
          s.status === 'ACTIVE'
            ? 'bg-emerald-100 text-emerald-800'
            : 'bg-amber-100 text-amber-800'
        }`}>
          {s.status}
        </span>
      )
    }
  ];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStaff.firstName.trim() || !newStaff.lastName.trim() || !newStaff.email.trim()) {
      alert("Please provide First Name, Last Name, and Email.");
      return;
    }

    addStaff({
      firstName: newStaff.firstName,
      lastName: newStaff.lastName,
      fullName: `${newStaff.firstName} ${newStaff.lastName}`,
      email: newStaff.email,
      phone: newStaff.phone,
      designation: newStaff.designation,
      department: newStaff.department,
      joiningDate: newStaff.joiningDate,
      qualification: newStaff.qualification,
      basicSalary: newStaff.basicSalary,
      status: 'ACTIVE',
      avatarUrl: newStaff.avatarUrl
    });

    setModalOpen(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <Briefcase className="w-5 h-5 text-blue-600" />
            <span>Faculty & Staff HR Registry (Page 40)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Personnel Master: Faculty credentials, salary structure, contract status, and department heads.
          </p>
        </div>

        {['SUPER_ADMIN', 'SCHOOL_ADMIN', 'PRINCIPAL'].includes(currentUser.role) && (
          <button
            onClick={() => setModalOpen(true)}
            className="px-3.5 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center space-x-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Add Staff Member</span>
          </button>
        )}
      </div>

      <InteractiveReport
        title="Staff Directory"
        data={staff}
        columns={columns}
        searchPlaceholder="Search staff by Name, Emp No, Designation, or Dept..."
        searchFilterKeys={['fullName', 'employeeNo', 'designation', 'department', 'qualification', 'email']}
      />

      <ApexModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Enroll Faculty / Staff Member"
        subtitle="Register personnel record in Oracle APEX TBL_STAFF"
      >
        <form onSubmit={handleSave} className="space-y-3 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">First Name *</label>
              <input
                type="text"
                required
                value={newStaff.firstName}
                onChange={e => setNewStaff({ ...newStaff, firstName: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Last Name *</label>
              <input
                type="text"
                required
                value={newStaff.lastName}
                onChange={e => setNewStaff({ ...newStaff, lastName: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Email Address *</label>
              <input
                type="email"
                required
                value={newStaff.email}
                onChange={e => setNewStaff({ ...newStaff, email: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Phone Number *</label>
              <input
                type="tel"
                required
                value={newStaff.phone}
                onChange={e => setNewStaff({ ...newStaff, phone: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Designation *</label>
              <input
                type="text"
                required
                value={newStaff.designation}
                onChange={e => setNewStaff({ ...newStaff, designation: e.target.value })}
                placeholder="e.g. Physics Lecturer"
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Department *</label>
              <select
                value={newStaff.department}
                onChange={e => setNewStaff({ ...newStaff, department: e.target.value as any })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                <option value="ACADEMICS">Academics</option>
                <option value="ADMINISTRATION">Administration</option>
                <option value="ACCOUNTS">Accounts & Finance</option>
                <option value="SPORTS">Sports & Physical Ed</option>
                <option value="SUPPORT">Support Staff</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Qualification</label>
              <input
                type="text"
                value={newStaff.qualification}
                onChange={e => setNewStaff({ ...newStaff, qualification: e.target.value })}
                placeholder="e.g. M.Phil Physics"
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Basic Monthly Salary ({settings.currencySymbol})</label>
              <input
                type="number"
                value={newStaff.basicSalary}
                onChange={e => setNewStaff({ ...newStaff, basicSalary: Number(e.target.value) })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-bold bg-blue-600 hover:bg-blue-700 text-white rounded shadow-sm"
            >
              Save Employee
            </button>
          </div>
        </form>
      </ApexModal>
    </div>
  );
};
