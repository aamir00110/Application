import React, { useState } from 'react';
import {
  CalendarDays,
  Plus,
  CheckCircle,
  XCircle,
  Clock,
  UserCheck,
  FileText
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { StaffLeave } from '../../types';
import { InteractiveReport, ColumnDef } from '../common/InteractiveReport';
import { ApexModal } from '../common/ApexModal';

export const StaffLeaveManager: React.FC = () => {
  const { staffLeaves, staff, addStaffLeave, updateStaffLeaveStatus, currentUser } = useSchool();
  const [modalOpen, setModalOpen] = useState(false);

  const [newLeave, setNewLeave] = useState({
    staffId: staff[0]?.id || '',
    leaveType: 'CASUAL' as any,
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0],
    reason: 'Family event / Personal matter'
  });

  const columns: ColumnDef<StaffLeave>[] = [
    {
      header: "Staff Member",
      cell: (l: StaffLeave) => {
        const s = staff.find(st => st.id === l.staffId);
        return (
          <div>
            <div className="font-bold text-slate-900">{s?.fullName || 'Staff'}</div>
            <div className="text-[11px] text-slate-500">{s?.designation} • {s?.department}</div>
          </div>
        );
      }
    },
    {
      header: "Leave Type",
      accessorKey: "leaveType",
      cell: (l: StaffLeave) => (
        <span className="font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded text-[11px]">
          {l.leaveType}
        </span>
      )
    },
    {
      header: "Duration Period",
      cell: (l: StaffLeave) => (
        <span className="text-slate-800 font-medium">
          {l.startDate} <span className="text-slate-400">to</span> {l.endDate}
        </span>
      )
    },
    {
      header: "Reason",
      accessorKey: "reason",
      cell: (l: StaffLeave) => <span className="text-slate-600 italic text-[11px]">{l.reason}</span>
    },
    {
      header: "Approval Status",
      accessorKey: "status",
      cell: (l: StaffLeave) => (
        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
          l.status === 'APPROVED'
            ? 'bg-emerald-100 text-emerald-800'
            : l.status === 'REJECTED'
            ? 'bg-rose-100 text-rose-800'
            : 'bg-amber-100 text-amber-800'
        }`}>
          {l.status}
        </span>
      )
    },
    {
      header: "Action",
      align: "center",
      cell: (l: StaffLeave) => {
        if (!['SUPER_ADMIN', 'SCHOOL_ADMIN', 'PRINCIPAL'].includes(currentUser.role)) {
          return <span className="text-slate-400 text-[10px]">View Only</span>;
        }

        if (l.status !== 'PENDING') {
          return <span className="text-slate-400 text-[10px] font-medium">Decided</span>;
        }

        return (
          <div className="flex items-center justify-center space-x-1.5">
            <button
              onClick={() => updateStaffLeaveStatus(l.id, 'APPROVED')}
              className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
              title="Approve Leave"
            >
              <CheckCircle className="w-4 h-4" />
            </button>
            <button
              onClick={() => updateStaffLeaveStatus(l.id, 'REJECTED')}
              className="p-1 text-rose-600 hover:bg-rose-50 rounded"
              title="Reject Leave"
            >
              <XCircle className="w-4 h-4" />
            </button>
          </div>
        );
      }
    }
  ];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    addStaffLeave(newLeave);
    setModalOpen(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <CalendarDays className="w-5 h-5 text-blue-600" />
            <span>Staff Leave Requests & Approvals (Page 45)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Workflow: Absence management, medical endorsements, and principal approvals.
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="px-3.5 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center space-x-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>Apply for Leave</span>
        </button>
      </div>

      <InteractiveReport
        title="Leave Records"
        data={staffLeaves}
        columns={columns}
        searchPlaceholder="Search leaves by staff or reason..."
        searchFilterKeys={['reason', 'leaveType', 'status']}
      />

      <ApexModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Submit Leave Application"
        subtitle="Record leave intent into Oracle APEX TBL_STAFF_LEAVES"
      >
        <form onSubmit={handleSave} className="space-y-3 text-xs">
          <div>
            <label className="block font-semibold mb-1 text-slate-700">Staff Member *</label>
            <select
              value={newLeave.staffId}
              onChange={e => setNewLeave({ ...newLeave, staffId: e.target.value })}
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
            >
              {staff.map(s => (
                <option key={s.id} value={s.id}>{s.fullName} ({s.designation})</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700">Leave Category *</label>
            <select
              value={newLeave.leaveType}
              onChange={e => setNewLeave({ ...newLeave, leaveType: e.target.value as any })}
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
            >
              <option value="CASUAL">Casual Leave</option>
              <option value="SICK">Medical / Sick Leave</option>
              <option value="MATERNITY">Maternity / Paternity Leave</option>
              <option value="UNPAID">Leave Without Pay (Unpaid)</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Start Date *</label>
              <input
                type="date"
                required
                value={newLeave.startDate}
                onChange={e => setNewLeave({ ...newLeave, startDate: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">End Date *</label>
              <input
                type="date"
                required
                value={newLeave.endDate}
                onChange={e => setNewLeave({ ...newLeave, endDate: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700">Detailed Justification / Reason *</label>
            <textarea
              required
              rows={3}
              value={newLeave.reason}
              onChange={e => setNewLeave({ ...newLeave, reason: e.target.value })}
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-bold bg-blue-600 hover:bg-blue-700 text-white rounded shadow-sm"
            >
              Submit Application
            </button>
          </div>
        </form>
      </ApexModal>
    </div>
  );
};
