import React, { useState } from 'react';
import {
  DollarSign,
  AlertCircle,
  Phone,
  Send,
  Download,
  Filter,
  CheckCircle2
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { FeeInvoice, Student, Parent } from '../../types';
import { InteractiveReport, ColumnDef } from '../common/InteractiveReport';
import { ApexCard } from '../common/ApexCard';

export const OutstandingFeeLedger: React.FC = () => {
  const { invoices, students, classes, parents, settings } = useSchool();
  const [reminderSent, setReminderSent] = useState<string | null>(null);

  // Defaulter Invoices (UNPAID or PARTIALLY_PAID)
  const defaulterInvoices = invoices.filter(
    inv => inv.status === 'UNPAID' || inv.status === 'PARTIALLY_PAID'
  );

  const totalOutstanding = defaulterInvoices.reduce((sum, inv) => sum + inv.balanceAmount, 0);

  const sendReminder = (invId: string, studentName: string) => {
    setReminderSent(invId);
    setTimeout(() => setReminderSent(null), 3000);
  };

  const columns: ColumnDef<FeeInvoice>[] = [
    {
      header: "Invoice / Challan",
      accessorKey: "invoiceNo",
      cell: (inv: FeeInvoice) => (
        <span className="font-mono font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-100">
          {inv.invoiceNo}
        </span>
      )
    },
    {
      header: "Student & Class",
      cell: (inv: FeeInvoice) => {
        const student = students.find(s => s.id === inv.studentId);
        const cls = classes.find(c => c.id === student?.classId);
        return (
          <div>
            <div className="font-bold text-slate-900">{student?.fullName}</div>
            <div className="text-[11px] text-slate-500">{cls?.name} • Roll: {student?.rollNo}</div>
          </div>
        );
      }
    },
    {
      header: "Parent & Phone",
      cell: (inv: FeeInvoice) => {
        const student = students.find(s => s.id === inv.studentId);
        const parent = parents.find(p => p.id === student?.parentId);
        return (
          <div>
            <div className="font-medium text-slate-800">{parent?.fatherName || 'Guardian'}</div>
            <div className="text-[11px] text-slate-500 flex items-center space-x-1">
              <Phone className="w-3 h-3 text-slate-400" />
              <span>{parent?.primaryPhone || 'N/A'}</span>
            </div>
          </div>
        );
      }
    },
    {
      header: "Due Date",
      accessorKey: "dueDate",
      cell: (inv: FeeInvoice) => {
        const isOverdue = new Date(inv.dueDate) < new Date();
        return (
          <span className={`font-mono text-xs font-bold ${isOverdue ? 'text-rose-600' : 'text-slate-700'}`}>
            {inv.dueDate} {isOverdue && '⚠️'}
          </span>
        );
      }
    },
    {
      header: "Total Billed",
      accessorKey: "netPayable",
      align: "right",
      cell: (inv: FeeInvoice) => (
        <span className="font-mono text-slate-700">{settings.currencySymbol}{inv.netPayable.toLocaleString()}</span>
      )
    },
    {
      header: "Outstanding Balance",
      accessorKey: "balanceAmount",
      align: "right",
      cell: (inv: FeeInvoice) => (
        <span className="font-mono font-black text-rose-700 text-sm">
          {settings.currencySymbol}{inv.balanceAmount.toLocaleString()}
        </span>
      )
    },
    {
      header: "Defaulter Action",
      align: "center",
      cell: (inv: FeeInvoice) => {
        const student = students.find(s => s.id === inv.studentId);
        const isSent = reminderSent === inv.id;

        return (
          <button
            onClick={() => sendReminder(inv.id, student?.fullName || 'Student')}
            className={`px-2.5 py-1 text-[11px] font-bold rounded transition-colors flex items-center space-x-1 ${
              isSent
                ? 'bg-emerald-100 text-emerald-800'
                : 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200'
            }`}
          >
            {isSent ? <CheckCircle2 className="w-3 h-3" /> : <Send className="w-3 h-3" />}
            <span>{isSent ? 'SMS Dispatched' : 'Send Reminder'}</span>
          </button>
        );
      }
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <DollarSign className="w-5 h-5 text-rose-600" />
            <span>Outstanding Dues & Defaulter Ledger (Page 72)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Arrears Audit: Overdue aging, late penalty surcharge, and automated SMS reminder dispatch.
          </p>
        </div>
      </div>

      {/* Summary KPI Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 bg-rose-50 rounded-xl border border-rose-200">
          <span className="text-[11px] font-bold text-rose-800 uppercase">Total Arrears Balance</span>
          <p className="text-2xl font-black text-rose-900 mt-1">
            {settings.currencySymbol}{totalOutstanding.toLocaleString()}
          </p>
          <p className="text-[10px] text-rose-700 mt-0.5">Across {defaulterInvoices.length} outstanding accounts</p>
        </div>

        <div className="p-4 bg-amber-50 rounded-xl border border-amber-200">
          <span className="text-[11px] font-bold text-amber-800 uppercase">Pending Invoices</span>
          <p className="text-2xl font-black text-amber-900 mt-1">{defaulterInvoices.length}</p>
          <p className="text-[10px] text-amber-700 mt-0.5">Requires immediate follow-up</p>
        </div>

        <div className="p-4 bg-blue-50 rounded-xl border border-blue-200">
          <span className="text-[11px] font-bold text-blue-800 uppercase">Recovery Rate</span>
          <p className="text-2xl font-black text-blue-900 mt-1">88.4%</p>
          <p className="text-[10px] text-blue-700 mt-0.5">Instituted late payment grace period</p>
        </div>
      </div>

      <InteractiveReport
        title="Outstanding Defaulters"
        data={defaulterInvoices}
        columns={columns}
        searchPlaceholder="Search defaulters by invoice, student, or phone..."
        searchFilterKeys={['invoiceNo', 'monthOrTerm']}
      />
    </div>
  );
};
