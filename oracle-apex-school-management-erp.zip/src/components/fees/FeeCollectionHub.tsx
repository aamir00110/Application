import React, { useState } from 'react';
import {
  Receipt,
  Plus,
  Printer,
  CreditCard,
  Search,
  DollarSign,
  CheckCircle2,
  Calendar,
  School,
  Sparkles
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { FeeInvoice, FeeReceipt, Student } from '../../types';
import { InteractiveReport, ColumnDef } from '../common/InteractiveReport';
import { ApexModal } from '../common/ApexModal';

export const FeeCollectionHub: React.FC = () => {
  const {
    invoices,
    receipts,
    students,
    classes,
    parents,
    recordFeePayment,
    generateMonthlyInvoices,
    settings,
    currentUser
  } = useSchool();

  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [receiptModalOpen, setReceiptModalOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<FeeInvoice | null>(null);
  const [selectedReceipt, setSelectedReceipt] = useState<FeeReceipt | null>(null);

  const [paymentForm, setPaymentForm] = useState({
    amountPaid: 0,
    paymentMode: 'CASH' as any,
    transactionRef: '',
    paymentDate: new Date().toISOString().split('T')[0],
    remarks: 'Monthly tuition payment received at counter'
  });

  const [genMonth, setGenMonth] = useState('October 2026');
  const [genDue, setGenDue] = useState('2026-10-10');

  const openPaymentModal = (inv: FeeInvoice) => {
    setSelectedInvoice(inv);
    setPaymentForm({
      amountPaid: inv.balanceAmount,
      paymentMode: 'CASH',
      transactionRef: `REF-${Date.now().toString().slice(-6)}`,
      paymentDate: new Date().toISOString().split('T')[0],
      remarks: 'Payment cleared at school accounts desk'
    });
    setPaymentModalOpen(true);
  };

  const handleProcessPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInvoice) return;

    if (paymentForm.amountPaid <= 0) {
      alert("Please enter a valid payment amount.");
      return;
    }

    const createdReceipt = recordFeePayment({
      invoiceId: selectedInvoice.id,
      amountPaid: paymentForm.amountPaid,
      paymentDate: paymentForm.paymentDate,
      paymentMode: paymentForm.paymentMode,
      transactionRef: paymentForm.transactionRef || undefined,
      receivedByUserId: currentUser.id,
      remarks: paymentForm.remarks
    });

    setPaymentModalOpen(false);
    setSelectedReceipt(createdReceipt);
    setReceiptModalOpen(true);
  };

  const columns: ColumnDef<FeeInvoice>[] = [
    {
      header: "Invoice / Challan No",
      accessorKey: "invoiceNo",
      cell: (inv: FeeInvoice) => (
        <span className="font-mono font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-100">
          {inv.invoiceNo}
        </span>
      )
    },
    {
      header: "Student & Class",
      cell: (inv: FeeInvoice) => {
        const student = students.find(s => s.id === inv.studentId);
        const cls = classes.find(c => c.id === student?.classId);
        return (
          <div>
            <div className="font-bold text-slate-900">{student?.fullName || 'Student'}</div>
            <div className="text-[11px] text-slate-500">{cls?.name} • Roll: {student?.rollNo}</div>
          </div>
        );
      }
    },
    {
      header: "Billing Period",
      accessorKey: "monthOrTerm",
      cell: (inv: FeeInvoice) => <span className="font-semibold text-slate-800">{inv.monthOrTerm}</span>
    },
    {
      header: "Total Payable",
      accessorKey: "netPayable",
      align: "right",
      cell: (inv: FeeInvoice) => (
        <span className="font-mono font-bold text-slate-900">
          {settings.currencySymbol}{inv.netPayable.toLocaleString()}
        </span>
      )
    },
    {
      header: "Paid",
      accessorKey: "paidAmount",
      align: "right",
      cell: (inv: FeeInvoice) => (
        <span className="font-mono font-bold text-emerald-700">
          {settings.currencySymbol}{inv.paidAmount.toLocaleString()}
        </span>
      )
    },
    {
      header: "Balance Due",
      accessorKey: "balanceAmount",
      align: "right",
      cell: (inv: FeeInvoice) => (
        <span className="font-mono font-bold text-rose-700">
          {settings.currencySymbol}{inv.balanceAmount.toLocaleString()}
        </span>
      )
    },
    {
      header: "Status",
      accessorKey: "status",
      cell: (inv: FeeInvoice) => (
        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
          inv.status === 'PAID'
            ? 'bg-emerald-100 text-emerald-800'
            : inv.status === 'PARTIALLY_PAID'
            ? 'bg-amber-100 text-amber-800'
            : 'bg-rose-100 text-rose-800'
        }`}>
          {inv.status}
        </span>
      )
    },
    {
      header: "Action",
      align: "center",
      cell: (inv: FeeInvoice) => {
        if (inv.status === 'PAID') {
          const rec = receipts.find(r => r.invoiceId === inv.id);
          return (
            <button
              onClick={() => {
                if (rec) {
                  setSelectedReceipt(rec);
                  setReceiptModalOpen(true);
                }
              }}
              className="text-xs font-semibold text-blue-600 hover:underline flex items-center space-x-1"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Receipt</span>
            </button>
          );
        }

        return (
          <button
            onClick={() => openPaymentModal(inv)}
            className="px-2.5 py-1 text-[11px] font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded shadow-xs transition-colors flex items-center space-x-1"
          >
            <CreditCard className="w-3 h-3" />
            <span>Pay Fee</span>
          </button>
        );
      }
    }
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <Receipt className="w-5 h-5 text-blue-600" />
            <span>Fee Billing & Collection Register (Page 71)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Transaction Engine: Automated invoice posting, multi-mode cash/bank counter collection, and printed receipt vouchers.
          </p>
        </div>

        {['SUPER_ADMIN', 'SCHOOL_ADMIN', 'ACCOUNTANT'].includes(currentUser.role) && (
          <button
            onClick={() => {
              generateMonthlyInvoices(genMonth, genDue);
              alert(`Batch Fee Invoices generated for ${genMonth}!`);
            }}
            className="px-3.5 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center space-x-1.5"
          >
            <Sparkles className="w-4 h-4" />
            <span>Batch Generate Next Month Invoices</span>
          </button>
        )}
      </div>

      <InteractiveReport
        title="Fee Invoices Ledger"
        data={invoices}
        columns={columns}
        searchPlaceholder="Search by invoice no, student name, or term..."
        searchFilterKeys={['invoiceNo', 'monthOrTerm', 'status']}
      />

      {/* Collect Payment Modal */}
      <ApexModal
        isOpen={paymentModalOpen}
        onClose={() => setPaymentModalOpen(false)}
        title="Collect Fee Payment"
        subtitle={`Invoice: ${selectedInvoice?.invoiceNo} • Outstanding: ${settings.currencySymbol}${selectedInvoice?.balanceAmount}`}
      >
        <form onSubmit={handleProcessPayment} className="space-y-3 text-xs">
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 grid grid-cols-3 gap-2">
            <div>
              <span className="text-slate-400 text-[10px] uppercase font-bold">Total Bill</span>
              <p className="font-bold text-slate-800">{settings.currencySymbol}{selectedInvoice?.netPayable}</p>
            </div>
            <div>
              <span className="text-emerald-600 text-[10px] uppercase font-bold">Already Paid</span>
              <p className="font-bold text-emerald-800">{settings.currencySymbol}{selectedInvoice?.paidAmount}</p>
            </div>
            <div>
              <span className="text-rose-600 text-[10px] uppercase font-bold">Current Balance</span>
              <p className="font-bold text-rose-800 text-sm">{settings.currencySymbol}{selectedInvoice?.balanceAmount}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Amount to Receive ({settings.currencySymbol}) *</label>
              <input
                type="number"
                required
                max={selectedInvoice?.balanceAmount}
                value={paymentForm.amountPaid}
                onChange={e => setPaymentForm({ ...paymentForm, amountPaid: Number(e.target.value) })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded font-bold font-mono focus:ring-1 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">Payment Mode *</label>
              <select
                value={paymentForm.paymentMode}
                onChange={e => setPaymentForm({ ...paymentForm, paymentMode: e.target.value as any })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                <option value="CASH">Cash at Counter</option>
                <option value="BANK_TRANSFER">Bank Transfer / EFT</option>
                <option value="ONLINE">Online Portal / Credit Card</option>
                <option value="CHEQUE">Cheque / Pay Order</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Transaction Reference No</label>
              <input
                type="text"
                value={paymentForm.transactionRef}
                onChange={e => setPaymentForm({ ...paymentForm, transactionRef: e.target.value })}
                placeholder="e.g. TXN-892147"
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 font-mono"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Payment Date *</label>
              <input
                type="date"
                required
                value={paymentForm.paymentDate}
                onChange={e => setPaymentForm({ ...paymentForm, paymentDate: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700">Remarks / Ledger Narration</label>
            <input
              type="text"
              value={paymentForm.remarks}
              onChange={e => setPaymentForm({ ...paymentForm, remarks: e.target.value })}
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setPaymentModalOpen(false)}
              className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded shadow-sm flex items-center space-x-1.5"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Confirm & Generate Receipt</span>
            </button>
          </div>
        </form>
      </ApexModal>

      {/* Official Receipt Printable Modal */}
      <ApexModal
        isOpen={receiptModalOpen}
        onClose={() => setReceiptModalOpen(false)}
        title="Official Fee Payment Receipt"
        subtitle={`Receipt No: ${selectedReceipt?.receiptNo}`}
        maxWidth="lg"
        footer={
          <div className="flex space-x-2">
            <button
              onClick={() => window.print()}
              className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded flex items-center space-x-1.5 text-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Receipt Voucher</span>
            </button>
            <button
              onClick={() => setReceiptModalOpen(false)}
              className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded"
            >
              Close
            </button>
          </div>
        }
      >
        {selectedReceipt && (
          <div className="p-4 bg-white border border-slate-300 rounded-lg space-y-4 text-xs print:p-0 print:border-none">
            <div className="text-center border-b border-slate-300 pb-3">
              <div className="flex items-center justify-center space-x-2">
                <School className="w-5 h-5 text-blue-900" />
                <h3 className="text-base font-black text-slate-900 uppercase">{settings.schoolName}</h3>
              </div>
              <p className="text-[10px] text-slate-500">{settings.address}, {settings.city}</p>
              <span className="inline-block mt-1 font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                OFFICIAL PAYMENT RECEIPT
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 p-2 bg-slate-50 rounded border border-slate-200">
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase">Receipt Number</span>
                <p className="font-mono font-bold text-blue-800">{selectedReceipt.receiptNo}</p>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase">Date of Payment</span>
                <p className="font-medium text-slate-800">{selectedReceipt.paymentDate}</p>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase">Payment Mode</span>
                <p className="font-semibold text-slate-800">{selectedReceipt.paymentMode}</p>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase">Transaction Ref</span>
                <p className="font-mono text-slate-800">{selectedReceipt.transactionRef || 'COUNTER-CASH'}</p>
              </div>
            </div>

            <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200 text-center">
              <span className="text-xs font-bold text-emerald-900 uppercase">Amount Received</span>
              <p className="text-2xl font-black text-emerald-900">
                {settings.currencySymbol}{selectedReceipt.amountPaid.toLocaleString()}
              </p>
              <p className="text-[10px] text-emerald-700 italic">Received with thanks. All dues accounted for.</p>
            </div>

            <div className="pt-6 flex justify-between text-[11px] text-slate-500 border-t border-slate-200">
              <div>Depositor / Student Signature</div>
              <div>Cashier / Accounts Officer Seal</div>
            </div>
          </div>
        )}
      </ApexModal>
    </div>
  );
};
