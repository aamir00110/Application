import React, { useState } from 'react';
import {
  CreditCard,
  Plus,
  Layers,
  Sparkles,
  BookOpen
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { FeeStructure } from '../../types';
import { InteractiveReport, ColumnDef } from '../common/InteractiveReport';
import { ApexModal } from '../common/ApexModal';

export const FeeStructureSetup: React.FC = () => {
  const { feeStructures, classes, addFeeStructure, settings } = useSchool();
  const [modalOpen, setModalOpen] = useState(false);

  const [newFee, setNewFee] = useState({
    classId: classes[0]?.id || '',
    feeHead: 'TUITION' as any,
    amount: 8500,
    frequency: 'MONTHLY' as any,
    academicSessionId: 'SES-2026'
  });

  const columns: ColumnDef<FeeStructure>[] = [
    {
      header: "Class Name",
      cell: (f: FeeStructure) => {
        const c = classes.find(cls => cls.id === f.classId);
        return <span className="font-bold text-slate-900">{c?.name || 'All Classes'}</span>;
      }
    },
    {
      header: "Fee Head Category",
      accessorKey: "feeHead",
      cell: (f: FeeStructure) => (
        <span className="font-mono font-semibold text-slate-800 bg-slate-100 px-2 py-0.5 rounded text-[11px]">
          {f.feeHead}
        </span>
      )
    },
    {
      header: "Billing Frequency",
      accessorKey: "frequency",
      cell: (f: FeeStructure) => (
        <span className="font-medium text-blue-700 bg-blue-50 px-2 py-0.5 rounded text-[11px]">
          {f.frequency}
        </span>
      )
    },
    {
      header: "Tariff Amount",
      accessorKey: "amount",
      align: "right",
      cell: (f: FeeStructure) => (
        <span className="font-mono font-bold text-slate-900 text-sm">
          {settings.currencySymbol}{f.amount.toLocaleString()}
        </span>
      )
    }
  ];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    addFeeStructure(newFee);
    setModalOpen(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <CreditCard className="w-5 h-5 text-blue-600" />
            <span>Class Fee Structure & Tariff Master (Page 70)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Fee Head Rules: Tuition, lab dues, library deposits, and annual development charges.
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="px-3.5 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center space-x-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>Add Fee Head</span>
        </button>
      </div>

      <InteractiveReport
        title="Fee Structure"
        data={feeStructures}
        columns={columns}
        searchPlaceholder="Search fee heads..."
        searchFilterKeys={['feeHead', 'frequency']}
      />

      <ApexModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Add Fee Structure Category"
        subtitle="Catalog fee tariffs in Oracle APEX TBL_FEE_STRUCTURE"
      >
        <form onSubmit={handleSave} className="space-y-3 text-xs">
          <div>
            <label className="block font-semibold mb-1 text-slate-700">Target Academic Class *</label>
            <select
              value={newFee.classId}
              onChange={e => setNewFee({ ...newFee, classId: e.target.value })}
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
            >
              {classes.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Fee Head *</label>
              <select
                value={newFee.feeHead}
                onChange={e => setNewFee({ ...newFee, feeHead: e.target.value as any })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                <option value="TUITION">Tuition Fee</option>
                <option value="ADMISSION">Admission Fee</option>
                <option value="EXAMINATION">Examination Fee</option>
                <option value="LABORATORY">Science Lab Fee</option>
                <option value="LIBRARY">Library Security</option>
                <option value="SPORTS">Sports & Gym</option>
                <option value="ANNUAL_CHARGES">Annual Development</option>
                <option value="MISCELLANEOUS">Miscellaneous</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">Billing Frequency *</label>
              <select
                value={newFee.frequency}
                onChange={e => setNewFee({ ...newFee, frequency: e.target.value as any })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                <option value="MONTHLY">Monthly</option>
                <option value="QUARTERLY">Quarterly</option>
                <option value="ANNUAL">Annual / One-time</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700">Amount ({settings.currencySymbol}) *</label>
            <input
              type="number"
              required
              value={newFee.amount}
              onChange={e => setNewFee({ ...newFee, amount: Number(e.target.value) })}
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-bold bg-blue-600 hover:bg-blue-700 text-white rounded shadow-sm"
            >
              Save Fee Tariff
            </button>
          </div>
        </form>
      </ApexModal>
    </div>
  );
};
