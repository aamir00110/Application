import React, { useState } from 'react';
import {
  GraduationCap,
  Save,
  UserPlus,
  Users,
  AlertCircle,
  CheckCircle2,
  Phone,
  Mail,
  MapPin,
  Heart,
  Bus
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { ApexCard } from '../common/ApexCard';
import { Student, Parent } from '../../types';

interface StudentAdmissionFormProps {
  onComplete: (studentId: string) => void;
}

export const StudentAdmissionForm: React.FC<StudentAdmissionFormProps> = ({ onComplete }) => {
  const { classes, sections, parents, transportRoutes, addStudent, addParent, settings } = useSchool();

  const [formData, setFormData] = useState({
    // Student Personal
    firstName: '',
    lastName: '',
    gender: 'MALE' as 'MALE' | 'FEMALE' | 'OTHER',
    dateOfBirth: '2011-05-15',
    cnicBForm: '',
    bloodGroup: 'A+',
    religion: 'Islam',
    admissionDate: new Date().toISOString().split('T')[0],
    email: '',
    phone: '',
    address: '45 Knowledge Park, Sector 4',
    city: 'Metropolis',
    previousSchool: '',
    medicalConditions: '',
    avatarUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',

    // Academic Placement
    classId: classes[0]?.id || '',
    sectionId: sections[0]?.id || '',
    rollNo: '01',
    transportRequired: false,
    transportRouteId: '',

    // Parent Guardian Details
    parentMode: 'EXISTING' as 'EXISTING' | 'NEW',
    selectedParentId: parents[0]?.id || '',

    // New Parent fields
    fatherName: '',
    motherName: '',
    fatherOccupation: '',
    motherOccupation: '',
    parentPhone: '',
    parentEmail: '',
    parentCnic: '',
    parentAddress: '',
    emergencyContact: '',
    emergencyPhone: ''
  });

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Filter sections by selected class
  const availableSections = sections.filter(s => s.classId === formData.classId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!formData.firstName.trim() || !formData.lastName.trim()) {
      setErrorMessage('Please enter both First Name and Last Name.');
      return;
    }

    if (!formData.classId || !formData.sectionId) {
      setErrorMessage('Please select an Academic Class and Section.');
      return;
    }

    try {
      let parentId = formData.selectedParentId;

      if (formData.parentMode === 'NEW') {
        if (!formData.fatherName.trim() || !formData.parentPhone.trim()) {
          setErrorMessage('Please enter the Father/Guardian Name and Primary Phone.');
          return;
        }
        const createdParent = addParent({
          fatherName: formData.fatherName,
          motherName: formData.motherName,
          fatherOccupation: formData.fatherOccupation || 'Private Business',
          motherOccupation: formData.motherOccupation,
          primaryPhone: formData.parentPhone,
          email: formData.parentEmail || 'guardian@apexmail.com',
          cnicBForm: formData.parentCnic || '35202-0000000-0',
          address: formData.parentAddress || formData.address,
          emergencyContact: formData.emergencyContact || formData.fatherName,
          emergencyPhone: formData.emergencyPhone || formData.parentPhone
        });
        parentId = createdParent.id;
      }

      const newStudent = addStudent({
        firstName: formData.firstName,
        lastName: formData.lastName,
        fullName: `${formData.firstName} ${formData.lastName}`,
        gender: formData.gender,
        dateOfBirth: formData.dateOfBirth,
        cnicBForm: formData.cnicBForm || `35202-${Date.now().toString().slice(-7)}-1`,
        bloodGroup: formData.bloodGroup,
        religion: formData.religion,
        admissionDate: formData.admissionDate,
        classId: formData.classId,
        sectionId: formData.sectionId,
        rollNo: `${availableSections.find(s => s.id === formData.sectionId)?.name || 'A'}-${formData.rollNo.padStart(2, '0')}`,
        academicSessionId: 'SES-2026',
        parentId: parentId || 'PAR-01',
        email: formData.email || `${formData.firstName.toLowerCase()}.${formData.lastName.toLowerCase()}@student.apex.edu`,
        phone: formData.phone,
        address: formData.address,
        city: formData.city,
        previousSchool: formData.previousSchool,
        medicalConditions: formData.medicalConditions,
        avatarUrl: formData.avatarUrl,
        transportRequired: formData.transportRequired,
        transportRouteId: formData.transportRequired ? formData.transportRouteId : undefined,
        status: 'ACTIVE'
      });

      setIsSubmitted(true);
      setTimeout(() => {
        onComplete(newStudent.id);
      }, 1500);
    } catch (err: any) {
      setErrorMessage(err.message || 'An error occurred while enrolling the student.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <UserPlus className="w-5 h-5 text-blue-600" />
            <span>Student Admission Enrollment (Page 11)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Multi-Region Form: Validated entry with automatic ID generation & tuition challan allocation.
          </p>
        </div>
      </div>

      {isSubmitted && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 flex items-center space-x-3 animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <div className="text-xs">
            <p className="font-bold">Student Enrolled Successfully!</p>
            <p className="text-emerald-700">Official Admission Record, Student ID, and Monthly Fee Invoice generated.</p>
          </div>
        </div>
      )}

      {errorMessage && (
        <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 flex items-center space-x-2 text-xs">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6 text-xs text-slate-800">
        {/* Region 1: Student Information */}
        <ApexCard
          title="Region 1: Basic & Personal Demographics"
          subtitle="Mandatory identity particulars and civil registration details"
          icon={<GraduationCap className="w-4 h-4" />}
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">First Name *</label>
              <input
                type="text"
                required
                value={formData.firstName}
                onChange={e => setFormData({ ...formData, firstName: e.target.value })}
                placeholder="e.g. Alexander"
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">Last Name *</label>
              <input
                type="text"
                required
                value={formData.lastName}
                onChange={e => setFormData({ ...formData, lastName: e.target.value })}
                placeholder="e.g. Hayes"
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">Gender *</label>
              <select
                value={formData.gender}
                onChange={e => setFormData({ ...formData, gender: e.target.value as any })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none bg-white"
              >
                <option value="MALE">Male</option>
                <option value="FEMALE">Female</option>
                <option value="OTHER">Other</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">Date of Birth *</label>
              <input
                type="date"
                required
                value={formData.dateOfBirth}
                onChange={e => setFormData({ ...formData, dateOfBirth: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">CNIC / B-Form Number</label>
              <input
                type="text"
                value={formData.cnicBForm}
                onChange={e => setFormData({ ...formData, cnicBForm: e.target.value })}
                placeholder="35202-XXXXXXX-X"
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">Blood Group</label>
              <select
                value={formData.bloodGroup}
                onChange={e => setFormData({ ...formData, bloodGroup: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none bg-white"
              >
                {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(bg => (
                  <option key={bg} value={bg}>{bg}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">Admission Date</label>
              <input
                type="date"
                value={formData.admissionDate}
                onChange={e => setFormData({ ...formData, admissionDate: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">Student Mobile/Emergency Phone</label>
              <input
                type="tel"
                value={formData.phone}
                onChange={e => setFormData({ ...formData, phone: e.target.value })}
                placeholder="+1 (555) 000-0000"
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">Avatar Photo URL</label>
              <input
                type="url"
                value={formData.avatarUrl}
                onChange={e => setFormData({ ...formData, avatarUrl: e.target.value })}
                placeholder="https://..."
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-semibold mb-1 text-slate-700">Residential Address</label>
              <input
                type="text"
                value={formData.address}
                onChange={e => setFormData({ ...formData, address: e.target.value })}
                placeholder="House / Flat / Street address"
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">City / District</label>
              <input
                type="text"
                value={formData.city}
                onChange={e => setFormData({ ...formData, city: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div className="sm:col-span-3">
              <label className="block font-semibold mb-1 text-slate-700">Medical Notes / Allergies (if any)</label>
              <input
                type="text"
                value={formData.medicalConditions}
                onChange={e => setFormData({ ...formData, medicalConditions: e.target.value })}
                placeholder="e.g. Asthma, peanut allergy, spectacles"
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none"
              />
            </div>
          </div>
        </ApexCard>

        {/* Region 2: Academic Assignment */}
        <ApexCard
          title="Region 2: Academic Placement & Transport Assignment"
          subtitle="Class, section allotment and school bus service"
          icon={<Users className="w-4 h-4" />}
        >
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Academic Class *</label>
              <select
                value={formData.classId}
                onChange={e => {
                  const newClassId = e.target.value;
                  const sec = sections.find(s => s.classId === newClassId);
                  setFormData({
                    ...formData,
                    classId: newClassId,
                    sectionId: sec?.id || ''
                  });
                }}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none bg-white font-medium"
              >
                {classes.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">Section *</label>
              <select
                value={formData.sectionId}
                onChange={e => setFormData({ ...formData, sectionId: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none bg-white"
              >
                {availableSections.map(s => (
                  <option key={s.id} value={s.id}>{s.name} ({s.roomNumber || 'Main'})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">Assigned Roll Number</label>
              <input
                type="number"
                value={formData.rollNo}
                onChange={e => setFormData({ ...formData, rollNo: e.target.value })}
                min={1}
                max={99}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div className="sm:col-span-3 pt-2 border-t border-slate-100 flex flex-wrap items-center gap-4">
              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.transportRequired}
                  onChange={e => setFormData({ ...formData, transportRequired: e.target.checked })}
                  className="rounded text-blue-600 focus:ring-blue-500 h-4 w-4"
                />
                <span className="font-semibold text-slate-700">Assign School Bus Transport Facility</span>
              </label>

              {formData.transportRequired && (
                <div className="flex-1 max-w-sm">
                  <select
                    value={formData.transportRouteId}
                    onChange={e => setFormData({ ...formData, transportRouteId: e.target.value })}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none bg-white"
                  >
                    <option value="">-- Select Bus Route --</option>
                    {transportRoutes.map(r => (
                      <option key={r.id} value={r.id}>{r.routeName} ({settings.currencySymbol}{r.monthlyFee}/mo)</option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          </div>
        </ApexCard>

        {/* Region 3: Parent & Guardian Details */}
        <ApexCard
          title="Region 3: Parent / Guardian Relationship"
          subtitle="Link with existing registered family or create a new guardian record"
          icon={<Users className="w-4 h-4" />}
        >
          <div className="space-y-4">
            <div className="flex items-center space-x-4 border-b border-slate-100 pb-3">
              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="radio"
                  name="parentMode"
                  checked={formData.parentMode === 'EXISTING'}
                  onChange={() => setFormData({ ...formData, parentMode: 'EXISTING' })}
                  className="text-blue-600"
                />
                <span className="font-semibold">Link Existing Parent Record</span>
              </label>

              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="radio"
                  name="parentMode"
                  checked={formData.parentMode === 'NEW'}
                  onChange={() => setFormData({ ...formData, parentMode: 'NEW' })}
                  className="text-blue-600"
                />
                <span className="font-semibold">Register New Parent</span>
              </label>
            </div>

            {formData.parentMode === 'EXISTING' ? (
              <div>
                <label className="block font-semibold mb-1 text-slate-700">Select Parent Account</label>
                <select
                  value={formData.selectedParentId}
                  onChange={e => setFormData({ ...formData, selectedParentId: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none bg-white"
                >
                  {parents.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.fatherName} (Father) & {p.motherName || 'Guardian'} • Phone: {p.primaryPhone}
                    </option>
                  ))}
                </select>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700">Father's Name *</label>
                  <input
                    type="text"
                    value={formData.fatherName}
                    onChange={e => setFormData({ ...formData, fatherName: e.target.value })}
                    placeholder="e.g. Jonathan Hayes"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-700">Mother's Name</label>
                  <input
                    type="text"
                    value={formData.motherName}
                    onChange={e => setFormData({ ...formData, motherName: e.target.value })}
                    placeholder="e.g. Katherine Hayes"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-700">Primary Contact Phone *</label>
                  <input
                    type="tel"
                    value={formData.parentPhone}
                    onChange={e => setFormData({ ...formData, parentPhone: e.target.value })}
                    placeholder="+1 (555) 000-0000"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-700">Father Occupation</label>
                  <input
                    type="text"
                    value={formData.fatherOccupation}
                    onChange={e => setFormData({ ...formData, fatherOccupation: e.target.value })}
                    placeholder="e.g. Civil Engineer"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-700">Parent Email</label>
                  <input
                    type="email"
                    value={formData.parentEmail}
                    onChange={e => setFormData({ ...formData, parentEmail: e.target.value })}
                    placeholder="parent@email.com"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-700">Parent CNIC</label>
                  <input
                    type="text"
                    value={formData.parentCnic}
                    onChange={e => setFormData({ ...formData, parentCnic: e.target.value })}
                    placeholder="35202-XXXXXXX-X"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>
            )}
          </div>
        </ApexCard>

        {/* Submit Buttons */}
        <div className="flex items-center justify-end space-x-3 pt-2">
          <button
            type="button"
            onClick={() => onComplete('')}
            className="px-4 py-2 font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            id="btn-submit-admission"
            className="px-5 py-2 font-bold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm transition-colors flex items-center space-x-2"
          >
            <Save className="w-4 h-4" />
            <span>Complete Admission & Generate Challan</span>
          </button>
        </div>
      </form>
    </div>
  );
};
