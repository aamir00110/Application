import React, { useState } from 'react';
import {
  TrendingUp,
  GraduationCap,
  ArrowRight,
  CheckSquare,
  Square,
  Award,
  AlertCircle,
  CheckCircle2
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { ApexCard } from '../common/ApexCard';

export const StudentPromotion: React.FC = () => {
  const { students, classes, sections, promoteStudents, getStudentAttendancePercentage } = useSchool();

  const [sourceClassId, setSourceClassId] = useState<string>(classes[0]?.id || '');
  const [sourceSectionId, setSourceSectionId] = useState<string>('ALL');

  const [targetClassId, setTargetClassId] = useState<string>(classes[1]?.id || classes[0]?.id || '');
  const [targetSectionId, setTargetSectionId] = useState<string>(sections[0]?.id || '');

  const [selectedStudentIds, setSelectedStudentIds] = useState<string[]>([]);
  const [successMessage, setSuccessMessage] = useState('');

  const sourceStudents = students.filter(s => {
    if (s.classId !== sourceClassId) return false;
    if (sourceSectionId !== 'ALL' && s.sectionId !== sourceSectionId) return false;
    return s.status === 'ACTIVE';
  });

  const targetSections = sections.filter(s => s.classId === targetClassId);

  const toggleSelectAll = () => {
    if (selectedStudentIds.length === sourceStudents.length) {
      setSelectedStudentIds([]);
    } else {
      setSelectedStudentIds(sourceStudents.map(s => s.id));
    }
  };

  const toggleSelectStudent = (id: string) => {
    setSelectedStudentIds(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handlePromote = () => {
    if (selectedStudentIds.length === 0) {
      alert("Please select at least one student to promote.");
      return;
    }

    if (sourceClassId === targetClassId) {
      if (!window.confirm("Source and Destination classes are the same. Do you wish to re-assign sections?")) {
        return;
      }
    }

    promoteStudents(selectedStudentIds, targetClassId, targetSectionId);
    setSuccessMessage(`Successfully promoted/transferred ${selectedStudentIds.length} students to ${classes.find(c => c.id === targetClassId)?.name}!`);
    setSelectedStudentIds([]);

    setTimeout(() => {
      setSuccessMessage('');
    }, 4000);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
          <TrendingUp className="w-5 h-5 text-blue-600" />
          <span>Student Promotion & Class Progression (Page 15)</span>
        </h2>
        <p className="text-xs text-slate-500">
          Bulk academic session rollover: Promote eligible students to the next academic level with roll realignment.
        </p>
      </div>

      {successMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 flex items-center space-x-3 text-xs">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span className="font-bold">{successMessage}</span>
        </div>
      )}

      {/* Source and Destination Setup */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <ApexCard
          title="Step 1: Select Source Class (Current Roster)"
          subtitle="Choose current cohort to promote from"
          icon={<GraduationCap className="w-4 h-4" />}
        >
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Source Class</label>
              <select
                value={sourceClassId}
                onChange={e => {
                  setSourceClassId(e.target.value);
                  setSelectedStudentIds([]);
                }}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 bg-white"
              >
                {classes.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">Source Section</label>
              <select
                value={sourceSectionId}
                onChange={e => {
                  setSourceSectionId(e.target.value);
                  setSelectedStudentIds([]);
                }}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 bg-white"
              >
                <option value="ALL">All Sections</option>
                {sections.filter(s => s.classId === sourceClassId).map(s => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>
          </div>
        </ApexCard>

        <ApexCard
          title="Step 2: Select Destination Class & Section"
          subtitle="Target class for the upcoming academic session"
          icon={<ArrowRight className="w-4 h-4 text-emerald-600" />}
        >
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Destination Class *</label>
              <select
                value={targetClassId}
                onChange={e => {
                  const newTargetId = e.target.value;
                  setTargetClassId(newTargetId);
                  const firstSec = sections.find(s => s.classId === newTargetId);
                  setTargetSectionId(firstSec?.id || '');
                }}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 bg-white font-medium"
              >
                {classes.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">Destination Section *</label>
              <select
                value={targetSectionId}
                onChange={e => setTargetSectionId(e.target.value)}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-500 bg-white"
              >
                {targetSections.map(s => (
                  <option key={s.id} value={s.id}>{s.name} ({s.roomNumber || 'Main'})</option>
                ))}
              </select>
            </div>
          </div>
        </ApexCard>
      </div>

      {/* Students Selection Table */}
      <ApexCard
        title={`Eligible Candidates (${sourceStudents.length} Students)`}
        subtitle="Select students who passed examination benchmarks"
        actions={
          <div className="flex items-center space-x-2">
            <button
              onClick={toggleSelectAll}
              className="px-2.5 py-1 text-xs font-semibold bg-slate-100 hover:bg-slate-200 rounded border border-slate-300"
            >
              {selectedStudentIds.length === sourceStudents.length ? 'Deselect All' : 'Select All'}
            </button>
            <button
              id="btn-confirm-promotion"
              onClick={handlePromote}
              disabled={selectedStudentIds.length === 0}
              className="px-4 py-1.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-md shadow-sm transition-colors flex items-center space-x-1.5"
            >
              <TrendingUp className="w-3.5 h-3.5" />
              <span>Promote {selectedStudentIds.length} Selected</span>
            </button>
          </div>
        }
      >
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                <th className="p-3 w-10">
                  <input
                    type="checkbox"
                    checked={sourceStudents.length > 0 && selectedStudentIds.length === sourceStudents.length}
                    onChange={toggleSelectAll}
                    className="rounded text-blue-600"
                  />
                </th>
                <th className="p-3">Student Name</th>
                <th className="p-3">Admission No</th>
                <th className="p-3">Current Roll</th>
                <th className="p-3">Attendance %</th>
                <th className="p-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {sourceStudents.length > 0 ? (
                sourceStudents.map(s => {
                  const isChecked = selectedStudentIds.includes(s.id);
                  const att = getStudentAttendancePercentage(s.id);
                  return (
                    <tr
                      key={s.id}
                      onClick={() => toggleSelectStudent(s.id)}
                      className={`cursor-pointer transition-colors ${
                        isChecked ? 'bg-blue-50/70 font-semibold' : 'hover:bg-slate-50'
                      }`}
                    >
                      <td className="p-3" onClick={e => e.stopPropagation()}>
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => toggleSelectStudent(s.id)}
                          className="rounded text-blue-600"
                        />
                      </td>
                      <td className="p-3 flex items-center space-x-2">
                        <img
                          src={s.avatarUrl || 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80'}
                          alt={s.fullName}
                          className="w-7 h-7 rounded-full object-cover"
                        />
                        <span>{s.fullName}</span>
                      </td>
                      <td className="p-3 font-mono font-medium text-blue-700">{s.admissionNo}</td>
                      <td className="p-3 font-mono">{s.rollNo}</td>
                      <td className="p-3 font-mono font-bold text-emerald-700">{att}%</td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                          {s.status}
                        </span>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={6} className="p-6 text-center text-slate-400 italic">
                    No active students found in this source class.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </ApexCard>
    </div>
  );
};
