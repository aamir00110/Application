import React, { useState, useMemo } from 'react';
import {
  GraduationCap,
  Plus,
  Search,
  Filter,
  Eye,
  Trash2,
  Phone,
  Mail,
  UserCheck,
  CheckCircle,
  FileSpreadsheet,
  Printer,
  CreditCard
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { Student } from '../../types';
import { InteractiveReport, ColumnDef } from '../common/InteractiveReport';
import { StudentProfileModal } from './StudentProfileModal';

interface StudentDirectoryProps {
  onNavigateAdmission: () => void;
}

export const StudentDirectory: React.FC<StudentDirectoryProps> = ({ onNavigateAdmission }) => {
  const { students, classes, sections, parents, deleteStudent, getStudentAttendancePercentage, currentUser } = useSchool();
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [profileModalOpen, setProfileModalOpen] = useState(false);

  // Filters
  const [selectedClassId, setSelectedClassId] = useState<string>('ALL');
  const [selectedSectionId, setSelectedSectionId] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');

  // Filtered Students
  const filteredStudents = useMemo(() => {
    return students.filter(s => {
      if (selectedClassId !== 'ALL' && s.classId !== selectedClassId) return false;
      if (selectedSectionId !== 'ALL' && s.sectionId !== selectedSectionId) return false;
      if (selectedStatus !== 'ALL' && s.status !== selectedStatus) return false;
      return true;
    });
  }, [students, selectedClassId, selectedSectionId, selectedStatus]);

  const columns: ColumnDef<Student>[] = [
    {
      header: "Student Name & Roll",
      accessorKey: "fullName",
      cell: (s: Student) => {
        const studentClass = classes.find(c => c.id === s.classId);
        const studentSection = sections.find(sec => sec.id === s.sectionId);
        return (
          <div className="flex items-center space-x-3">
            <img
              src={s.avatarUrl || 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80'}
              alt={s.fullName}
              className="w-9 h-9 rounded-full object-cover border border-slate-200"
            />
            <div>
              <div className="font-bold text-slate-900 flex items-center space-x-1.5">
                <span>{s.fullName}</span>
                <span className="font-mono text-[10px] px-1.5 py-0.2 bg-slate-100 text-slate-600 rounded">
                  {s.rollNo}
                </span>
              </div>
              <div className="text-[11px] text-slate-500">
                {studentClass?.name || 'Class'} • {studentSection?.name || 'Sec'}
              </div>
            </div>
          </div>
        );
      }
    },
    {
      header: "Admission ID",
      accessorKey: "admissionNo",
      cell: (s: Student) => (
        <span className="font-mono font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-100">
          {s.admissionNo}
        </span>
      )
    },
    {
      header: "Parent / Guardian",
      accessorKey: "parentId",
      cell: (s: Student) => {
        const parent = parents.find(p => p.id === s.parentId);
        return (
          <div>
            <div className="font-medium text-slate-800">{parent?.fatherName || 'Guardian'}</div>
            <div className="text-[11px] text-slate-500">{parent?.primaryPhone || s.phone || 'N/A'}</div>
          </div>
        );
      }
    },
    {
      header: "Attendance %",
      cell: (s: Student) => {
        const pct = getStudentAttendancePercentage(s.id);
        const isHealthy = pct >= 75;
        return (
          <div className="flex items-center space-x-2">
            <div className="w-12 bg-slate-200 rounded-full h-1.5 overflow-hidden">
              <div
                className={`h-1.5 rounded-full ${isHealthy ? 'bg-emerald-500' : 'bg-rose-500'}`}
                style={{ width: `${pct}%` }}
              />
            </div>
            <span className={`font-bold font-mono text-[11px] ${isHealthy ? 'text-emerald-700' : 'text-rose-700'}`}>
              {pct}%
            </span>
          </div>
        );
      }
    },
    {
      header: "Status",
      accessorKey: "status",
      cell: (s: Student) => (
        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
          s.status === 'ACTIVE'
            ? 'bg-emerald-100 text-emerald-800'
            : s.status === 'GRADUATED'
            ? 'bg-blue-100 text-blue-800'
            : 'bg-rose-100 text-rose-800'
        }`}>
          {s.status}
        </span>
      )
    },
    {
      header: "Actions",
      align: "center",
      cell: (s: Student) => (
        <div className="flex items-center justify-center space-x-1.5">
          <button
            onClick={() => {
              setSelectedStudent(s);
              setProfileModalOpen(true);
            }}
            className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
            title="View Student 360° Profile"
          >
            <Eye className="w-4 h-4" />
          </button>
          {['SUPER_ADMIN', 'SCHOOL_ADMIN', 'PRINCIPAL'].includes(currentUser.role) && (
            <button
              onClick={() => {
                if (window.confirm(`Are you sure you want to delete ${s.fullName}?`)) {
                  deleteStudent(s.id);
                }
              }}
              className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
              title="Delete Student"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      )
    }
  ];

  return (
    <div className="space-y-4">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <GraduationCap className="w-5 h-5 text-blue-600" />
            <span>Student Directory & Roster (Page 10)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Interactive Report with faceted search, academic profiles, attendance history, and fee statements.
          </p>
        </div>

        {['SUPER_ADMIN', 'SCHOOL_ADMIN', 'PRINCIPAL', 'RECEPTIONIST'].includes(currentUser.role) && (
          <button
            id="btn-add-student"
            onClick={onNavigateAdmission}
            className="px-3.5 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm transition-colors flex items-center space-x-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>New Admission (Page 11)</span>
          </button>
        )}
      </div>

      {/* Faceted Filters Bar */}
      <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-2xs flex flex-wrap items-center gap-3 text-xs">
        <div className="flex items-center space-x-1.5 text-slate-500 font-semibold">
          <Filter className="w-3.5 h-3.5" />
          <span>Filter Roster:</span>
        </div>

        <div>
          <select
            value={selectedClassId}
            onChange={e => setSelectedClassId(e.target.value)}
            className="px-2.5 py-1 bg-slate-50 border border-slate-300 rounded text-xs focus:ring-1 focus:ring-blue-500 font-medium"
          >
            <option value="ALL">All Classes ({students.length})</option>
            {classes.map(c => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>

        <div>
          <select
            value={selectedSectionId}
            onChange={e => setSelectedSectionId(e.target.value)}
            className="px-2.5 py-1 bg-slate-50 border border-slate-300 rounded text-xs focus:ring-1 focus:ring-blue-500"
          >
            <option value="ALL">All Sections</option>
            {sections.map(s => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </div>

        <div>
          <select
            value={selectedStatus}
            onChange={e => setSelectedStatus(e.target.value)}
            className="px-2.5 py-1 bg-slate-50 border border-slate-300 rounded text-xs focus:ring-1 focus:ring-blue-500"
          >
            <option value="ALL">All Statuses</option>
            <option value="ACTIVE">Active</option>
            <option value="GRADUATED">Graduated</option>
            <option value="TRANSFERRED">Transferred</option>
          </select>
        </div>

        {(selectedClassId !== 'ALL' || selectedSectionId !== 'ALL' || selectedStatus !== 'ALL') && (
          <button
            onClick={() => {
              setSelectedClassId('ALL');
              setSelectedSectionId('ALL');
              setSelectedStatus('ALL');
            }}
            className="text-xs text-blue-600 hover:underline ml-auto font-medium"
          >
            Clear Filters
          </button>
        )}
      </div>

      {/* Interactive Report Table */}
      <InteractiveReport
        id="report-students-roster"
        title="Student Roster"
        data={filteredStudents}
        columns={columns}
        searchPlaceholder="Search by Name, Admission No, Parent, or Roll..."
        searchFilterKeys={['fullName', 'admissionNo', 'rollNo', 'phone', 'city']}
      />

      {/* Student 360° Modal */}
      <StudentProfileModal
        student={selectedStudent}
        isOpen={profileModalOpen}
        onClose={() => {
          setProfileModalOpen(false);
          setSelectedStudent(null);
        }}
      />
    </div>
  );
};
