import React, { useState } from 'react';
import {
  GraduationCap,
  Calendar,
  Phone,
  Mail,
  MapPin,
  Heart,
  Bus,
  Award,
  CreditCard,
  UserCheck,
  CheckCircle,
  FileCheck2,
  AlertCircle
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { Student } from '../../types';
import { ApexModal } from '../common/ApexModal';

interface StudentProfileModalProps {
  student: Student | null;
  isOpen: boolean;
  onClose: () => void;
}

export const StudentProfileModal: React.FC<StudentProfileModalProps> = ({
  student,
  isOpen,
  onClose
}) => {
  const {
    classes,
    sections,
    parents,
    studentAttendance,
    studentMarks,
    invoices,
    receipts,
    certificates,
    examTypes,
    subjects,
    settings
  } = useSchool();

  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'ATTENDANCE' | 'ACADEMICS' | 'FEES' | 'CERTIFICATES'>('OVERVIEW');

  if (!student) return null;

  const studentClass = classes.find(c => c.id === student.classId);
  const studentSection = sections.find(s => s.id === student.sectionId);
  const parent = parents.find(p => p.id === student.parentId);

  // Attendance Stats
  const studentAttRecords = studentAttendance.filter(r => r.studentId === student.id);
  const totalAttDays = studentAttRecords.length;
  const presentDays = studentAttRecords.filter(r => r.status === 'PRESENT' || r.status === 'LATE' || r.status === 'HALF_DAY').length;
  const attPct = totalAttDays > 0 ? Math.round((presentDays / totalAttDays) * 100) : 100;

  // Exam Marks
  const marksList = studentMarks.filter(m => m.studentId === student.id);
  const totalMarksObtained = marksList.reduce((sum, m) => sum + m.marksObtained, 0);
  const totalMaxMarks = marksList.reduce((sum, m) => sum + m.maxMarks, 0);
  const overallExamPct = totalMaxMarks > 0 ? Math.round((totalMarksObtained / totalMaxMarks) * 100) : 0;
  const avgGpa = marksList.length > 0
    ? (marksList.reduce((sum, m) => sum + m.gpa, 0) / marksList.length).toFixed(2)
    : 'N/A';

  // Fee Invoices
  const studentInvoices = invoices.filter(i => i.studentId === student.id);
  const totalInvoiced = studentInvoices.reduce((sum, i) => sum + i.netPayable, 0);
  const totalPaid = studentInvoices.reduce((sum, i) => sum + i.paidAmount, 0);
  const totalBalance = studentInvoices.reduce((sum, i) => sum + i.balanceAmount, 0);

  // Certificates
  const studentCerts = certificates.filter(c => c.studentId === student.id);

  return (
    <ApexModal
      isOpen={isOpen}
      onClose={onClose}
      title={`Student 360° Profile: ${student.fullName}`}
      subtitle={`Admission No: ${student.admissionNo} • Roll: ${student.rollNo} • Class: ${studentClass?.name || ''} (${studentSection?.name || ''})`}
      maxWidth="4xl"
      footer={
        <button
          onClick={onClose}
          className="px-4 py-1.5 text-xs font-semibold bg-slate-800 text-white hover:bg-slate-700 rounded-md"
        >
          Close Profile
        </button>
      }
    >
      <div className="space-y-4 text-xs text-slate-700">
        {/* Header Ribbon / Student Card */}
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row items-center sm:items-start space-y-3 sm:space-y-0 sm:space-x-4">
          <img
            src={student.avatarUrl || 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80'}
            alt={student.fullName}
            className="w-20 h-20 rounded-xl object-cover border-2 border-white shadow-sm"
          />
          <div className="flex-1 text-center sm:text-left space-y-1">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <h2 className="text-base font-bold text-slate-900">{student.fullName}</h2>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                student.status === 'ACTIVE'
                  ? 'bg-emerald-100 text-emerald-800'
                  : 'bg-rose-100 text-rose-800'
              }`}>
                {student.status}
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-100 text-blue-800">
                Blood Group: {student.bloodGroup}
              </span>
            </div>
            <p className="text-xs text-slate-500">
              {studentClass?.name} • {studentSection?.name} • Admission Date: {student.admissionDate}
            </p>
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 text-[11px] text-slate-600 pt-1">
              <span className="flex items-center space-x-1">
                <Phone className="w-3.5 h-3.5 text-slate-400" />
                <span>{student.phone || parent?.primaryPhone || 'N/A'}</span>
              </span>
              <span className="flex items-center space-x-1">
                <Mail className="w-3.5 h-3.5 text-slate-400" />
                <span>{student.email || parent?.email || 'N/A'}</span>
              </span>
              <span className="flex items-center space-x-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                <span>{student.city}</span>
              </span>
            </div>
          </div>

          {/* Quick Metrics Badge */}
          <div className="flex sm:flex-col gap-2 shrink-0">
            <div className="p-2 bg-white rounded-lg border border-slate-200 text-center min-w-[90px]">
              <span className="text-[10px] font-semibold text-slate-400 uppercase">Attendance</span>
              <p className="text-sm font-bold text-emerald-600">{attPct}%</p>
            </div>
            <div className="p-2 bg-white rounded-lg border border-slate-200 text-center min-w-[90px]">
              <span className="text-[10px] font-semibold text-slate-400 uppercase">Avg GPA</span>
              <p className="text-sm font-bold text-blue-600">{avgGpa}</p>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 space-x-2">
          {[
            { id: 'OVERVIEW', label: 'Overview & Family', icon: <GraduationCap className="w-3.5 h-3.5" /> },
            { id: 'ATTENDANCE', label: 'Attendance Timeline', icon: <UserCheck className="w-3.5 h-3.5" /> },
            { id: 'ACADEMICS', label: 'Exam Results', icon: <Award className="w-3.5 h-3.5" /> },
            { id: 'FEES', label: 'Fee Account', icon: <CreditCard className="w-3.5 h-3.5" /> },
            { id: 'CERTIFICATES', label: 'Certificates', icon: <FileCheck2 className="w-3.5 h-3.5" /> }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-1.5 px-3 py-2 text-xs font-semibold border-b-2 transition-all ${
                activeTab === tab.id
                  ? 'border-blue-600 text-blue-600 bg-blue-50/50'
                  : 'border-transparent text-slate-500 hover:text-slate-700'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Tab 1: Overview & Family */}
        {activeTab === 'OVERVIEW' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
              <h4 className="font-bold text-slate-900 border-b border-slate-200 pb-1">
                Personal & Medical Profile
              </h4>
              <div className="space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-500">Gender:</span>
                  <span className="font-medium">{student.gender}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Date of Birth:</span>
                  <span className="font-medium">{student.dateOfBirth}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">CNIC / B-Form:</span>
                  <span className="font-mono font-medium">{student.cnicBForm || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Religion:</span>
                  <span className="font-medium">{student.religion || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Previous School:</span>
                  <span className="font-medium">{student.previousSchool || 'Direct Entry'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Medical Notes:</span>
                  <span className="font-medium text-amber-700">{student.medicalConditions || 'Healthy / None'}</span>
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
              <h4 className="font-bold text-slate-900 border-b border-slate-200 pb-1">
                Parent & Guardian Information
              </h4>
              {parent ? (
                <div className="space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Father's Name:</span>
                    <span className="font-medium">{parent.fatherName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Occupation:</span>
                    <span className="font-medium">{parent.fatherOccupation}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Mother's Name:</span>
                    <span className="font-medium">{parent.motherName || 'N/A'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Primary Phone:</span>
                    <span className="font-medium">{parent.primaryPhone}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Email:</span>
                    <span className="font-medium">{parent.email}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Emergency Contact:</span>
                    <span className="font-medium text-rose-700">{parent.emergencyContact} ({parent.emergencyPhone})</span>
                  </div>
                </div>
              ) : (
                <p className="text-slate-400 italic">No linked parent record found.</p>
              )}
            </div>
          </div>
        )}

        {/* Tab 2: Attendance */}
        {activeTab === 'ATTENDANCE' && (
          <div className="space-y-3">
            <div className="p-3 bg-blue-50 rounded-lg border border-blue-100 flex items-center justify-between">
              <div>
                <span className="font-bold text-blue-900">Attendance Summary</span>
                <p className="text-[11px] text-blue-700">Calculated over {totalAttDays} official school days</p>
              </div>
              <span className="text-lg font-black text-blue-900">{attPct}% Overall</span>
            </div>

            <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg overflow-hidden">
              {studentAttRecords.map(att => (
                <div key={att.id} className="p-2.5 flex items-center justify-between hover:bg-slate-50">
                  <div className="flex items-center space-x-2">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span className="font-semibold">{att.date}</span>
                    {att.remarks && (
                      <span className="text-[11px] text-slate-500 italic">({att.remarks})</span>
                    )}
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    att.status === 'PRESENT'
                      ? 'bg-emerald-100 text-emerald-800'
                      : att.status === 'LATE'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-rose-100 text-rose-800'
                  }`}>
                    {att.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: Academics */}
        {activeTab === 'ACADEMICS' && (
          <div className="space-y-3">
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg overflow-hidden">
              {marksList.length > 0 ? (
                marksList.map(m => {
                  const examType = examTypes.find(e => e.id === m.examTypeId);
                  const subject = subjects.find(s => s.id === m.subjectId);
                  return (
                    <div key={m.id} className="p-3 flex items-center justify-between hover:bg-slate-50">
                      <div>
                        <div className="font-bold text-slate-800">{subject?.name} ({subject?.code})</div>
                        <div className="text-[11px] text-slate-500">{examType?.name}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-mono font-bold text-slate-900">
                          {m.marksObtained} / {m.maxMarks}
                        </div>
                        <div className="flex items-center justify-end space-x-1.5 text-[11px]">
                          <span className="font-bold text-emerald-700">Grade: {m.grade}</span>
                          <span>•</span>
                          <span className="text-blue-700">GPA: {m.gpa}</span>
                        </div>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="p-6 text-center text-slate-400 italic">
                  No exam marks published for this student yet.
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 4: Fee Account */}
        {activeTab === 'FEES' && (
          <div className="space-y-3">
            <div className="grid grid-cols-3 gap-3">
              <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">Total Invoiced</span>
                <p className="text-sm font-bold text-slate-800">{settings.currencySymbol}{totalInvoiced}</p>
              </div>
              <div className="p-2.5 bg-emerald-50 rounded border border-emerald-100">
                <span className="text-[10px] text-emerald-700 uppercase font-semibold">Total Paid</span>
                <p className="text-sm font-bold text-emerald-900">{settings.currencySymbol}{totalPaid}</p>
              </div>
              <div className="p-2.5 bg-rose-50 rounded border border-rose-100">
                <span className="text-[10px] text-rose-700 uppercase font-semibold">Balance Due</span>
                <p className="text-sm font-bold text-rose-900">{settings.currencySymbol}{totalBalance}</p>
              </div>
            </div>

            <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg overflow-hidden">
              {studentInvoices.map(inv => (
                <div key={inv.id} className="p-3 flex items-center justify-between hover:bg-slate-50">
                  <div>
                    <div className="font-bold text-slate-800">{inv.monthOrTerm} ({inv.invoiceNo})</div>
                    <div className="text-[11px] text-slate-500">Due: {inv.dueDate}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-slate-900">{settings.currencySymbol}{inv.netPayable}</div>
                    <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                      inv.status === 'PAID'
                        ? 'bg-emerald-100 text-emerald-800'
                        : inv.status === 'PARTIALLY_PAID'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}>
                      {inv.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 5: Certificates */}
        {activeTab === 'CERTIFICATES' && (
          <div className="space-y-3">
            {studentCerts.length > 0 ? (
              <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg overflow-hidden">
                {studentCerts.map(cert => (
                  <div key={cert.id} className="p-3 flex items-center justify-between hover:bg-slate-50">
                    <div>
                      <div className="font-bold text-slate-800">{cert.type} Certificate</div>
                      <div className="text-[11px] text-slate-500">No: {cert.certificateNo} • Purpose: {cert.purpose}</div>
                    </div>
                    <span className="text-[11px] font-medium text-blue-600">Issued: {cert.issueDate}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-6 text-center text-slate-400 italic">
                No official certificates issued yet for this student.
              </div>
            )}
          </div>
        )}
      </div>
    </ApexModal>
  );
};
