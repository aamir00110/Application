import React from 'react';
import {
  Users,
  GraduationCap,
  Briefcase,
  DollarSign,
  Calendar,
  CheckCircle,
  TrendingUp,
  CreditCard,
  Award,
  AlertCircle,
  Clock,
  BookOpen,
  ArrowRight,
  Sparkles,
  ShieldCheck,
  UserCheck
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { ApexStatCard } from '../common/ApexStatCard';
import { ApexCard } from '../common/ApexCard';
import { NavigationPage } from '../common/ApexSidebar';

interface ExecutiveDashboardProps {
  onNavigate: (page: NavigationPage) => void;
}

export const ExecutiveDashboard: React.FC<ExecutiveDashboardProps> = ({ onNavigate }) => {
  const {
    currentUser,
    settings,
    students,
    staff,
    invoices,
    receipts,
    expenses,
    studentAttendance,
    examTypes,
    notices,
    events,
    classes,
    homework
  } = useSchool();

  // Metrics calculation
  const totalStudents = students.length;
  const activeStudents = students.filter(s => s.status === 'ACTIVE').length;
  const maleStudents = students.filter(s => s.gender === 'MALE').length;
  const femaleStudents = students.filter(s => s.gender === 'FEMALE').length;
  const totalTeachers = staff.filter(s => s.department === 'ACADEMICS').length;
  const totalStaff = staff.length;

  // Financials
  const totalCollectedFees = receipts.reduce((sum, r) => sum + r.amountPaid, 0);
  const totalOutstandingFees = invoices.reduce((sum, i) => sum + i.balanceAmount, 0);
  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const netOperatingMargin = totalCollectedFees - totalExpenses;

  // Today Attendance
  const today = new Date().toISOString().split('T')[0];
  const todayRecords = studentAttendance.filter(r => r.date === today);
  const presentToday = todayRecords.filter(r => r.status === 'PRESENT' || r.status === 'LATE').length;
  const attendanceRateToday = todayRecords.length > 0
    ? Math.round((presentToday / todayRecords.length) * 100)
    : 95;

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-[#1E293B] rounded-xl p-6 text-white shadow-sm border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1.5">
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-md text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 uppercase tracking-wider">
              {currentUser.role.replace('_', ' ')} WORKSPACE
            </span>
            <span className="text-xs text-slate-400">
              Active Session: {settings.currentAcademicSession}
            </span>
          </div>
          <h1 className="text-xl md:text-2xl font-bold tracking-tight text-white">
            Welcome back, {currentUser.fullName}
          </h1>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            ScholarERP Enterprise APEX Console. Campus telemetry, real-time student lifecycle tracking, attendance and financial metrics.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          {currentUser.role !== 'STUDENT' && currentUser.role !== 'PARENT' && (
            <button
              id="dash-btn-admission"
              onClick={() => onNavigate('STUDENT_ADMISSION')}
              className="px-3.5 py-2 text-xs font-semibold bg-emerald-500 hover:bg-emerald-400 text-slate-900 rounded-lg shadow-sm transition-colors flex items-center space-x-1.5"
            >
              <GraduationCap className="w-4 h-4 text-slate-900" />
              <span>New Admission</span>
            </button>
          )}
          <button
            id="dash-btn-attendance"
            onClick={() => onNavigate('ATTENDANCE_STUDENTS')}
            className="px-3.5 py-2 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 transition-colors flex items-center space-x-1.5"
          >
            <UserCheck className="w-4 h-4 text-emerald-400" />
            <span>Mark Attendance</span>
          </button>
          <button
            id="dash-btn-architecture"
            onClick={() => onNavigate('ORACLE_APEX_HUB')}
            className="px-3.5 py-2 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 transition-colors flex items-center space-x-1.5"
          >
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Database Specs</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <ApexStatCard
          id="stat-total-students"
          title="Enrolled Students"
          value={totalStudents}
          subtitle={`${maleStudents} Boys • ${femaleStudents} Girls`}
          icon={<GraduationCap className="w-6 h-6" />}
          trend={{ value: "+4 this month", isPositive: true }}
          colorTheme="blue"
          onClick={() => onNavigate('STUDENT_DIRECTORY')}
        />

        <ApexStatCard
          id="stat-attendance-rate"
          title="Daily Attendance"
          value={`${attendanceRateToday}%`}
          subtitle={`${presentToday} Present of ${todayRecords.length || totalStudents}`}
          icon={<UserCheck className="w-6 h-6" />}
          trend={{ value: "Target ≥ 90%", isPositive: true }}
          colorTheme="emerald"
          onClick={() => onNavigate('ATTENDANCE_STUDENTS')}
        />

        <ApexStatCard
          id="stat-fee-collections"
          title="Fee Collections"
          value={`${settings.currencySymbol}${totalCollectedFees.toLocaleString()}`}
          subtitle={`Due: ${settings.currencySymbol}${totalOutstandingFees.toLocaleString()}`}
          icon={<CreditCard className="w-6 h-6" />}
          trend={{ value: "88% recovered", isPositive: true }}
          colorTheme="amber"
          onClick={() => onNavigate('FEES_COLLECTION')}
        />

        <ApexStatCard
          id="stat-faculty-staff"
          title="Faculty & Staff"
          value={totalStaff}
          subtitle={`${totalTeachers} Academic Teachers`}
          icon={<Briefcase className="w-6 h-6" />}
          colorTheme="indigo"
          onClick={() => onNavigate('STAFF_DIRECTORY')}
        />
      </div>

      {/* Analytics & Quick Action Rows */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Financial & Academic Highlights */}
        <div className="lg:col-span-2 space-y-6">
          {/* Financial Summary Breakdown */}
          <ApexCard
            id="region-financial-summary"
            title="Institutional Financial Health & Cashflow"
            subtitle="Oracle SQL Aggregation: Monthly Fee Revenue vs Operating Expenditure"
            icon={<TrendingUp className="w-4 h-4" />}
            actions={
              <button
                onClick={() => onNavigate('FEES_OUTSTANDING')}
                className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 flex items-center space-x-1"
              >
                <span>View Dues Ledger</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            }
          >
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
              <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-100">
                <span className="text-[11px] font-bold text-emerald-800 uppercase">Gross Revenue Collected</span>
                <p className="text-xl font-bold text-emerald-900 mt-1">
                  {settings.currencySymbol}{totalCollectedFees.toLocaleString()}
                </p>
                <p className="text-[10px] text-emerald-700 mt-0.5">{receipts.length} successful transactions</p>
              </div>

              <div className="p-3 bg-rose-50 rounded-lg border border-rose-100">
                <span className="text-[11px] font-bold text-rose-800 uppercase">Operating Expenses</span>
                <p className="text-xl font-bold text-rose-900 mt-1">
                  {settings.currencySymbol}{totalExpenses.toLocaleString()}
                </p>
                <p className="text-[10px] text-rose-700 mt-0.5">Utilities, Labs & Fleet Fuel</p>
              </div>

              <div className="p-3 bg-blue-50 rounded-lg border border-blue-100">
                <span className="text-[11px] font-bold text-blue-800 uppercase">Net Operational Balance</span>
                <p className="text-xl font-bold text-blue-900 mt-1">
                  {settings.currencySymbol}{netOperatingMargin.toLocaleString()}
                </p>
                <p className="text-[10px] text-blue-700 mt-0.5">Surplus for Academic Expansion</p>
              </div>
            </div>

            {/* Quick Bar Meter */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-semibold text-slate-700">
                <span>Fee Collection Target Progress</span>
                <span>
                  {settings.currencySymbol}{totalCollectedFees} / {settings.currencySymbol}{totalCollectedFees + totalOutstandingFees} ({Math.round((totalCollectedFees / (totalCollectedFees + totalOutstandingFees || 1)) * 100)}%)
                </span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
                <div
                  className="bg-emerald-500 h-3 rounded-full transition-all duration-500"
                  style={{
                    width: `${Math.min(100, Math.round((totalCollectedFees / (totalCollectedFees + totalOutstandingFees || 1)) * 100))}%`
                  }}
                />
              </div>
            </div>
          </ApexCard>

          {/* Class Enrollment Breakdown */}
          <ApexCard
            id="region-class-breakdown"
            title="Class-wise Student Enrollment & Ratios"
            subtitle="Real-time count across Senior High, High School & Middle School"
            icon={<BookOpen className="w-4 h-4" />}
          >
            <div className="divide-y divide-slate-100 text-xs">
              {classes.map(c => {
                const count = students.filter(s => s.classId === c.id).length;
                const pct = Math.round((count / (c.capacity || 40)) * 100);
                return (
                  <div key={c.id} className="py-2.5 flex items-center justify-between">
                    <div>
                      <div className="font-bold text-slate-800">{c.name}</div>
                      <div className="text-[11px] text-slate-500">{c.description || 'General Academic'}</div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-32 bg-slate-100 rounded-full h-2 hidden sm:block">
                        <div
                          className="bg-emerald-500 h-2 rounded-full"
                          style={{ width: `${Math.min(100, pct)}%` }}
                        />
                      </div>
                      <span className="font-semibold text-slate-800 whitespace-nowrap">
                        {count} / {c.capacity} students
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </ApexCard>
        </div>

        {/* Right Col: Notices, Upcoming Events & Quick Launch */}
        <div className="space-y-6">
          {/* Quick Module Launchers */}
          <ApexCard
            id="region-quick-launch"
            title="Quick Action Shortcuts"
            subtitle="APEX Fast-path Navigation"
            icon={<Sparkles className="w-4 h-4" />}
          >
            <div className="grid grid-cols-2 gap-2.5 text-xs">
              <button
                onClick={() => onNavigate('STUDENT_ADMISSION')}
                className="p-3 rounded-lg border border-slate-200 hover:bg-emerald-50/50 hover:border-emerald-300 text-left transition-colors flex flex-col items-start space-y-1 group"
              >
                <GraduationCap className="w-4 h-4 text-emerald-600 group-hover:scale-105 transition-transform" />
                <span className="font-bold text-slate-800">Admissions</span>
                <span className="text-[10px] text-slate-500">Register student</span>
              </button>

              <button
                onClick={() => onNavigate('EXAMS_MARKS_ENTRY')}
                className="p-3 rounded-lg border border-slate-200 hover:bg-emerald-50/50 hover:border-emerald-300 text-left transition-colors flex flex-col items-start space-y-1 group"
              >
                <Award className="w-4 h-4 text-amber-600 group-hover:scale-105 transition-transform" />
                <span className="font-bold text-slate-800">Marks Entry</span>
                <span className="text-[10px] text-slate-500">Grading sheet</span>
              </button>

              <button
                onClick={() => onNavigate('FEES_COLLECTION')}
                className="p-3 rounded-lg border border-slate-200 hover:bg-emerald-50/50 hover:border-emerald-300 text-left transition-colors flex flex-col items-start space-y-1 group"
              >
                <CreditCard className="w-4 h-4 text-emerald-600 group-hover:scale-105 transition-transform" />
                <span className="font-bold text-slate-800">Fee Challans</span>
                <span className="text-[10px] text-slate-500">Collect & Receipt</span>
              </button>

              <button
                onClick={() => onNavigate('EXAMS_REPORT_CARDS')}
                className="p-3 rounded-lg border border-slate-200 hover:bg-emerald-50/50 hover:border-emerald-300 text-left transition-colors flex flex-col items-start space-y-1 group"
              >
                <CheckCircle className="w-4 h-4 text-slate-700 group-hover:scale-105 transition-transform" />
                <span className="font-bold text-slate-800">Report Cards</span>
                <span className="text-[10px] text-slate-500">Official printouts</span>
              </button>
            </div>
          </ApexCard>

          {/* Upcoming School Events */}
          <ApexCard
            id="region-events"
            title="School Calendar & Events"
            subtitle="Scheduled examinations and activities"
            icon={<Calendar className="w-4 h-4" />}
            actions={
              <button
                onClick={() => onNavigate('NOTICES_EVENTS')}
                className="text-xs text-emerald-600 hover:underline font-semibold"
              >
                View all
              </button>
            }
          >
            <div className="space-y-3 text-xs">
              {events.map(e => (
                <div key={e.id} className="p-3 bg-slate-50 rounded-lg border-l-4 border-emerald-500 border border-slate-200/80 flex items-start space-x-3">
                  <div className="w-9 h-9 rounded-lg bg-emerald-100 text-emerald-800 flex flex-col items-center justify-center font-bold shrink-0">
                    <span className="text-[8px] uppercase tracking-wider">{new Date(e.startDate).toLocaleString('default', { month: 'short' })}</span>
                    <span className="text-xs leading-none font-extrabold">{new Date(e.startDate).getDate()}</span>
                  </div>
                  <div>
                    <div className="font-bold text-slate-800">{e.title}</div>
                    <div className="text-[11px] text-slate-500 flex items-center space-x-2 mt-0.5">
                      <span>{e.category}</span>
                      <span>•</span>
                      <span>{e.location}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ApexCard>

          {/* Active Homework / Digital Diary */}
          <ApexCard
            id="region-homework"
            title="Digital Class Homework"
            subtitle="Recent assignments posted by faculty"
            icon={<Clock className="w-4 h-4" />}
            actions={
              <button
                onClick={() => onNavigate('HOMEWORK')}
                className="text-xs text-emerald-600 hover:underline font-semibold"
              >
                Open Diary
              </button>
            }
          >
            <div className="space-y-2 text-xs">
              {homework.slice(0, 3).map(hw => (
                <div key={hw.id} className="p-2.5 rounded-lg border border-slate-100 bg-slate-50/50">
                  <div className="font-semibold text-slate-800">{hw.title}</div>
                  <div className="text-[10px] text-slate-500 mt-1 flex justify-between items-center">
                    <span>Due: {hw.dueDate}</span>
                    <span className="font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">{hw.maxPoints} pts</span>
                  </div>
                </div>
              ))}
            </div>
          </ApexCard>
        </div>
      </div>
    </div>
  );
};
