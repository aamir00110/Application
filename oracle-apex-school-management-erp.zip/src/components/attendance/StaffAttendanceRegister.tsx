import React, { useState } from 'react';
import {
  UserCheck,
  Calendar,
  Save,
  CheckCircle2,
  Clock,
  Briefcase
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { AttendanceStatus } from '../../types';

export const StaffAttendanceRegister: React.FC = () => {
  const { staff, staffAttendance, saveStaffAttendance } = useSchool();
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );

  const [staffState, setStaffState] = useState<Record<string, { status: AttendanceStatus; checkInTime: string; checkOutTime: string }>>(() => {
    const init: Record<string, { status: AttendanceStatus; checkInTime: string; checkOutTime: string }> = {};
    staff.forEach(s => {
      init[s.id] = { status: 'PRESENT', checkInTime: '07:45', checkOutTime: '15:30' };
    });
    return init;
  });

  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleStatusChange = (staffId: string, status: AttendanceStatus) => {
    setStaffState(prev => ({
      ...prev,
      [staffId]: {
        ...prev[staffId],
        status
      }
    }));
  };

  const handleSave = () => {
    const records = staff.map(s => ({
      staffId: s.id,
      date: selectedDate,
      status: staffState[s.id]?.status || 'PRESENT',
      checkInTime: staffState[s.id]?.checkInTime || '07:45',
      checkOutTime: staffState[s.id]?.checkOutTime || '15:30'
    }));

    saveStaffAttendance(records);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <UserCheck className="w-5 h-5 text-blue-600" />
            <span>Staff & Faculty Daily Attendance Register (Page 51)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Biometric Sync: Check-in/check-out timestamp logging and late penalty rules.
          </p>
        </div>

        <button
          onClick={handleSave}
          className="px-4 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center space-x-2 transition-colors"
        >
          <Save className="w-4 h-4" />
          <span>Save Staff Log</span>
        </button>
      </div>

      {savedSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 flex items-center space-x-2 text-xs animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-bold">Staff attendance records successfully logged.</span>
        </div>
      )}

      {/* Date Header */}
      <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-2xs flex items-center space-x-3 text-xs">
        <span className="font-semibold text-slate-700">Attendance Date:</span>
        <input
          type="date"
          value={selectedDate}
          onChange={e => setSelectedDate(e.target.value)}
          className="px-2.5 py-1 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 font-medium"
        />
      </div>

      {/* Staff Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
              <th className="p-3">Staff Member</th>
              <th className="p-3">Department & Designation</th>
              <th className="p-3 text-center min-w-[280px]">Status</th>
              <th className="p-3">Check In</th>
              <th className="p-3">Check Out</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-800">
            {staff.map(s => {
              const currentStatus = staffState[s.id]?.status || 'PRESENT';

              return (
                <tr key={s.id} className="hover:bg-slate-50">
                  <td className="p-3">
                    <div className="flex items-center space-x-2.5">
                      <img
                        src={s.avatarUrl || 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80'}
                        alt={s.fullName}
                        className="w-7 h-7 rounded-full object-cover"
                      />
                      <span className="font-bold text-slate-900">{s.fullName}</span>
                    </div>
                  </td>
                  <td className="p-3 text-slate-600">
                    {s.designation} • <span className="text-blue-600 font-medium">{s.department}</span>
                  </td>
                  <td className="p-3 text-center">
                    <div className="inline-flex rounded-lg border border-slate-200 p-0.5 bg-slate-50 space-x-1">
                      {[
                        { id: 'PRESENT', label: 'Present', color: 'bg-emerald-600 text-white font-bold' },
                        { id: 'ABSENT', label: 'Absent', color: 'bg-rose-600 text-white font-bold' },
                        { id: 'LATE', label: 'Late', color: 'bg-amber-500 text-white font-bold' },
                        { id: 'ON_LEAVE', label: 'Leave', color: 'bg-blue-600 text-white font-bold' }
                      ].map(opt => {
                        const isSelected = currentStatus === opt.id;
                        return (
                          <button
                            key={opt.id}
                            type="button"
                            onClick={() => handleStatusChange(s.id, opt.id as any)}
                            className={`px-2.5 py-1 text-[11px] rounded transition-all ${
                              isSelected ? opt.color : 'text-slate-600 hover:bg-slate-200/60'
                            }`}
                          >
                            {opt.label}
                          </button>
                        );
                      })}
                    </div>
                  </td>
                  <td className="p-3">
                    <input
                      type="time"
                      value={staffState[s.id]?.checkInTime || '07:45'}
                      onChange={e =>
                        setStaffState(prev => ({
                          ...prev,
                          [s.id]: { ...prev[s.id], checkInTime: e.target.value }
                        }))
                      }
                      className="px-2 py-0.5 border border-slate-200 rounded font-mono text-xs"
                    />
                  </td>
                  <td className="p-3">
                    <input
                      type="time"
                      value={staffState[s.id]?.checkOutTime || '15:30'}
                      onChange={e =>
                        setStaffState(prev => ({
                          ...prev,
                          [s.id]: { ...prev[s.id], checkOutTime: e.target.value }
                        }))
                      }
                      className="px-2 py-0.5 border border-slate-200 rounded font-mono text-xs"
                    />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
