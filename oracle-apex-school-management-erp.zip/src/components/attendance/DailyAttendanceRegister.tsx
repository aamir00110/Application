import React, { useState, useEffect } from 'react';
import {
  CheckSquare,
  Calendar,
  Save,
  UserCheck,
  Users,
  CheckCircle2,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { ApexCard } from '../common/ApexCard';
import { AttendanceStatus } from '../../types';

export const DailyAttendanceRegister: React.FC = () => {
  const { classes, sections, students, studentAttendance, saveBulkAttendance } = useSchool();

  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [selectedClassId, setSelectedClassId] = useState<string>(classes[0]?.id || '');
  const [selectedSectionId, setSelectedSectionId] = useState<string>(sections[0]?.id || '');

  // Local map of studentId -> status and remarks
  const [attendanceState, setAttendanceState] = useState<Record<string, { status: AttendanceStatus; remarks: string }>>({});
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Filter students
  const filteredStudents = students.filter(
    s => s.classId === selectedClassId && s.sectionId === selectedSectionId && s.status === 'ACTIVE'
  );

  // Load existing records or default to PRESENT
  useEffect(() => {
    const nextState: Record<string, { status: AttendanceStatus; remarks: string }> = {};

    filteredStudents.forEach(s => {
      const existing = studentAttendance.find(
        r => r.studentId === s.id && r.date === selectedDate
      );
      if (existing) {
        nextState[s.id] = { status: existing.status, remarks: existing.remarks || '' };
      } else {
        nextState[s.id] = { status: 'PRESENT', remarks: '' };
      }
    });

    setAttendanceState(nextState);
    setSavedSuccess(false);
  }, [selectedDate, selectedClassId, selectedSectionId, students, studentAttendance]);

  const handleStatusChange = (studentId: string, status: AttendanceStatus) => {
    setAttendanceState(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        status
      }
    }));
  };

  const handleRemarksChange = (studentId: string, remarks: string) => {
    setAttendanceState(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        remarks
      }
    }));
  };

  const handleMarkAll = (status: AttendanceStatus) => {
    const updated: Record<string, { status: AttendanceStatus; remarks: string }> = {};
    filteredStudents.forEach(s => {
      updated[s.id] = {
        status,
        remarks: attendanceState[s.id]?.remarks || ''
      };
    });
    setAttendanceState(updated);
  };

  const handleSave = () => {
    const records = filteredStudents.map(s => ({
      studentId: s.id,
      date: selectedDate,
      status: attendanceState[s.id]?.status || 'PRESENT',
      remarks: attendanceState[s.id]?.remarks || undefined
    }));

    saveBulkAttendance(records);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  // Metrics for today's batch
  const total = filteredStudents.length;
  const stateValues = Object.values(attendanceState) as { status: string; remarks?: string }[];
  const presentCount = stateValues.filter(v => v.status === 'PRESENT').length;
  const absentCount = stateValues.filter(v => v.status === 'ABSENT').length;
  const lateCount = stateValues.filter(v => v.status === 'LATE').length;
  const leaveCount = stateValues.filter(v => v.status === 'ON_LEAVE' || v.status === 'HALF_DAY').length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <CheckSquare className="w-5 h-5 text-blue-600" />
            <span>Daily Student Bulk Attendance (Page 50)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Editable Grid: High-speed barcode/register marking with automatic SMS alert flags for absentees.
          </p>
        </div>

        <button
          id="btn-save-attendance"
          onClick={handleSave}
          disabled={filteredStudents.length === 0}
          className="px-4 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-lg shadow-sm flex items-center space-x-2 transition-colors"
        >
          <Save className="w-4 h-4" />
          <span>Commit Attendance to Database</span>
        </button>
      </div>

      {savedSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 flex items-center space-x-2 text-xs animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-bold">Attendance Register committed successfully to Oracle Database.</span>
        </div>
      )}

      {/* Filter Header */}
      <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div>
            <label className="block font-semibold mb-1 text-slate-700">Attendance Date *</label>
            <input
              type="date"
              value={selectedDate}
              onChange={e => setSelectedDate(e.target.value)}
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 font-medium"
            />
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700">Class Cohort *</label>
            <select
              value={selectedClassId}
              onChange={e => {
                const newCId = e.target.value;
                setSelectedClassId(newCId);
                const sec = sections.find(s => s.classId === newCId);
                setSelectedSectionId(sec?.id || '');
              }}
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white font-medium"
            >
              {classes.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700">Section *</label>
            <select
              value={selectedSectionId}
              onChange={e => setSelectedSectionId(e.target.value)}
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white font-medium"
            >
              {sections.filter(s => s.classId === selectedClassId).map(s => (
                <option key={s.id} value={s.id}>{s.name} ({s.roomNumber || 'Main'})</option>
              ))}
            </select>
          </div>
        </div>

        {/* Quick Batch Controls & Counters */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100 text-xs">
          <div className="flex items-center space-x-2">
            <span className="font-semibold text-slate-600">Fast Bulk Mark:</span>
            <button
              onClick={() => handleMarkAll('PRESENT')}
              className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-semibold rounded border border-emerald-200"
            >
              All Present
            </button>
            <button
              onClick={() => handleMarkAll('ABSENT')}
              className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-800 font-semibold rounded border border-rose-200"
            >
              All Absent
            </button>
          </div>

          <div className="flex items-center space-x-3 font-medium">
            <span className="text-emerald-700">Present: <strong>{presentCount}</strong></span>
            <span className="text-rose-700">Absent: <strong>{absentCount}</strong></span>
            <span className="text-amber-700">Late: <strong>{lateCount}</strong></span>
            <span className="text-blue-700">Leave: <strong>{leaveCount}</strong></span>
            <span className="text-slate-400">|</span>
            <span className="text-slate-700">Total: <strong>{total}</strong></span>
          </div>
        </div>
      </div>

      {/* Register Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 select-none">
              <th className="p-3 w-16">Roll</th>
              <th className="p-3">Student Name</th>
              <th className="p-3">Admission No</th>
              <th className="p-3 text-center min-w-[300px]">Attendance Status</th>
              <th className="p-3">Remarks / Reason</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-800">
            {filteredStudents.length > 0 ? (
              filteredStudents.map(student => {
                const currentStatus = attendanceState[student.id]?.status || 'PRESENT';
                const currentRemarks = attendanceState[student.id]?.remarks || '';

                return (
                  <tr key={student.id} className="hover:bg-slate-50 transition-colors">
                    <td className="p-3 font-mono font-bold text-slate-700">{student.rollNo}</td>
                    <td className="p-3">
                      <div className="flex items-center space-x-2.5">
                        <img
                          src={student.avatarUrl || 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80'}
                          alt={student.fullName}
                          className="w-7 h-7 rounded-full object-cover"
                        />
                        <span className="font-bold text-slate-900">{student.fullName}</span>
                      </div>
                    </td>
                    <td className="p-3 font-mono text-blue-700">{student.admissionNo}</td>
                    <td className="p-3 text-center">
                      <div className="inline-flex rounded-lg border border-slate-200 p-0.5 bg-slate-50 space-x-1">
                        {[
                          { id: 'PRESENT', label: 'Present', color: 'bg-emerald-600 text-white font-bold shadow-2xs' },
                          { id: 'ABSENT', label: 'Absent', color: 'bg-rose-600 text-white font-bold shadow-2xs' },
                          { id: 'LATE', label: 'Late', color: 'bg-amber-500 text-white font-bold shadow-2xs' },
                          { id: 'HALF_DAY', label: 'Half Day', color: 'bg-purple-600 text-white font-bold shadow-2xs' },
                          { id: 'ON_LEAVE', label: 'Leave', color: 'bg-blue-600 text-white font-bold shadow-2xs' }
                        ].map(opt => {
                          const isSelected = currentStatus === opt.id;
                          return (
                            <button
                              key={opt.id}
                              type="button"
                              onClick={() => handleStatusChange(student.id, opt.id as any)}
                              className={`px-2.5 py-1 text-[11px] rounded transition-all ${
                                isSelected ? opt.color : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                              }`}
                            >
                              {opt.label}
                            </button>
                          );
                        })}
                      </div>
                    </td>
                    <td className="p-3">
                      <input
                        type="text"
                        value={currentRemarks}
                        onChange={e => handleRemarksChange(student.id, e.target.value)}
                        placeholder="e.g. Doctor appointment"
                        className="w-full px-2 py-1 text-xs border border-slate-200 rounded focus:ring-1 focus:ring-blue-500 focus:outline-none"
                      />
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={5} className="p-8 text-center text-slate-400 italic">
                  No active students enrolled in the selected class and section.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
