import React from 'react';
import {
  LayoutDashboard,
  GraduationCap,
  UserPlus,
  Users,
  BookOpen,
  CalendarDays,
  Clock,
  CheckSquare,
  Award,
  CreditCard,
  Receipt,
  DollarSign,
  Briefcase,
  BookMarked,
  Bus,
  Package,
  AlertCircle,
  FileCheck2,
  FileSpreadsheet,
  Settings,
  ShieldCheck,
  Database,
  ChevronRight,
  TrendingUp,
  FileText,
  UserCheck
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { UserRole } from '../../types';

export type NavigationPage =
  | 'DASHBOARD'
  | 'STUDENT_DIRECTORY'
  | 'STUDENT_ADMISSION'
  | 'STUDENT_PROMOTION'
  | 'PARENTS'
  | 'ACADEMICS_CLASSES'
  | 'ACADEMICS_SUBJECTS'
  | 'ACADEMICS_TIMETABLE'
  | 'STAFF_DIRECTORY'
  | 'STAFF_LEAVE'
  | 'ATTENDANCE_STUDENTS'
  | 'ATTENDANCE_STAFF'
  | 'EXAMS_MASTER'
  | 'EXAMS_MARKS_ENTRY'
  | 'EXAMS_REPORT_CARDS'
  | 'FEES_STRUCTURE'
  | 'FEES_COLLECTION'
  | 'FEES_OUTSTANDING'
  | 'PAYROLL'
  | 'EXPENSES'
  | 'HOMEWORK'
  | 'NOTICES_EVENTS'
  | 'LIBRARY'
  | 'TRANSPORT'
  | 'INVENTORY'
  | 'COMPLAINTS'
  | 'CERTIFICATES'
  | 'REPORTS_CENTER'
  | 'ORACLE_APEX_HUB'
  | 'SETTINGS'
  | 'USER_MGMT'
  | 'AUDIT_LOGS';

interface ApexSidebarProps {
  currentPage: NavigationPage;
  onNavigate: (page: NavigationPage) => void;
  isOpen: boolean;
}

interface NavItem {
  id: NavigationPage;
  label: string;
  pageNumber: number;
  icon: React.ReactNode;
  rolesAllowed?: UserRole[];
}

interface NavCategory {
  title: string;
  items: NavItem[];
}

export const ApexSidebar: React.FC<ApexSidebarProps> = ({
  currentPage,
  onNavigate,
  isOpen
}) => {
  const { currentUser } = useSchool();

  const categories: NavCategory[] = [
    {
      title: "Core Operations",
      items: [
        { id: 'DASHBOARD', label: 'Executive Dashboard', pageNumber: 1, icon: <LayoutDashboard className="w-4 h-4" /> }
      ]
    },
    {
      title: "Students & Admissions",
      items: [
        { id: 'STUDENT_DIRECTORY', label: 'Student Directory (Roster)', pageNumber: 10, icon: <GraduationCap className="w-4 h-4" /> },
        { id: 'STUDENT_ADMISSION', label: 'Admission Enrollment Form', pageNumber: 11, icon: <UserPlus className="w-4 h-4" />, rolesAllowed: ['SUPER_ADMIN', 'SCHOOL_ADMIN', 'PRINCIPAL', 'RECEPTIONIST'] },
        { id: 'STUDENT_PROMOTION', label: 'Student Promotion & Transfer', pageNumber: 15, icon: <TrendingUp className="w-4 h-4" />, rolesAllowed: ['SUPER_ADMIN', 'SCHOOL_ADMIN', 'PRINCIPAL'] },
        { id: 'PARENTS', label: 'Parent / Guardian Directory', pageNumber: 20, icon: <Users className="w-4 h-4" /> }
      ]
    },
    {
      title: "Academics & Schedule",
      items: [
        { id: 'ACADEMICS_CLASSES', label: 'Classes & Sections Master', pageNumber: 30, icon: <BookOpen className="w-4 h-4" /> },
        { id: 'ACADEMICS_SUBJECTS', label: 'Curriculum & Subjects', pageNumber: 31, icon: <FileText className="w-4 h-4" /> },
        { id: 'ACADEMICS_TIMETABLE', label: 'Timetable Matrix', pageNumber: 32, icon: <Clock className="w-4 h-4" /> },
        { id: 'HOMEWORK', label: 'Digital Homework & Diary', pageNumber: 90, icon: <FileSpreadsheet className="w-4 h-4" /> }
      ]
    },
    {
      title: "Staff & Faculty HR",
      items: [
        { id: 'STAFF_DIRECTORY', label: 'Faculty & Staff Directory', pageNumber: 40, icon: <Briefcase className="w-4 h-4" /> },
        { id: 'STAFF_LEAVE', label: 'Leave Requests & Approvals', pageNumber: 45, icon: <CalendarDays className="w-4 h-4" /> }
      ]
    },
    {
      title: "Attendance Engine",
      items: [
        { id: 'ATTENDANCE_STUDENTS', label: 'Daily Student Bulk Register', pageNumber: 50, icon: <CheckSquare className="w-4 h-4" /> },
        { id: 'ATTENDANCE_STAFF', label: 'Staff Attendance Register', pageNumber: 51, icon: <UserCheck className="w-4 h-4" />, rolesAllowed: ['SUPER_ADMIN', 'SCHOOL_ADMIN', 'PRINCIPAL'] }
      ]
    },
    {
      title: "Examinations & Grading",
      items: [
        { id: 'EXAMS_MASTER', label: 'Exam Schedules & Types', pageNumber: 60, icon: <Award className="w-4 h-4" /> },
        { id: 'EXAMS_MARKS_ENTRY', label: 'Bulk Marks Entry Sheet', pageNumber: 61, icon: <FileText className="w-4 h-4" />, rolesAllowed: ['SUPER_ADMIN', 'SCHOOL_ADMIN', 'PRINCIPAL', 'TEACHER'] },
        { id: 'EXAMS_REPORT_CARDS', label: 'Official Report Cards', pageNumber: 62, icon: <Award className="w-4 h-4" /> }
      ]
    },
    {
      title: "Accounts & Financials",
      items: [
        { id: 'FEES_STRUCTURE', label: 'Class Fee Setup', pageNumber: 70, icon: <CreditCard className="w-4 h-4" />, rolesAllowed: ['SUPER_ADMIN', 'SCHOOL_ADMIN', 'ACCOUNTANT'] },
        { id: 'FEES_COLLECTION', label: 'Fee Collection & Challans', pageNumber: 71, icon: <Receipt className="w-4 h-4" />, rolesAllowed: ['SUPER_ADMIN', 'SCHOOL_ADMIN', 'ACCOUNTANT', 'PARENT', 'STUDENT'] },
        { id: 'FEES_OUTSTANDING', label: 'Outstanding Dues Ledger', pageNumber: 72, icon: <DollarSign className="w-4 h-4" />, rolesAllowed: ['SUPER_ADMIN', 'SCHOOL_ADMIN', 'ACCOUNTANT', 'PRINCIPAL'] },
        { id: 'PAYROLL', label: 'Staff Monthly Payroll', pageNumber: 80, icon: <DollarSign className="w-4 h-4" />, rolesAllowed: ['SUPER_ADMIN', 'SCHOOL_ADMIN', 'ACCOUNTANT'] },
        { id: 'EXPENSES', label: 'Expenditure Vouchers', pageNumber: 85, icon: <CreditCard className="w-4 h-4" />, rolesAllowed: ['SUPER_ADMIN', 'SCHOOL_ADMIN', 'ACCOUNTANT'] }
      ]
    },
    {
      title: "Logistics & Administration",
      items: [
        { id: 'NOTICES_EVENTS', label: 'Notice Board & Events', pageNumber: 95, icon: <CalendarDays className="w-4 h-4" /> },
        { id: 'LIBRARY', label: 'Library Circulation Desk', pageNumber: 100, icon: <BookMarked className="w-4 h-4" /> },
        { id: 'TRANSPORT', label: 'Transport Fleet & Routes', pageNumber: 105, icon: <Bus className="w-4 h-4" /> },
        { id: 'INVENTORY', label: 'Assets & Inventory', pageNumber: 110, icon: <Package className="w-4 h-4" /> },
        { id: 'COMPLAINTS', label: 'Complaints & Grievances', pageNumber: 115, icon: <AlertCircle className="w-4 h-4" /> },
        { id: 'CERTIFICATES', label: 'Official Certificates Hub', pageNumber: 120, icon: <FileCheck2 className="w-4 h-4" />, rolesAllowed: ['SUPER_ADMIN', 'SCHOOL_ADMIN', 'PRINCIPAL', 'RECEPTIONIST'] }
      ]
    },
    {
      title: "Reporting & Database Specs",
      items: [
        { id: 'REPORTS_CENTER', label: 'Executive Reports Suite', pageNumber: 130, icon: <FileSpreadsheet className="w-4 h-4" /> },
        { id: 'ORACLE_APEX_HUB', label: 'Oracle APEX & SQL Blueprint', pageNumber: 200, icon: <Database className="w-4 h-4 text-emerald-400" /> }
      ]
    },
    {
      title: "System Administration",
      items: [
        { id: 'SETTINGS', label: 'School Configuration', pageNumber: 140, icon: <Settings className="w-4 h-4" />, rolesAllowed: ['SUPER_ADMIN', 'SCHOOL_ADMIN'] },
        { id: 'USER_MGMT', label: 'Security & User Accounts', pageNumber: 145, icon: <ShieldCheck className="w-4 h-4" />, rolesAllowed: ['SUPER_ADMIN'] },
        { id: 'AUDIT_LOGS', label: 'System Audit Trail', pageNumber: 150, icon: <Clock className="w-4 h-4" />, rolesAllowed: ['SUPER_ADMIN', 'SCHOOL_ADMIN'] }
      ]
    }
  ];

  if (!isOpen) return null;

  return (
    <aside className="w-64 bg-[#1E293B] text-slate-200 flex flex-col shrink-0 h-[calc(100vh-61px)] overflow-y-auto custom-scrollbar select-none">
      {/* Brand Header / Context */}
      <div className="p-4 border-b border-slate-800 bg-[#1E293B] sticky top-0 z-10">
        <div className="flex items-center space-x-3 px-2 py-1">
          <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center font-bold text-white text-base shadow-xs">
            S
          </div>
          <div>
            <span className="text-white font-bold text-sm tracking-tight block">ScholarERP APEX</span>
            <span className="text-[10px] text-slate-400 tracking-wider uppercase font-semibold">
              Role: <span className="text-emerald-400">{currentUser.role.replace('_', ' ')}</span>
            </span>
          </div>
        </div>
      </div>

      <nav className="flex-1 py-4 px-3 space-y-4">
        {categories.map((cat, catIdx) => {
          // Filter items based on roles allowed
          const visibleItems = cat.items.filter(item => {
            if (!item.rolesAllowed) return true;
            return item.rolesAllowed.includes(currentUser.role);
          });

          if (visibleItems.length === 0) return null;

          return (
            <div key={catIdx} className="space-y-1">
              <div className="text-slate-400 text-[10px] uppercase font-semibold mb-1.5 px-3 tracking-widest">
                {cat.title}
              </div>
              <div className="space-y-0.5">
                {visibleItems.map(item => {
                  const isActive = currentPage === item.id;
                  return (
                    <button
                      key={item.id}
                      id={`nav-item-${item.id.toLowerCase()}`}
                      onClick={() => onNavigate(item.id)}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs transition-all group ${
                        isActive
                          ? 'bg-emerald-500/10 text-emerald-400 font-medium'
                          : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center space-x-3 truncate">
                        <span className={isActive ? 'text-emerald-400' : 'text-slate-400 group-hover:text-slate-200'}>
                          {item.icon}
                        </span>
                        <span className="text-sm font-medium truncate">{item.label}</span>
                      </div>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${
                        isActive ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'
                      }`}>
                        p{item.pageNumber}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </nav>

      {/* Footer Profile Info */}
      <div className="p-4 border-t border-slate-700 bg-[#1E293B]">
        <div className="flex items-center space-x-3 px-1">
          <div className="w-8 h-8 rounded-full bg-emerald-600/30 border border-emerald-500/40 flex items-center justify-center text-xs font-bold text-emerald-300">
            {currentUser.fullName.split(' ').map(n => n[0]).join('').slice(0, 2)}
          </div>
          <div className="flex-1 overflow-hidden">
            <p className="text-xs text-white font-medium truncate">{currentUser.fullName}</p>
            <p className="text-[10px] text-slate-400 truncate">{currentUser.role.replace('_', ' ')}</p>
          </div>
        </div>
      </div>
    </aside>
  );
};
