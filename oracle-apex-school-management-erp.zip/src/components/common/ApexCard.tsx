import React from 'react';

interface ApexCardProps {
  id?: string;
  title: string;
  subtitle?: string;
  icon?: React.ReactNode;
  actions?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  headerClassName?: string;
}

export const ApexCard: React.FC<ApexCardProps> = ({
  id,
  title,
  subtitle,
  icon,
  actions,
  children,
  className = '',
  headerClassName = ''
}) => {
  return (
    <div
      id={id}
      className={`bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden ${className}`}
    >
      <div className={`px-5 py-4 border-b border-slate-100 bg-white flex flex-wrap items-center justify-between gap-2 ${headerClassName}`}>
        <div className="flex items-center space-x-2.5">
          {icon && <span className="text-emerald-600 shrink-0">{icon}</span>}
          <div>
            <h3 className="text-sm font-bold text-slate-800 tracking-tight leading-snug">
              {title}
            </h3>
            {subtitle && (
              <p className="text-xs text-slate-500 leading-none mt-1">
                {subtitle}
              </p>
            )}
          </div>
        </div>
        {actions && <div className="flex items-center space-x-2">{actions}</div>}
      </div>
      <div className="p-5">{children}</div>
    </div>
  );
};
