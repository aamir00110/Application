import React from 'react';

interface ApexStatCardProps {
  id?: string;
  title: string;
  value: string | number;
  subtitle?: string;
  icon: React.ReactNode;
  trend?: {
    value: string;
    isPositive: boolean;
  };
  colorTheme?: 'blue' | 'emerald' | 'amber' | 'indigo' | 'rose' | 'purple';
  onClick?: () => void;
}

export const ApexStatCard: React.FC<ApexStatCardProps> = ({
  id,
  title,
  value,
  subtitle,
  icon,
  trend,
  colorTheme = 'blue',
  onClick
}) => {
  const themeClasses = {
    blue: {
      bar: 'bg-blue-500',
      trend: 'text-blue-600',
      iconBg: 'bg-blue-50 text-blue-600'
    },
    emerald: {
      bar: 'bg-emerald-500',
      trend: 'text-emerald-600',
      iconBg: 'bg-emerald-50 text-emerald-600'
    },
    amber: {
      bar: 'bg-amber-500',
      trend: 'text-amber-600',
      iconBg: 'bg-amber-50 text-amber-600'
    },
    indigo: {
      bar: 'bg-indigo-500',
      trend: 'text-indigo-600',
      iconBg: 'bg-indigo-50 text-indigo-600'
    },
    rose: {
      bar: 'bg-rose-500',
      trend: 'text-rose-600',
      iconBg: 'bg-rose-50 text-rose-600'
    },
    purple: {
      bar: 'bg-purple-500',
      trend: 'text-purple-600',
      iconBg: 'bg-purple-50 text-purple-600'
    }
  }[colorTheme];

  return (
    <div
      id={id}
      onClick={onClick}
      className={`bg-white p-5 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all ${
        onClick ? 'cursor-pointer hover:border-slate-300' : ''
      }`}
    >
      <div className="flex items-center justify-between mb-2">
        <span className="text-slate-500 text-xs font-semibold uppercase tracking-wider">
          {title}
        </span>
        {trend ? (
          <span className={`text-xs font-medium ${trend.isPositive ? 'text-emerald-600' : 'text-rose-600'}`}>
            {trend.value}
          </span>
        ) : (
          <div className={`w-7 h-7 rounded-md ${themeClasses.iconBg} flex items-center justify-center text-xs`}>
            {icon}
          </div>
        )}
      </div>

      <div className="text-3xl font-bold text-slate-800 tracking-tight">
        {value}
      </div>

      {subtitle && (
        <p className="text-xs text-slate-500 mt-1 truncate">
          {subtitle}
        </p>
      )}

      {/* Natural Tones Progress Meter Line */}
      <div className="mt-3 w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
        <div className={`${themeClasses.bar} h-full w-[85%] rounded-full`} />
      </div>
    </div>
  );
};
