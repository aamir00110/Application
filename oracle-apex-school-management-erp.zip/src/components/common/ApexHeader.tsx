import React, { useState } from 'react';
import {
  Menu,
  Bell,
  Search,
  Database,
  UserCheck,
  ChevronDown,
  Sparkles,
  School,
  LogOut,
  RefreshCw,
  FileCode2,
  Calendar,
  CheckCircle2
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { UserRole } from '../../types';

interface ApexHeaderProps {
  sidebarOpen: boolean;
  setSidebarOpen: React.Dispatch<React.SetStateAction<boolean>>;
  onOpenArchitecture: () => void;
}

export const ApexHeader: React.FC<ApexHeaderProps> = ({
  sidebarOpen,
  setSidebarOpen,
  onOpenArchitecture
}) => {
  const { currentUser, switchUserRole, settings, resetToDefaultData, notices } = useSchool();
  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);
  const [noticesOpen, setNoticesOpen] = useState(false);
  const [confirmResetOpen, setConfirmResetOpen] = useState(false);

  const roles: { role: UserRole; label: string; desc: string }[] = [
    { role: 'SUPER_ADMIN', label: 'Super Admin', desc: 'Full system & database architecture access' },
    { role: 'SCHOOL_ADMIN', label: 'School Admin', desc: 'Campus operations & academic configuration' },
    { role: 'PRINCIPAL', label: 'Principal', desc: 'Approvals, academic oversight & appraisals' },
    { role: 'TEACHER', label: 'Faculty / Teacher', desc: 'Attendance, marks grading & timetable' },
    { role: 'ACCOUNTANT', label: 'Accountant', desc: 'Fee challans, payment receipts & payroll' },
    { role: 'RECEPTIONIST', label: 'Front Desk', desc: 'Admissions, inquiries & visitor logs' },
    { role: 'STUDENT', label: 'Student Portal', desc: 'Report card, homework & attendance' },
    { role: 'PARENT', label: 'Parent Portal', desc: 'Fee dues, ward progress & circulars' }
  ];

  return (
    <header className="sticky top-0 z-40 bg-white text-slate-800 shadow-xs border-b border-slate-200">
      <div className="flex items-center justify-between px-4 sm:px-6 py-3">
        {/* Left: Brand & Sidebar toggle */}
        <div className="flex items-center space-x-3">
          <button
            id="btn-toggle-sidebar"
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 rounded-lg hover:bg-slate-100 text-slate-600 transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-500"
            title="Toggle Navigation Menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 bg-emerald-500 rounded-lg flex items-center justify-center font-bold text-white shadow-xs">
              <School className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold tracking-tight text-slate-800 text-base">
                  {settings.schoolName}
                </span>
                <span className="hidden md:inline-block px-2 py-0.5 text-[10px] font-bold bg-emerald-100 text-emerald-700 rounded uppercase tracking-wide">
                  Active Session: {settings.currentAcademicSession}
                </span>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">
                ScholarERP Enterprise Suite • APEX Universal Theme
              </p>
            </div>
          </div>
        </div>

        {/* Center/Right: Role Switcher & Shortcuts */}
        <div className="flex items-center space-x-2 md:space-x-3">
          {/* Quick Oracle DDL Architecture Inspector Button */}
          <button
            id="btn-header-architecture"
            onClick={onOpenArchitecture}
            className="flex items-center space-x-1.5 px-3 py-1.5 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg shadow-xs transition-all"
            title="Oracle DDL & APEX Architecture Hub"
          >
            <Database className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Oracle & SQL Specs</span>
          </button>

          {/* Role Switcher Pill */}
          <div className="relative">
            <button
              id="btn-role-switcher-toggle"
              onClick={() => setRoleDropdownOpen(!roleDropdownOpen)}
              className="flex items-center space-x-2 px-3 py-1.5 text-xs font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg border border-slate-200 transition-colors"
            >
              <div className="w-2 h-2 rounded-full bg-emerald-500" />
              <div className="text-left hidden sm:block">
                <div className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">Active Role</div>
                <div className="font-bold text-slate-800 leading-tight">{currentUser.role.replace('_', ' ')}</div>
              </div>
              <div className="sm:hidden font-semibold text-slate-800">{currentUser.role}</div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
            </button>

            {roleDropdownOpen && (
              <div className="absolute right-0 mt-2 w-72 bg-white rounded-xl shadow-xl border border-slate-200 text-slate-800 py-2 z-50 animate-in fade-in slide-in-from-top-2">
                <div className="px-3.5 py-2 border-b border-slate-100 mb-1">
                  <p className="text-xs font-bold text-slate-600 uppercase tracking-wider">Switch Security Profile</p>
                  <p className="text-[11px] text-slate-400">Tests role-based page authorization in real-time</p>
                </div>
                <div className="max-h-80 overflow-y-auto custom-scrollbar">
                  {roles.map(r => (
                    <button
                      key={r.role}
                      onClick={() => {
                        switchUserRole(r.role);
                        setRoleDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3.5 py-2 text-xs hover:bg-slate-50 flex items-start space-x-2.5 transition-colors ${
                        currentUser.role === r.role ? 'bg-emerald-50 text-emerald-800 border-l-4 border-emerald-600 font-semibold' : 'text-slate-700'
                      }`}
                    >
                      <UserCheck className={`w-4 h-4 mt-0.5 ${currentUser.role === r.role ? 'text-emerald-600' : 'text-slate-400'}`} />
                      <div>
                        <div className="font-semibold text-slate-800">{r.label}</div>
                        <div className="text-[11px] text-slate-500 leading-tight">{r.desc}</div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Notification Center */}
          <div className="relative">
            <button
              id="btn-header-notices"
              onClick={() => setNoticesOpen(!noticesOpen)}
              className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 relative transition-colors"
              title="Notices & Announcements"
            >
              <Bell className="w-4 h-4" />
              {notices.length > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-emerald-500 rounded-full ring-2 ring-white" />
              )}
            </button>

            {noticesOpen && (
              <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-xl border border-slate-200 text-slate-800 py-2 z-50">
                <div className="px-4 py-2 border-b border-slate-100 flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800">Notice Board & Circulars</span>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-bold">{notices.length} New</span>
                </div>
                <div className="max-h-64 overflow-y-auto divide-y divide-slate-100">
                  {notices.map(n => (
                    <div key={n.id} className="p-3 hover:bg-slate-50 text-xs">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-semibold text-slate-800">{n.title}</span>
                        <span className="text-[10px] text-slate-400">{n.publishDate}</span>
                      </div>
                      <p className="text-slate-600 text-[11px] line-clamp-2">{n.content}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Quick Database Reset */}
          <button
            id="btn-header-reset-db"
            onClick={() => setConfirmResetOpen(true)}
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-rose-50 hover:text-rose-600 text-slate-500 flex items-center justify-center transition-colors"
            title="Reset DB to Default Sample Data"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Confirmation Modal for DB Reset */}
      {confirmResetOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white text-slate-800 rounded-xl max-w-md w-full p-5 shadow-2xl border border-slate-200">
            <h3 className="text-base font-bold text-slate-900 mb-2 flex items-center space-x-2">
              <RefreshCw className="w-5 h-5 text-amber-600" />
              <span>Reset ERP Database to Initial State?</span>
            </h3>
            <p className="text-xs text-slate-600 mb-4 leading-relaxed">
              This will re-seed all Oracle APEX tables with default high-school sample records including classes, teachers, student rosters, exam marks, fee receipts, and audit logs.
            </p>
            <div className="flex justify-end space-x-2">
              <button
                onClick={() => setConfirmResetOpen(false)}
                className="px-3 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-md"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  resetToDefaultData();
                  setConfirmResetOpen(false);
                }}
                className="px-4 py-1.5 text-xs font-semibold bg-rose-600 hover:bg-rose-700 text-white rounded-md shadow-sm"
              >
                Confirm Reset
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
