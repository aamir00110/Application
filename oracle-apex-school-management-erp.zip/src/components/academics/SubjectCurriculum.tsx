import React, { useState } from 'react';
import {
  FileText,
  Plus,
  BookOpen,
  Award,
  Layers
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { Subject } from '../../types';
import { InteractiveReport, ColumnDef } from '../common/InteractiveReport';
import { ApexModal } from '../common/ApexModal';

export const SubjectCurriculum: React.FC = () => {
  const { subjects, classes, addSubject } = useSchool();
  const [modalOpen, setModalOpen] = useState(false);
  const [newSubject, setNewSubject] = useState({
    name: '',
    code: '',
    type: 'CORE' as 'CORE' | 'ELECTIVE' | 'OPTIONAL',
    totalMarks: 100,
    passingMarks: 40,
    creditHours: 4,
    classId: classes[0]?.id || ''
  });

  const columns: ColumnDef<Subject>[] = [
    {
      header: "Subject Title",
      accessorKey: "name",
      cell: (s: Subject) => (
        <div>
          <div className="font-bold text-slate-900">{s.name}</div>
          <div className="text-[11px] text-slate-500 font-mono">Code: {s.code}</div>
        </div>
      )
    },
    {
      header: "Type",
      accessorKey: "type",
      cell: (s: Subject) => (
        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
          s.type === 'CORE'
            ? 'bg-blue-100 text-blue-800'
            : s.type === 'ELECTIVE'
            ? 'bg-purple-100 text-purple-800'
            : 'bg-slate-100 text-slate-700'
        }`}>
          {s.type}
        </span>
      )
    },
    {
      header: "Curriculum Class",
      cell: (s: Subject) => {
        const c = classes.find(cls => cls.id === s.classId);
        return <span className="font-semibold text-slate-800">{c?.name || 'Universal'}</span>;
      }
    },
    {
      header: "Total Marks",
      accessorKey: "totalMarks",
      align: "center",
      cell: (s: Subject) => (
        <span className="font-mono font-bold text-slate-800">{s.totalMarks}</span>
      )
    },
    {
      header: "Passing Criteria",
      accessorKey: "passMarks",
      align: "center",
      cell: (s: Subject) => (
        <span className="font-mono font-semibold text-emerald-700">{s.passMarks} ({Math.round((s.passMarks / s.totalMarks) * 100)}%)</span>
      )
    },
    {
      header: "Credit Hours",
      accessorKey: "credits",
      align: "center",
      cell: (s: Subject) => (
        <span className="font-mono bg-slate-100 px-2 py-0.5 rounded font-semibold text-slate-700">
          {s.credits} hrs/wk
        </span>
      )
    }
  ];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubject.name.trim() || !newSubject.code.trim()) {
      alert("Please provide Subject Name and Code.");
      return;
    }
    addSubject(newSubject);
    setModalOpen(false);
    setNewSubject({
      name: '',
      code: '',
      type: 'CORE',
      totalMarks: 100,
      passingMarks: 40,
      creditHours: 4,
      classId: classes[0]?.id || ''
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <FileText className="w-5 h-5 text-blue-600" />
            <span>Curriculum & Subject Catalog (Page 31)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Course registry, grading schema parameters, passing benchmarks, and weekly credit allocations.
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="px-3.5 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center space-x-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>Add Subject</span>
        </button>
      </div>

      <InteractiveReport
        title="Subjects Catalog"
        data={subjects}
        columns={columns}
        searchPlaceholder="Search subject name, code, or class..."
        searchFilterKeys={['name', 'code', 'type']}
      />

      <ApexModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Add Academic Subject"
        subtitle="Catalog new subject into Oracle APEX TBL_SUBJECTS"
      >
        <form onSubmit={handleSave} className="space-y-3 text-xs">
          <div>
            <label className="block font-semibold mb-1 text-slate-700">Subject Name *</label>
            <input
              type="text"
              required
              value={newSubject.name}
              onChange={e => setNewSubject({ ...newSubject, name: e.target.value })}
              placeholder="e.g. Advanced Physics & Mechanics"
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Subject Code *</label>
              <input
                type="text"
                required
                value={newSubject.code}
                onChange={e => setNewSubject({ ...newSubject, code: e.target.value })}
                placeholder="e.g. PHY-101"
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Subject Type</label>
              <select
                value={newSubject.type}
                onChange={e => setNewSubject({ ...newSubject, type: e.target.value as any })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                <option value="CORE">Core</option>
                <option value="ELECTIVE">Elective</option>
                <option value="OPTIONAL">Optional</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Total Marks</label>
              <input
                type="number"
                value={newSubject.totalMarks}
                onChange={e => setNewSubject({ ...newSubject, totalMarks: Number(e.target.value) })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Passing Marks</label>
              <input
                type="number"
                value={newSubject.passingMarks}
                onChange={e => setNewSubject({ ...newSubject, passingMarks: Number(e.target.value) })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Credit Hours</label>
              <input
                type="number"
                value={newSubject.creditHours}
                onChange={e => setNewSubject({ ...newSubject, creditHours: Number(e.target.value) })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700">Assigned Class *</label>
            <select
              value={newSubject.classId}
              onChange={e => setNewSubject({ ...newSubject, classId: e.target.value })}
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
            >
              {classes.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-bold bg-blue-600 hover:bg-blue-700 text-white rounded shadow-sm"
            >
              Save Subject
            </button>
          </div>
        </form>
      </ApexModal>
    </div>
  );
};
