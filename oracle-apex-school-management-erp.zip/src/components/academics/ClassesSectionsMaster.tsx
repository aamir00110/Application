import React, { useState } from 'react';
import {
  BookOpen,
  Plus,
  Edit2,
  Trash2,
  Users,
  GraduationCap,
  Sparkles,
  Layers
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { ApexCard } from '../common/ApexCard';
import { ApexModal } from '../common/ApexModal';
import { AcademicClass, Section } from '../../types';

export const ClassesSectionsMaster: React.FC = () => {
  const { classes, sections, students, staff, addClass, addSection } = useSchool();

  const [classModalOpen, setClassModalOpen] = useState(false);
  const [sectionModalOpen, setSectionModalOpen] = useState(false);

  const [newClass, setNewClass] = useState({
    name: '',
    code: '',
    capacity: 40,
    description: ''
  });

  const [newSection, setNewSection] = useState({
    classId: classes[0]?.id || '',
    name: '',
    roomNumber: 'Room 101',
    maxCapacity: 35,
    classTeacherId: staff[0]?.id || ''
  });

  const handleSaveClass = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClass.name.trim() || !newClass.code.trim()) {
      alert("Please provide Class Name and Code.");
      return;
    }
    addClass(newClass);
    setClassModalOpen(false);
    setNewClass({ name: '', code: '', capacity: 40, description: '' });
  };

  const handleSaveSection = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSection.name.trim()) {
      alert("Please provide Section Name.");
      return;
    }
    addSection(newSection);
    setSectionModalOpen(false);
    setNewSection({
      classId: classes[0]?.id || '',
      name: '',
      roomNumber: 'Room 101',
      maxCapacity: 35,
      classTeacherId: staff[0]?.id || ''
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <BookOpen className="w-5 h-5 text-blue-600" />
            <span>Classes & Sections Master (Page 30)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Master-Detail Grid: Academic cohorts, branch divisions, class teacher allocation, and room planning.
          </p>
        </div>

        <div className="flex space-x-2">
          <button
            onClick={() => setClassModalOpen(true)}
            className="px-3 py-1.5 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center space-x-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Add Class</span>
          </button>
          <button
            onClick={() => setSectionModalOpen(true)}
            className="px-3 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white rounded-lg shadow-sm flex items-center space-x-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Add Section</span>
          </button>
        </div>
      </div>

      {/* Classes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {classes.map(cls => {
          const classSections = sections.filter(s => s.classId === cls.id);
          const enrolledCount = students.filter(s => s.classId === cls.id).length;

          return (
            <div
              key={cls.id}
              className="bg-white rounded-xl border border-slate-200 shadow-2xs hover:shadow-md transition-all overflow-hidden flex flex-col justify-between"
            >
              <div className="p-4 space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="font-mono text-[10px] font-bold px-2 py-0.5 bg-blue-100 text-blue-800 rounded">
                      {cls.code}
                    </span>
                    <h3 className="text-base font-bold text-slate-900 mt-1">{cls.name}</h3>
                    <p className="text-xs text-slate-500">{cls.description || 'Standard Curriculum'}</p>
                  </div>
                  <div className="p-2 bg-slate-50 rounded-lg border border-slate-100 text-center shrink-0">
                    <span className="text-[10px] uppercase font-semibold text-slate-400">Total Enrolled</span>
                    <p className="text-base font-black text-slate-800">{enrolledCount}</p>
                  </div>
                </div>

                {/* Sections List in this Class */}
                <div className="space-y-1.5 pt-2 border-t border-slate-100">
                  <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                    Assigned Sections ({classSections.length})
                  </span>
                  <div className="space-y-1">
                    {classSections.map(sec => {
                      const teacher = staff.find(t => t.id === sec.classTeacherId);
                      const secStudents = students.filter(s => s.sectionId === sec.id).length;
                      return (
                        <div
                          key={sec.id}
                          className="p-2 bg-slate-50 rounded-md border border-slate-200 flex items-center justify-between text-xs"
                        >
                          <div>
                            <span className="font-bold text-slate-800">Section {sec.name}</span>
                            <span className="text-[10px] text-slate-500 ml-1.5">({sec.roomNumber})</span>
                            <div className="text-[10px] text-slate-500">
                              Teacher: {teacher?.fullName || 'Unassigned'}
                            </div>
                          </div>
                          <span className="font-mono font-bold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded text-[11px]">
                            {secStudents} / {sec.maxCapacity}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                <span>Capacity: {cls.capacity} seats</span>
                <span className="text-emerald-600 font-semibold">Active</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Class Modal */}
      <ApexModal
        isOpen={classModalOpen}
        onClose={() => setClassModalOpen(false)}
        title="Add Academic Class"
        subtitle="Define new grade cohort in Oracle APEX TBL_CLASSES"
      >
        <form onSubmit={handleSaveClass} className="space-y-3 text-xs">
          <div>
            <label className="block font-semibold mb-1 text-slate-700">Class Name *</label>
            <input
              type="text"
              required
              value={newClass.name}
              onChange={e => setNewClass({ ...newClass, name: e.target.value })}
              placeholder="e.g. Grade 12 (A-Level)"
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Class Code *</label>
              <input
                type="text"
                required
                value={newClass.code}
                onChange={e => setNewClass({ ...newClass, code: e.target.value })}
                placeholder="e.g. GRD-12"
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Target Capacity</label>
              <input
                type="number"
                value={newClass.capacity}
                onChange={e => setNewClass({ ...newClass, capacity: Number(e.target.value) })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>
          <div>
            <label className="block font-semibold mb-1 text-slate-700">Description</label>
            <input
              type="text"
              value={newClass.description}
              onChange={e => setNewClass({ ...newClass, description: e.target.value })}
              placeholder="e.g. Senior Secondary Science Track"
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setClassModalOpen(false)}
              className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-bold bg-blue-600 hover:bg-blue-700 text-white rounded shadow-sm"
            >
              Save Class
            </button>
          </div>
        </form>
      </ApexModal>

      {/* Add Section Modal */}
      <ApexModal
        isOpen={sectionModalOpen}
        onClose={() => setSectionModalOpen(false)}
        title="Add Class Section"
        subtitle="Allot section room and class teacher in Oracle APEX TBL_SECTIONS"
      >
        <form onSubmit={handleSaveSection} className="space-y-3 text-xs">
          <div>
            <label className="block font-semibold mb-1 text-slate-700">Select Parent Class *</label>
            <select
              value={newSection.classId}
              onChange={e => setNewSection({ ...newSection, classId: e.target.value })}
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
            >
              {classes.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Section Name *</label>
              <input
                type="text"
                required
                value={newSection.name}
                onChange={e => setNewSection({ ...newSection, name: e.target.value })}
                placeholder="e.g. A or Gold"
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Room Number</label>
              <input
                type="text"
                value={newSection.roomNumber}
                onChange={e => setNewSection({ ...newSection, roomNumber: e.target.value })}
                placeholder="e.g. Science Lab 2"
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Max Capacity</label>
              <input
                type="number"
                value={newSection.maxCapacity}
                onChange={e => setNewSection({ ...newSection, maxCapacity: Number(e.target.value) })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Class Teacher</label>
              <select
                value={newSection.classTeacherId}
                onChange={e => setNewSection({ ...newSection, classTeacherId: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                {staff.filter(s => s.department === 'ACADEMICS').map(t => (
                  <option key={t.id} value={t.id}>{t.fullName} ({t.designation})</option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setSectionModalOpen(false)}
              className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-bold bg-blue-600 hover:bg-blue-700 text-white rounded shadow-sm"
            >
              Save Section
            </button>
          </div>
        </form>
      </ApexModal>
    </div>
  );
};
