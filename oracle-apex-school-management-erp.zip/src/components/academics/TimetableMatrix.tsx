import React, { useState } from 'react';
import {
  Clock,
  Calendar,
  BookOpen,
  Users,
  MapPin,
  Plus,
  Layers,
  Sparkles
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { ApexCard } from '../common/ApexCard';
import { ApexModal } from '../common/ApexModal';
import { TimetableSlot } from '../../types';

export const TimetableMatrix: React.FC = () => {
  const { classes, sections, subjects, staff, timetable, addTimetableSlot } = useSchool();

  const [selectedClassId, setSelectedClassId] = useState<string>(classes[0]?.id || '');
  const [selectedSectionId, setSelectedSectionId] = useState<string>(sections[0]?.id || '');
  const [modalOpen, setModalOpen] = useState(false);

  const [newSlot, setNewSlot] = useState({
    classId: classes[0]?.id || '',
    sectionId: sections[0]?.id || '',
    subjectId: subjects[0]?.id || '',
    teacherId: staff[0]?.id || '',
    dayOfWeek: 'MONDAY' as any,
    periodNumber: 1,
    startTime: '08:00',
    endTime: '08:45',
    roomNumber: 'Room 101'
  });

  const days: ('MONDAY' | 'TUESDAY' | 'WEDNESDAY' | 'THURSDAY' | 'FRIDAY')[] = [
    'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY'
  ];

  const periods = [1, 2, 3, 4, 5, 6, 7];

  const filteredSlots = timetable.filter(
    t => t.classId === selectedClassId && t.sectionId === selectedSectionId
  );

  const handleSaveSlot = (e: React.FormEvent) => {
    e.preventDefault();
    addTimetableSlot(newSlot);
    setModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <Clock className="w-5 h-5 text-blue-600" />
            <span>Timetable & Schedule Matrix (Page 32)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Dynamic Pivot Grid: Weekly period allocations, instructor assignment, and room conflict avoidance.
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="px-3.5 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center space-x-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>Add Period Slot</span>
        </button>
      </div>

      {/* Class and Section Filter */}
      <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-2xs flex flex-wrap items-center gap-3 text-xs">
        <div className="flex items-center space-x-2">
          <span className="font-semibold text-slate-700">Class:</span>
          <select
            value={selectedClassId}
            onChange={e => {
              const newCId = e.target.value;
              setSelectedClassId(newCId);
              const firstSec = sections.find(s => s.classId === newCId);
              setSelectedSectionId(firstSec?.id || '');
            }}
            className="px-2.5 py-1 bg-slate-50 border border-slate-300 rounded font-medium"
          >
            {classes.map(c => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>

        <div className="flex items-center space-x-2">
          <span className="font-semibold text-slate-700">Section:</span>
          <select
            value={selectedSectionId}
            onChange={e => setSelectedSectionId(e.target.value)}
            className="px-2.5 py-1 bg-slate-50 border border-slate-300 rounded font-medium"
          >
            {sections.filter(s => s.classId === selectedClassId).map(s => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Matrix Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-x-auto custom-scrollbar">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-slate-800 text-white font-bold">
              <th className="p-3 text-left w-28 border-r border-slate-700">Day / Time</th>
              {periods.map(p => (
                <th key={p} className="p-3 text-center border-r border-slate-700 min-w-[140px]">
                  <div className="font-bold">Period {p}</div>
                  <div className="text-[10px] text-slate-300 font-normal">
                    {p === 1 ? '08:00 - 08:45' : p === 2 ? '08:45 - 09:30' : p === 3 ? '09:30 - 10:15' : p === 4 ? '10:30 - 11:15' : p === 5 ? '11:15 - 12:00' : p === 6 ? '12:00 - 12:45' : '13:15 - 14:00'}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {days.map(day => (
              <tr key={day} className="hover:bg-slate-50/50">
                <td className="p-3 font-bold text-slate-900 bg-slate-100 border-r border-slate-200 whitespace-nowrap">
                  {day}
                </td>
                {periods.map(periodNum => {
                  const slot = filteredSlots.find(
                    s => s.dayOfWeek === day && s.periodNumber === periodNum
                  );

                  if (!slot) {
                    return (
                      <td
                        key={periodNum}
                        className="p-2 text-center border-r border-slate-100 text-slate-400 italic bg-slate-50/30"
                      >
                        <span className="text-[10px] opacity-60">Break / Free</span>
                      </td>
                    );
                  }

                  const subject = subjects.find(sb => sb.id === slot.subjectId);
                  const teacher = staff.find(st => st.id === slot.teacherId);

                  return (
                    <td
                      key={periodNum}
                      className="p-2 border-r border-slate-200 bg-blue-50/40 text-left align-top"
                    >
                      <div className="p-2 bg-white rounded border border-blue-200 shadow-2xs space-y-1">
                        <div className="font-bold text-blue-900 leading-tight">
                          {subject?.name || 'Class Subject'}
                        </div>
                        <div className="text-[10px] text-slate-600 flex items-center space-x-1">
                          <Users className="w-2.5 h-2.5 text-slate-400" />
                          <span className="truncate">{teacher?.fullName || 'Faculty'}</span>
                        </div>
                        <div className="text-[10px] text-slate-400 flex items-center space-x-1">
                          <MapPin className="w-2.5 h-2.5 text-slate-400" />
                          <span>{slot.roomNumber || 'Room 101'}</span>
                        </div>
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add Slot Modal */}
      <ApexModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Schedule Period Slot"
        subtitle="Record schedule into Oracle APEX TBL_TIMETABLE"
      >
        <form onSubmit={handleSaveSlot} className="space-y-3 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Day of Week *</label>
              <select
                value={newSlot.dayOfWeek}
                onChange={e => setNewSlot({ ...newSlot, dayOfWeek: e.target.value as any })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                {days.map(d => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Period Number *</label>
              <select
                value={newSlot.periodNumber}
                onChange={e => setNewSlot({ ...newSlot, periodNumber: Number(e.target.value) })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                {periods.map(p => (
                  <option key={p} value={p}>Period {p}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Class *</label>
              <select
                value={newSlot.classId}
                onChange={e => setNewSlot({ ...newSlot, classId: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                {classes.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Section *</label>
              <select
                value={newSlot.sectionId}
                onChange={e => setNewSlot({ ...newSlot, sectionId: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                {sections.map(s => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Subject *</label>
              <select
                value={newSlot.subjectId}
                onChange={e => setNewSlot({ ...newSlot, subjectId: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                {subjects.map(s => (
                  <option key={s.id} value={s.id}>{s.name} ({s.code})</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Teacher *</label>
              <select
                value={newSlot.teacherId}
                onChange={e => setNewSlot({ ...newSlot, teacherId: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                {staff.map(st => (
                  <option key={st.id} value={st.id}>{st.fullName}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700">Assigned Room</label>
            <input
              type="text"
              value={newSlot.roomNumber}
              onChange={e => setNewSlot({ ...newSlot, roomNumber: e.target.value })}
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-bold bg-blue-600 hover:bg-blue-700 text-white rounded shadow-sm"
            >
              Save Timetable Slot
            </button>
          </div>
        </form>
      </ApexModal>
    </div>
  );
};
