import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Plus,
  Calendar,
  BookOpen,
  CheckCircle,
  Clock,
  Send
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { Homework } from '../../types';
import { ApexCard } from '../common/ApexCard';
import { ApexModal } from '../common/ApexModal';

export const HomeworkDiary: React.FC = () => {
  const { homework, classes, sections, subjects, staff, addHomework, currentUser } = useSchool();
  const [modalOpen, setModalOpen] = useState(false);

  const [newHw, setNewHw] = useState({
    classId: classes[0]?.id || '',
    sectionId: sections[0]?.id || '',
    subjectId: subjects[0]?.id || '',
    teacherId: staff[0]?.id || '',
    title: '',
    description: '',
    assignedDate: new Date().toISOString().split('T')[0],
    dueDate: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
    maxPoints: 20
  });

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHw.title.trim() || !newHw.description.trim()) {
      alert("Please enter title and description.");
      return;
    }
    addHomework(newHw);
    setModalOpen(false);
    setNewHw({
      classId: classes[0]?.id || '',
      sectionId: sections[0]?.id || '',
      subjectId: subjects[0]?.id || '',
      teacherId: staff[0]?.id || '',
      title: '',
      description: '',
      assignedDate: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
      maxPoints: 20
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <FileSpreadsheet className="w-5 h-5 text-blue-600" />
            <span>Digital Homework & Daily Diary (Page 90)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Subject assignments, chapter questions, submission due dates, and grading rubrics.
          </p>
        </div>

        {['SUPER_ADMIN', 'SCHOOL_ADMIN', 'PRINCIPAL', 'TEACHER'].includes(currentUser.role) && (
          <button
            onClick={() => setModalOpen(true)}
            className="px-3.5 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center space-x-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Post New Assignment</span>
          </button>
        )}
      </div>

      {/* Homework Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {homework.map(hw => {
          const c = classes.find(cls => cls.id === hw.classId);
          const s = subjects.find(sub => sub.id === hw.subjectId);
          const t = staff.find(st => st.id === hw.teacherId);

          return (
            <div
              key={hw.id}
              className="bg-white rounded-xl border border-slate-200 shadow-2xs hover:shadow-md transition-all overflow-hidden flex flex-col justify-between"
            >
              <div className="p-4 space-y-3">
                <div className="flex items-start justify-between">
                  <span className="font-mono text-[10px] font-bold px-2 py-0.5 bg-blue-100 text-blue-800 rounded">
                    {s?.name || 'Subject'}
                  </span>
                  <span className="font-mono text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                    {hw.maxPoints} Points
                  </span>
                </div>

                <div>
                  <h3 className="text-sm font-bold text-slate-900 leading-snug">{hw.title}</h3>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed line-clamp-3">
                    {hw.description}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-100 space-y-1 text-[11px] text-slate-500">
                  <div className="flex justify-between">
                    <span>Class Cohort:</span>
                    <span className="font-semibold text-slate-700">{c?.name || 'Class'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Teacher:</span>
                    <span className="font-semibold text-slate-700">{t?.fullName || 'Faculty'}</span>
                  </div>
                </div>
              </div>

              <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-[11px]">
                <span className="text-slate-500">Assigned: {hw.assignedDate}</span>
                <span className="font-bold text-rose-600 flex items-center space-x-1">
                  <Clock className="w-3 h-3" />
                  <span>Due: {hw.dueDate}</span>
                </span>
              </div>
            </div>
          );
        })}
      </div>

      <ApexModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Create Digital Assignment"
        subtitle="Post class homework into Oracle APEX TBL_HOMEWORK"
      >
        <form onSubmit={handleSave} className="space-y-3 text-xs">
          <div>
            <label className="block font-semibold mb-1 text-slate-700">Assignment Title *</label>
            <input
              type="text"
              required
              value={newHw.title}
              onChange={e => setNewHw({ ...newHw, title: e.target.value })}
              placeholder="e.g. Calculus Chapter 4 Exercises 1-15"
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Class *</label>
              <select
                value={newHw.classId}
                onChange={e => setNewHw({ ...newHw, classId: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                {classes.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Subject *</label>
              <select
                value={newHw.subjectId}
                onChange={e => setNewHw({ ...newHw, subjectId: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                {subjects.map(s => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Submission Due Date *</label>
              <input
                type="date"
                required
                value={newHw.dueDate}
                onChange={e => setNewHw({ ...newHw, dueDate: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Max Score Points</label>
              <input
                type="number"
                value={newHw.maxPoints}
                onChange={e => setNewHw({ ...newHw, maxPoints: Number(e.target.value) })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700">Assignment Description & Instructions *</label>
            <textarea
              required
              rows={4}
              value={newHw.description}
              onChange={e => setNewHw({ ...newHw, description: e.target.value })}
              placeholder="Detail the problems, page references, and submission rules..."
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-bold bg-blue-600 hover:bg-blue-700 text-white rounded shadow-sm flex items-center space-x-1"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Broadcast Assignment</span>
            </button>
          </div>
        </form>
      </ApexModal>
    </div>
  );
};
