import React, { useState } from 'react';
import {
  CreditCard,
  Plus,
  Calendar,
  Layers,
  Sparkles,
  DollarSign
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { SchoolExpense } from '../../types';
import { InteractiveReport, ColumnDef } from '../common/InteractiveReport';
import { ApexModal } from '../common/ApexModal';

export const ExpenseManager: React.FC = () => {
  const { expenses, addExpense, settings, currentUser } = useSchool();
  const [modalOpen, setModalOpen] = useState(false);

  const [newExp, setNewExp] = useState({
    title: '',
    category: 'UTILITIES' as any,
    amount: 12000,
    expenseDate: new Date().toISOString().split('T')[0],
    paidTo: '',
    paymentMode: 'BANK_TRANSFER' as any,
    description: ''
  });

  const columns: ColumnDef<SchoolExpense>[] = [
    {
      header: "Expense Voucher",
      accessorKey: "voucherNo",
      cell: (e: SchoolExpense) => (
        <span className="font-mono font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded text-[11px]">
          {e.voucherNo}
        </span>
      )
    },
    {
      header: "Title & Purpose",
      accessorKey: "title",
      cell: (e: SchoolExpense) => (
        <div>
          <div className="font-bold text-slate-900">{e.title}</div>
          <div className="text-[11px] text-slate-500">{e.description}</div>
        </div>
      )
    },
    {
      header: "Category",
      accessorKey: "category",
      cell: (e: SchoolExpense) => (
        <span className="font-semibold text-slate-700 bg-blue-50 text-blue-800 px-2 py-0.5 rounded text-[11px]">
          {e.category}
        </span>
      )
    },
    {
      header: "Paid To / Beneficiary",
      accessorKey: "paidTo",
      cell: (e: SchoolExpense) => <span className="font-medium text-slate-800">{e.paidTo}</span>
    },
    {
      header: "Date",
      accessorKey: "expenseDate",
      cell: (e: SchoolExpense) => <span className="text-slate-600">{e.expenseDate}</span>
    },
    {
      header: "Amount",
      accessorKey: "amount",
      align: "right",
      cell: (e: SchoolExpense) => (
        <span className="font-mono font-black text-rose-700 text-sm">
          {settings.currencySymbol}{e.amount.toLocaleString()}
        </span>
      )
    }
  ];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newExp.title.trim() || !newExp.paidTo.trim()) {
      alert("Please provide Title and Paid To.");
      return;
    }
    addExpense({
      title: newExp.title,
      category: newExp.category,
      amount: newExp.amount,
      expenseDate: newExp.expenseDate,
      paidTo: newExp.paidTo,
      paymentMode: newExp.paymentMode,
      description: newExp.description,
      recordedByUserId: currentUser.id
    });
    setModalOpen(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <CreditCard className="w-5 h-5 text-blue-600" />
            <span>School Expenditure & Payments (Page 85)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Accounts Payable: Operating expense vouchers, utilities, transport fuel, and lab purchases.
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="px-3.5 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center space-x-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>Record Expense Voucher</span>
        </button>
      </div>

      <InteractiveReport
        title="Expense Vouchers"
        data={expenses}
        columns={columns}
        searchPlaceholder="Search expense by title, voucher, or beneficiary..."
        searchFilterKeys={['title', 'voucherNo', 'category', 'paidTo']}
      />

      <ApexModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Record Expense Voucher"
        subtitle="Catalog debit voucher in Oracle APEX TBL_EXPENSES"
      >
        <form onSubmit={handleSave} className="space-y-3 text-xs">
          <div>
            <label className="block font-semibold mb-1 text-slate-700">Expense Title *</label>
            <input
              type="text"
              required
              value={newExp.title}
              onChange={e => setNewExp({ ...newExp, title: e.target.value })}
              placeholder="e.g. Science Lab Chemical Reagents"
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Category *</label>
              <select
                value={newExp.category}
                onChange={e => setNewExp({ ...newExp, category: e.target.value as any })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                <option value="UTILITIES">Utilities (Electricity, Water, Gas)</option>
                <option value="MAINTENANCE">Campus Maintenance</option>
                <option value="SUPPLIES">Stationery & Supplies</option>
                <option value="TRANSPORT_FUEL">Transport Fleet Fuel</option>
                <option value="EVENTS">School Events & Sports</option>
                <option value="MISCELLANEOUS">Miscellaneous</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">Amount ({settings.currencySymbol}) *</label>
              <input
                type="number"
                required
                value={newExp.amount}
                onChange={e => setNewExp({ ...newExp, amount: Number(e.target.value) })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 font-bold"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Paid To / Beneficiary *</label>
              <input
                type="text"
                required
                value={newExp.paidTo}
                onChange={e => setNewExp({ ...newExp, paidTo: e.target.value })}
                placeholder="e.g. Metro Power Corp"
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">Expense Date *</label>
              <input
                type="date"
                required
                value={newExp.expenseDate}
                onChange={e => setNewExp({ ...newExp, expenseDate: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700">Description / Ledger Notes</label>
            <input
              type="text"
              value={newExp.description}
              onChange={e => setNewExp({ ...newExp, description: e.target.value })}
              placeholder="e.g. Monthly electricity bill for Science Block"
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-bold bg-blue-600 hover:bg-blue-700 text-white rounded shadow-sm"
            >
              Post Expense Voucher
            </button>
          </div>
        </form>
      </ApexModal>
    </div>
  );
};
