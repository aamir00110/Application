import React, { useState } from 'react';
import {
  DollarSign,
  Plus,
  Printer,
  Calendar,
  Briefcase,
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { StaffPayroll, Staff } from '../../types';
import { InteractiveReport, ColumnDef } from '../common/InteractiveReport';
import { ApexModal } from '../common/ApexModal';

export const PayrollHub: React.FC = () => {
  const { payrolls, staff, generateMonthlyPayroll, updatePayrollStatus, settings } = useSchool();
  const [selectedMonth, setSelectedMonth] = useState('October 2026');
  const [payslipModalOpen, setPayslipModalOpen] = useState(false);
  const [selectedPayroll, setSelectedPayroll] = useState<StaffPayroll | null>(null);

  const columns: ColumnDef<StaffPayroll>[] = [
    {
      header: "Staff Member",
      cell: (p: StaffPayroll) => {
        const s = staff.find(st => st.id === p.staffId);
        return (
          <div>
            <div className="font-bold text-slate-900">{s?.fullName}</div>
            <div className="text-[11px] text-slate-500">{s?.designation} • {s?.department}</div>
          </div>
        );
      }
    },
    {
      header: "Payroll Month",
      accessorKey: "monthOrYear",
      cell: (p: StaffPayroll) => <span className="font-semibold text-slate-800">{p.monthOrYear}</span>
    },
    {
      header: "Basic Salary",
      accessorKey: "basicSalary",
      align: "right",
      cell: (p: StaffPayroll) => (
        <span className="font-mono text-slate-700">{settings.currencySymbol}{p.basicSalary.toLocaleString()}</span>
      )
    },
    {
      header: "Allowances",
      accessorKey: "allowances",
      align: "right",
      cell: (p: StaffPayroll) => (
        <span className="font-mono text-emerald-700">+{settings.currencySymbol}{p.allowances.toLocaleString()}</span>
      )
    },
    {
      header: "Deductions",
      accessorKey: "deductions",
      align: "right",
      cell: (p: StaffPayroll) => (
        <span className="font-mono text-rose-700">-{settings.currencySymbol}{p.deductions.toLocaleString()}</span>
      )
    },
    {
      header: "Net Payable Salary",
      accessorKey: "netSalary",
      align: "right",
      cell: (p: StaffPayroll) => (
        <span className="font-mono font-bold text-slate-900 text-sm">
          {settings.currencySymbol}{p.netSalary.toLocaleString()}
        </span>
      )
    },
    {
      header: "Disbursement Status",
      accessorKey: "status",
      cell: (p: StaffPayroll) => (
        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
          p.status === 'PAID'
            ? 'bg-emerald-100 text-emerald-800'
            : 'bg-amber-100 text-amber-800'
        }`}>
          {p.status}
        </span>
      )
    },
    {
      header: "Action",
      align: "center",
      cell: (p: StaffPayroll) => (
        <div className="flex items-center justify-center space-x-2">
          {p.status === 'GENERATED' && (
            <button
              onClick={() => updatePayrollStatus(p.id, 'PAID')}
              className="px-2 py-0.5 text-[10px] font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded"
            >
              Disburse
            </button>
          )}
          <button
            onClick={() => {
              setSelectedPayroll(p);
              setPayslipModalOpen(true);
            }}
            className="text-xs text-blue-600 hover:underline flex items-center space-x-1"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Payslip</span>
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <DollarSign className="w-5 h-5 text-blue-600" />
            <span>Staff Payroll & Compensation Engine (Page 80)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Batch Payroll: Automated salary slip generation, allowances, tax deductions, and bank transfer vouchers.
          </p>
        </div>

        <button
          onClick={() => {
            generateMonthlyPayroll(selectedMonth);
            alert(`Batch payroll processed for ${selectedMonth}!`);
          }}
          className="px-3.5 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center space-x-1.5"
        >
          <Sparkles className="w-4 h-4" />
          <span>Process Batch Payroll</span>
        </button>
      </div>

      <InteractiveReport
        title="Staff Payroll Register"
        data={payrolls}
        columns={columns}
        searchPlaceholder="Search payroll by month or staff..."
        searchFilterKeys={['monthOrYear', 'status']}
      />

      {/* Payslip Modal */}
      <ApexModal
        isOpen={payslipModalOpen}
        onClose={() => setPayslipModalOpen(false)}
        title="Official Staff Salary Payslip"
        subtitle={`Period: ${selectedPayroll?.monthOrYear}`}
        maxWidth="lg"
        footer={
          <div className="flex space-x-2">
            <button
              onClick={() => window.print()}
              className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded flex items-center space-x-1.5 text-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Salary Slip</span>
            </button>
            <button
              onClick={() => setPayslipModalOpen(false)}
              className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded"
            >
              Close
            </button>
          </div>
        }
      >
        {selectedPayroll && (
          <div className="p-4 bg-white border border-slate-300 rounded-lg space-y-4 text-xs">
            <div className="text-center border-b border-slate-300 pb-3">
              <h3 className="text-base font-black text-slate-900 uppercase">{settings.schoolName}</h3>
              <p className="text-[10px] text-slate-500">Staff Salary Statement — {selectedPayroll.monthOrYear}</p>
            </div>

            <div className="grid grid-cols-2 gap-2 p-2 bg-slate-50 rounded border border-slate-200">
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase">Staff Name</span>
                <p className="font-bold text-slate-900">
                  {staff.find(s => s.id === selectedPayroll.staffId)?.fullName}
                </p>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase">Designation</span>
                <p className="font-medium text-slate-800">
                  {staff.find(s => s.id === selectedPayroll.staffId)?.designation}
                </p>
              </div>
            </div>

            <div className="space-y-1.5 border-t border-slate-200 pt-2">
              <div className="flex justify-between">
                <span>Basic Pay:</span>
                <span className="font-mono font-medium">{settings.currencySymbol}{selectedPayroll.basicSalary}</span>
              </div>
              <div className="flex justify-between text-emerald-700">
                <span>Allowances (Medical & Transport):</span>
                <span className="font-mono font-medium">+{settings.currencySymbol}{selectedPayroll.allowances}</span>
              </div>
              <div className="flex justify-between text-rose-700">
                <span>Deductions (Income Tax & Provident):</span>
                <span className="font-mono font-medium">-{settings.currencySymbol}{selectedPayroll.deductions}</span>
              </div>
              <div className="flex justify-between font-black text-slate-900 text-sm border-t border-slate-300 pt-2">
                <span>Net Disbursed Salary:</span>
                <span className="font-mono text-blue-900">{settings.currencySymbol}{selectedPayroll.netSalary.toLocaleString()}</span>
              </div>
            </div>
          </div>
        )}
      </ApexModal>
    </div>
  );
};
