import React, { useState } from 'react';
import {
  BookMarked,
  Plus,
  Search,
  BookOpen,
  UserCheck,
  CheckCircle,
  RotateCcw,
  Clock
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { LibraryBook, BookIssueRecord } from '../../types';
import { InteractiveReport, ColumnDef } from '../common/InteractiveReport';
import { ApexModal } from '../common/ApexModal';

export const LibraryDesk: React.FC = () => {
  const {
    libraryBooks,
    bookIssues,
    students,
    staff,
    addLibraryBook,
    issueBook,
    returnBook,
    settings
  } = useSchool();

  const [activeTab, setActiveTab] = useState<'CATALOG' | 'CIRCULATION'>('CATALOG');
  const [addBookModalOpen, setAddBookModalOpen] = useState(false);
  const [issueModalOpen, setIssueModalOpen] = useState(false);

  const [newBook, setNewBook] = useState({
    title: '',
    author: '',
    isbn: '',
    category: 'SCIENCE',
    totalCopies: 5,
    availableCopies: 5,
    shelfLocation: 'Shelf A-1'
  });

  const [issueForm, setIssueForm] = useState({
    bookId: libraryBooks[0]?.id || '',
    borrowerType: 'STUDENT' as any,
    borrowerId: students[0]?.id || '',
    issueDate: new Date().toISOString().split('T')[0],
    dueDate: new Date(Date.now() + 86400000 * 14).toISOString().split('T')[0]
  });

  const bookColumns: ColumnDef<LibraryBook>[] = [
    {
      header: "Book Title",
      accessorKey: "title",
      cell: (b: LibraryBook) => (
        <div>
          <div className="font-bold text-slate-900">{b.title}</div>
          <div className="text-[11px] text-slate-500 font-mono">ISBN: {b.isbn}</div>
        </div>
      )
    },
    {
      header: "Author",
      accessorKey: "author",
      cell: (b: LibraryBook) => <span className="font-medium text-slate-700">{b.author}</span>
    },
    {
      header: "Category",
      accessorKey: "category",
      cell: (b: LibraryBook) => (
        <span className="font-semibold text-blue-800 bg-blue-50 px-2 py-0.5 rounded text-[11px]">
          {b.category}
        </span>
      )
    },
    {
      header: "Shelf Location",
      accessorKey: "shelfLocation",
      cell: (b: LibraryBook) => <span className="font-mono text-slate-600">{b.shelfLocation}</span>
    },
    {
      header: "Availability",
      cell: (b: LibraryBook) => (
        <span className={`font-mono font-bold text-xs ${
          b.availableCopies > 0 ? 'text-emerald-700' : 'text-rose-700'
        }`}>
          {b.availableCopies} of {b.totalCopies} Available
        </span>
      )
    }
  ];

  const issueColumns: ColumnDef<BookIssueRecord>[] = [
    {
      header: "Book Title",
      cell: (r: BookIssueRecord) => {
        const b = libraryBooks.find(bk => bk.id === r.bookId);
        return <span className="font-bold text-slate-900">{b?.title || 'Book'}</span>;
      }
    },
    {
      header: "Borrower",
      cell: (r: BookIssueRecord) => {
        const s = students.find(st => st.id === r.borrowerId);
        const stf = staff.find(st => st.id === r.borrowerId);
        return (
          <span className="font-semibold text-slate-800">
            {s?.fullName || stf?.fullName || 'Borrower'} ({r.borrowerType})
          </span>
        );
      }
    },
    {
      header: "Issued Date",
      accessorKey: "issueDate",
      cell: (r: BookIssueRecord) => <span className="font-mono text-slate-600">{r.issueDate}</span>
    },
    {
      header: "Due Date",
      accessorKey: "dueDate",
      cell: (r: BookIssueRecord) => <span className="font-mono font-bold text-slate-800">{r.dueDate}</span>
    },
    {
      header: "Status",
      accessorKey: "status",
      cell: (r: BookIssueRecord) => (
        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
          r.status === 'RETURNED'
            ? 'bg-emerald-100 text-emerald-800'
            : 'bg-amber-100 text-amber-800'
        }`}>
          {r.status}
        </span>
      )
    },
    {
      header: "Action",
      align: "center",
      cell: (r: BookIssueRecord) => {
        if (r.status === 'RETURNED') return <span className="text-slate-400 text-[10px]">Returned</span>;
        return (
          <button
            onClick={() => returnBook(r.id)}
            className="px-2.5 py-1 text-[11px] font-bold bg-blue-600 hover:bg-blue-700 text-white rounded flex items-center space-x-1"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Mark Return</span>
          </button>
        );
      }
    }
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <BookMarked className="w-5 h-5 text-blue-600" />
            <span>Library Circulation Desk & Catalog (Page 100)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Library Module: Catalog accessioning, barcode circulation, due date tracking, and fine management.
          </p>
        </div>

        <div className="flex space-x-2">
          <button
            onClick={() => setAddBookModalOpen(true)}
            className="px-3 py-1.5 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center space-x-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Add Book</span>
          </button>
          <button
            onClick={() => setIssueModalOpen(true)}
            className="px-3 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white rounded-lg shadow-sm flex items-center space-x-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Issue Book</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 space-x-2">
        <button
          onClick={() => setActiveTab('CATALOG')}
          className={`px-3 py-2 text-xs font-bold border-b-2 transition-all ${
            activeTab === 'CATALOG'
              ? 'border-blue-600 text-blue-600 bg-blue-50/50'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          Book Catalog ({libraryBooks.length})
        </button>
        <button
          onClick={() => setActiveTab('CIRCULATION')}
          className={`px-3 py-2 text-xs font-bold border-b-2 transition-all ${
            activeTab === 'CIRCULATION'
              ? 'border-blue-600 text-blue-600 bg-blue-50/50'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          Circulation & Issue Desk ({bookIssues.length})
        </button>
      </div>

      {activeTab === 'CATALOG' ? (
        <InteractiveReport
          title="Library Catalog"
          data={libraryBooks}
          columns={bookColumns}
          searchPlaceholder="Search book title, author, or ISBN..."
          searchFilterKeys={['title', 'author', 'isbn', 'category']}
        />
      ) : (
        <InteractiveReport
          title="Issued Books Ledger"
          data={bookIssues}
          columns={issueColumns}
          searchPlaceholder="Search borrowed books..."
          searchFilterKeys={['status']}
        />
      )}

      {/* Add Book Modal */}
      <ApexModal
        isOpen={addBookModalOpen}
        onClose={() => setAddBookModalOpen(false)}
        title="Add Book to Catalog"
        subtitle="Catalog book title in Oracle APEX TBL_LIBRARY_BOOKS"
      >
        <form
          onSubmit={e => {
            e.preventDefault();
            addLibraryBook({
              ...newBook,
              availableCopies: newBook.totalCopies
            });
            setAddBookModalOpen(false);
          }}
          className="space-y-3 text-xs"
        >
          <div>
            <label className="block font-semibold mb-1 text-slate-700">Book Title *</label>
            <input
              type="text"
              required
              value={newBook.title}
              onChange={e => setNewBook({ ...newBook, title: e.target.value })}
              placeholder="e.g. A Brief History of Time"
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Author *</label>
              <input
                type="text"
                required
                value={newBook.author}
                onChange={e => setNewBook({ ...newBook, author: e.target.value })}
                placeholder="e.g. Stephen Hawking"
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">ISBN Code</label>
              <input
                type="text"
                value={newBook.isbn}
                onChange={e => setNewBook({ ...newBook, isbn: e.target.value })}
                placeholder="978-0553380163"
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Category</label>
              <input
                type="text"
                value={newBook.category}
                onChange={e => setNewBook({ ...newBook, category: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Total Copies</label>
              <input
                type="number"
                value={newBook.totalCopies}
                onChange={e => setNewBook({ ...newBook, totalCopies: Number(e.target.value) })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Shelf Rack</label>
              <input
                type="text"
                value={newBook.shelfLocation}
                onChange={e => setNewBook({ ...newBook, shelfLocation: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setAddBookModalOpen(false)}
              className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-bold bg-blue-600 hover:bg-blue-700 text-white rounded shadow-sm"
            >
              Save Book
            </button>
          </div>
        </form>
      </ApexModal>

      {/* Issue Book Modal */}
      <ApexModal
        isOpen={issueModalOpen}
        onClose={() => setIssueModalOpen(false)}
        title="Issue Book to Borrower"
        subtitle="Record circulation issue in Oracle APEX TBL_BOOK_ISSUES"
      >
        <form
          onSubmit={e => {
            e.preventDefault();
            issueBook(issueForm);
            setIssueModalOpen(false);
          }}
          className="space-y-3 text-xs"
        >
          <div>
            <label className="block font-semibold mb-1 text-slate-700">Select Book *</label>
            <select
              value={issueForm.bookId}
              onChange={e => setIssueForm({ ...issueForm, bookId: e.target.value })}
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
            >
              {libraryBooks.filter(b => b.availableCopies > 0).map(b => (
                <option key={b.id} value={b.id}>{b.title} ({b.availableCopies} available)</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Borrower Type</label>
              <select
                value={issueForm.borrowerType}
                onChange={e => setIssueForm({ ...issueForm, borrowerType: e.target.value as any })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                <option value="STUDENT">Student</option>
                <option value="STAFF">Faculty / Staff</option>
              </select>
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Borrower Name *</label>
              <select
                value={issueForm.borrowerId}
                onChange={e => setIssueForm({ ...issueForm, borrowerId: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                {issueForm.borrowerType === 'STUDENT'
                  ? students.map(s => <option key={s.id} value={s.id}>{s.fullName} ({s.rollNo})</option>)
                  : staff.map(st => <option key={st.id} value={st.id}>{st.fullName}</option>)
                }
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Issue Date *</label>
              <input
                type="date"
                required
                value={issueForm.issueDate}
                onChange={e => setIssueForm({ ...issueForm, issueDate: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Due Return Date *</label>
              <input
                type="date"
                required
                value={issueForm.dueDate}
                onChange={e => setIssueForm({ ...issueForm, dueDate: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setIssueModalOpen(false)}
              className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-bold bg-blue-600 hover:bg-blue-700 text-white rounded shadow-sm"
            >
              Complete Issue
            </button>
          </div>
        </form>
      </ApexModal>
    </div>
  );
};
