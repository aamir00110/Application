import React, { useState } from 'react';
import {
  Bus,
  Plus,
  Phone,
  User,
  MapPin,
  DollarSign
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { TransportRoute } from '../../types';
import { InteractiveReport, ColumnDef } from '../common/InteractiveReport';
import { ApexModal } from '../common/ApexModal';

export const TransportManager: React.FC = () => {
  const { transportRoutes, addTransportRoute, settings } = useSchool();
  const [modalOpen, setModalOpen] = useState(false);

  const [newRoute, setNewRoute] = useState({
    routeName: '',
    vehicleNo: '',
    driverName: '',
    driverPhone: '+1 (555) 888-9900',
    capacity: 40,
    fare: 3500,
    pickupPoints: 'Downtown Central, Westside Mall, Oakridge'
  });

  const columns: ColumnDef<TransportRoute>[] = [
    {
      header: "Route Name",
      accessorKey: "routeName",
      cell: (r: TransportRoute) => (
        <div>
          <div className="font-bold text-slate-900">{r.routeName}</div>
          <div className="text-[11px] text-slate-500 font-mono">Vehicle: {r.vehicleNo}</div>
        </div>
      )
    },
    {
      header: "Driver & Contact",
      accessorKey: "driverName",
      cell: (r: TransportRoute) => (
        <div>
          <div className="font-medium text-slate-900">{r.driverName}</div>
          <div className="text-[11px] text-slate-500 flex items-center space-x-1">
            <Phone className="w-3 h-3 text-slate-400" />
            <span>{r.driverPhone}</span>
          </div>
        </div>
      )
    },
    {
      header: "Bus Capacity",
      accessorKey: "capacity",
      cell: (r: TransportRoute) => <span className="font-mono text-slate-700">{r.capacity} Seats</span>
    },
    {
      header: "Pickup Points",
      accessorKey: "pickupPoints",
      cell: (r: TransportRoute) => <span className="text-slate-600 text-xs">{r.pickupPoints}</span>
    },
    {
      header: "Monthly Fare",
      accessorKey: "fare",
      align: "right",
      cell: (r: TransportRoute) => (
        <span className="font-mono font-bold text-slate-900">
          {settings.currencySymbol}{r.fare.toLocaleString()}
        </span>
      )
    }
  ];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoute.routeName.trim() || !newRoute.vehicleNo.trim()) {
      alert("Please provide Route Name and Vehicle No.");
      return;
    }
    addTransportRoute(newRoute);
    setModalOpen(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <Bus className="w-5 h-5 text-blue-600" />
            <span>Transport & Fleet Logistics (Page 110)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Fleet Registry: Route mapping, GPS tracking links, vehicle capacity, driver contact, and monthly transport fares.
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="px-3.5 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center space-x-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>Add Bus Route</span>
        </button>
      </div>

      <InteractiveReport
        title="Transport Fleet"
        data={transportRoutes}
        columns={columns}
        searchPlaceholder="Search routes by name, driver, or vehicle..."
        searchFilterKeys={['routeName', 'vehicleNo', 'driverName', 'pickupPoints']}
      />

      <ApexModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Create Fleet Transport Route"
        subtitle="Record vehicle route in Oracle APEX TBL_TRANSPORT_ROUTES"
      >
        <form onSubmit={handleSave} className="space-y-3 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Route Name *</label>
              <input
                type="text"
                required
                value={newRoute.routeName}
                onChange={e => setNewRoute({ ...newRoute, routeName: e.target.value })}
                placeholder="e.g. Route 03 - Airport Sector"
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Vehicle Number Plate *</label>
              <input
                type="text"
                required
                value={newRoute.vehicleNo}
                onChange={e => setNewRoute({ ...newRoute, vehicleNo: e.target.value })}
                placeholder="e.g. BUS-8942"
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Driver Name *</label>
              <input
                type="text"
                required
                value={newRoute.driverName}
                onChange={e => setNewRoute({ ...newRoute, driverName: e.target.value })}
                placeholder="e.g. Michael Miller"
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Driver Phone Number *</label>
              <input
                type="tel"
                required
                value={newRoute.driverPhone}
                onChange={e => setNewRoute({ ...newRoute, driverPhone: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Seating Capacity</label>
              <input
                type="number"
                value={newRoute.capacity}
                onChange={e => setNewRoute({ ...newRoute, capacity: Number(e.target.value) })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Monthly Fare ({settings.currencySymbol})</label>
              <input
                type="number"
                value={newRoute.fare}
                onChange={e => setNewRoute({ ...newRoute, fare: Number(e.target.value) })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700">Pickup Stops / Stations</label>
            <input
              type="text"
              value={newRoute.pickupPoints}
              onChange={e => setNewRoute({ ...newRoute, pickupPoints: e.target.value })}
              placeholder="e.g. Green Park, Central Station, North Avenue"
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-bold bg-blue-600 hover:bg-blue-700 text-white rounded shadow-sm"
            >
              Save Bus Route
            </button>
          </div>
        </form>
      </ApexModal>
    </div>
  );
};
