import React, { useState } from 'react';
import {
  Bell,
  Plus,
  Calendar,
  Sparkles,
  Users,
  Send,
  Flag
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { NoticeBoardItem, SchoolEvent } from '../../types';
import { ApexModal } from '../common/ApexModal';

export const NoticesEventsHub: React.FC = () => {
  const { noticeBoard, events, addNotice, addEvent, currentUser } = useSchool();

  const [activeTab, setActiveTab] = useState<'NOTICES' | 'EVENTS'>('NOTICES');
  const [noticeModalOpen, setNoticeModalOpen] = useState(false);
  const [eventModalOpen, setEventModalOpen] = useState(false);

  const [newNotice, setNewNotice] = useState({
    title: '',
    content: '',
    publishDate: new Date().toISOString().split('T')[0],
    targetAudience: 'ALL' as any,
    isUrgent: false
  });

  const [newEvent, setNewEvent] = useState({
    title: '',
    description: '',
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
    venue: 'Main Campus Auditorium',
    audience: 'ALL' as any
  });

  const handleSaveNotice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNotice.title.trim()) return;
    addNotice({
      ...newNotice,
      createdBy: currentUser.fullName
    });
    setNoticeModalOpen(false);
    setNewNotice({
      title: '',
      content: '',
      publishDate: new Date().toISOString().split('T')[0],
      targetAudience: 'ALL',
      isUrgent: false
    });
  };

  const handleSaveEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEvent.title.trim()) return;
    addEvent(newEvent);
    setEventModalOpen(false);
    setNewEvent({
      title: '',
      description: '',
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
      venue: 'Main Campus Auditorium',
      audience: 'ALL'
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <Bell className="w-5 h-5 text-blue-600" />
            <span>Circulars, Notice Board & Academic Calendar (Page 140)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Announcement Board: Broadcast notifications to parents, teachers, and students.
          </p>
        </div>

        {['SUPER_ADMIN', 'SCHOOL_ADMIN', 'PRINCIPAL'].includes(currentUser.role) && (
          <div className="flex space-x-2">
            <button
              onClick={() => setNoticeModalOpen(true)}
              className="px-3.5 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center space-x-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Post Notice</span>
            </button>
            <button
              onClick={() => setEventModalOpen(true)}
              className="px-3.5 py-2 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white rounded-lg shadow-sm flex items-center space-x-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Schedule Event</span>
            </button>
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 space-x-2">
        <button
          onClick={() => setActiveTab('NOTICES')}
          className={`px-3 py-2 text-xs font-bold border-b-2 transition-all ${
            activeTab === 'NOTICES'
              ? 'border-blue-600 text-blue-600 bg-blue-50/50'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          Active Notice Board ({noticeBoard.length})
        </button>
        <button
          onClick={() => setActiveTab('EVENTS')}
          className={`px-3 py-2 text-xs font-bold border-b-2 transition-all ${
            activeTab === 'EVENTS'
              ? 'border-blue-600 text-blue-600 bg-blue-50/50'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          Calendar Events & Holidays ({events.length})
        </button>
      </div>

      {activeTab === 'NOTICES' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {noticeBoard.map(n => (
            <div
              key={n.id}
              className={`p-5 rounded-xl border transition-all ${
                n.isUrgent
                  ? 'bg-rose-50/30 border-rose-200 shadow-xs'
                  : 'bg-white border-slate-200 shadow-2xs hover:shadow-xs'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center space-x-2">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    n.isUrgent ? 'bg-rose-600 text-white' : 'bg-blue-100 text-blue-800'
                  }`}>
                    {n.targetAudience}
                  </span>
                  {n.isUrgent && (
                    <span className="text-rose-600 text-[10px] font-bold uppercase flex items-center space-x-0.5">
                      <Flag className="w-3 h-3" />
                      <span>Urgent Circular</span>
                    </span>
                  )}
                </div>
                <span className="text-[11px] font-mono text-slate-400">{n.publishDate}</span>
              </div>

              <h3 className="text-sm font-bold text-slate-900 mt-2 leading-snug">{n.title}</h3>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed whitespace-pre-line">{n.content}</p>

              <div className="pt-3 mt-3 border-t border-slate-100 text-[11px] text-slate-400 flex justify-between">
                <span>Issued by: <strong>{n.createdBy}</strong></span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {events.map(ev => (
            <div key={ev.id} className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded">
                  {ev.audience}
                </span>
                <span className="text-xs font-mono font-bold text-blue-700">{ev.startDate}</span>
              </div>
              <h3 className="text-sm font-bold text-slate-900">{ev.title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{ev.description}</p>
              <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-500 flex items-center justify-between">
                <span>Venue: <strong>{ev.venue}</strong></span>
                {ev.endDate !== ev.startDate && <span>Until: {ev.endDate}</span>}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Post Notice Modal */}
      <ApexModal
        isOpen={noticeModalOpen}
        onClose={() => setNoticeModalOpen(false)}
        title="Post Notice / Circular"
        subtitle="Broadcast to Oracle APEX TBL_NOTICE_BOARD"
      >
        <form onSubmit={handleSaveNotice} className="space-y-3 text-xs">
          <div>
            <label className="block font-semibold mb-1 text-slate-700">Notice Title *</label>
            <input
              type="text"
              required
              value={newNotice.title}
              onChange={e => setNewNotice({ ...newNotice, title: e.target.value })}
              placeholder="e.g. Science Fair Registration Open"
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Target Audience</label>
              <select
                value={newNotice.targetAudience}
                onChange={e => setNewNotice({ ...newNotice, targetAudience: e.target.value as any })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                <option value="ALL">All School Community</option>
                <option value="STUDENTS">Students Only</option>
                <option value="PARENTS">Parents Only</option>
                <option value="STAFF">Faculty & Staff</option>
              </select>
            </div>
            <div className="flex items-center pt-5">
              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={newNotice.isUrgent}
                  onChange={e => setNewNotice({ ...newNotice, isUrgent: e.target.checked })}
                  className="rounded text-rose-600 focus:ring-rose-500"
                />
                <span className="font-semibold text-rose-700">Mark as High Priority / Urgent</span>
              </label>
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700">Notice Content *</label>
            <textarea
              required
              rows={4}
              value={newNotice.content}
              onChange={e => setNewNotice({ ...newNotice, content: e.target.value })}
              placeholder="Full announcement body and guidelines..."
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setNoticeModalOpen(false)}
              className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-bold bg-blue-600 hover:bg-blue-700 text-white rounded shadow-sm flex items-center space-x-1"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Publish Notice</span>
            </button>
          </div>
        </form>
      </ApexModal>

      {/* Schedule Event Modal */}
      <ApexModal
        isOpen={eventModalOpen}
        onClose={() => setEventModalOpen(false)}
        title="Schedule Calendar Event"
        subtitle="Record milestone in Oracle APEX TBL_EVENTS"
      >
        <form onSubmit={handleSaveEvent} className="space-y-3 text-xs">
          <div>
            <label className="block font-semibold mb-1 text-slate-700">Event Title *</label>
            <input
              type="text"
              required
              value={newEvent.title}
              onChange={e => setNewEvent({ ...newEvent, title: e.target.value })}
              placeholder="e.g. Annual Sports Day Gala"
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Start Date *</label>
              <input
                type="date"
                required
                value={newEvent.startDate}
                onChange={e => setNewEvent({ ...newEvent, startDate: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">End Date</label>
              <input
                type="date"
                value={newEvent.endDate}
                onChange={e => setNewEvent({ ...newEvent, endDate: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700">Venue / Location</label>
            <input
              type="text"
              value={newEvent.venue}
              onChange={e => setNewEvent({ ...newEvent, venue: e.target.value })}
              placeholder="e.g. Athletics Ground"
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700">Event Description</label>
            <textarea
              rows={3}
              value={newEvent.description}
              onChange={e => setNewEvent({ ...newEvent, description: e.target.value })}
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setEventModalOpen(false)}
              className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-bold bg-blue-600 hover:bg-blue-700 text-white rounded shadow-sm"
            >
              Schedule Event
            </button>
          </div>
        </form>
      </ApexModal>
    </div>
  );
};
