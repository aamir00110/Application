import React, { useState } from 'react';
import {
  FileBadge,
  Printer,
  Search,
  School,
  CheckCircle2,
  Award,
  Download
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { ApexCard } from '../common/ApexCard';

export const CertificatesHub: React.FC = () => {
  const { students, classes, parents, settings } = useSchool();

  const [selectedStudentId, setSelectedStudentId] = useState<string>(students[0]?.id || '');
  const [certType, setCertType] = useState<'BONAFIDE' | 'CHARACTER' | 'TRANSFER'>('BONAFIDE');
  const [certificateNo, setCertificateNo] = useState(`CERT-2026-${Date.now().toString().slice(-4)}`);
  const [issueDate, setIssueDate] = useState(new Date().toISOString().split('T')[0]);

  const student = students.find(s => s.id === selectedStudentId);
  const studentClass = classes.find(c => c.id === student?.classId);
  const parent = parents.find(p => p.id === student?.parentId);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Selector & Generator Bar (No print) */}
      <div className="no-print bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs flex-1">
          <div>
            <label className="block font-semibold mb-1 text-slate-700">Certificate Type</label>
            <select
              value={certType}
              onChange={e => setCertType(e.target.value as any)}
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 font-bold bg-white"
            >
              <option value="BONAFIDE">Bonafide Student Certificate</option>
              <option value="CHARACTER">Character & Conduct Certificate</option>
              <option value="TRANSFER">School Leaving / Transfer Certificate (SLC)</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700">Student</label>
            <select
              value={selectedStudentId}
              onChange={e => setSelectedStudentId(e.target.value)}
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 font-medium bg-white"
            >
              {students.map(s => (
                <option key={s.id} value={s.id}>{s.fullName} ({s.admissionNo})</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700">Issue Date</label>
            <input
              type="date"
              value={issueDate}
              onChange={e => setIssueDate(e.target.value)}
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>

        <button
          onClick={handlePrint}
          className="px-4 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center space-x-2 transition-colors shrink-0"
        >
          <Printer className="w-4 h-4" />
          <span>Print Certificate</span>
        </button>
      </div>

      {/* Official Certificate Canvas */}
      {student && (
        <div
          id="certificate-print-area"
          className="bg-white rounded-xl border-4 border-double border-slate-800 shadow-xl p-12 max-w-4xl mx-auto space-y-8 print:shadow-none print:border-4 print:p-8 print:m-0"
        >
          {/* Header */}
          <div className="text-center space-y-2 border-b-2 border-slate-300 pb-6">
            <div className="flex items-center justify-center space-x-3">
              <div className="w-14 h-14 rounded-xl bg-blue-950 text-amber-400 flex items-center justify-center font-black shadow-md">
                <School className="w-9 h-9" />
              </div>
              <div>
                <h1 className="text-3xl font-black tracking-tight text-slate-900 uppercase">
                  {settings.schoolName}
                </h1>
                <p className="text-xs font-semibold text-slate-600 tracking-wider">
                  Accredited by National Board of Secondary & Higher Education
                </p>
                <p className="text-[11px] text-slate-500">
                  {settings.address}, {settings.city} • Phone: {settings.phone}
                </p>
              </div>
            </div>

            <div className="pt-4">
              <span className="inline-block px-6 py-1.5 bg-slate-900 text-amber-300 font-serif font-black text-sm uppercase tracking-widest rounded-full shadow-xs">
                {certType === 'BONAFIDE' && 'Bonafide Student Certificate'}
                {certType === 'CHARACTER' && 'Character & Moral Conduct Certificate'}
                {certType === 'TRANSFER' && 'Official School Leaving / Transfer Certificate'}
              </span>
            </div>

            <div className="flex justify-between text-xs font-mono text-slate-600 pt-2 px-4">
              <span>Ref No: <strong>{certificateNo}</strong></span>
              <span>Date of Issue: <strong>{issueDate}</strong></span>
            </div>
          </div>

          {/* Certificate Body Paragraphs */}
          <div className="text-slate-800 text-base leading-loose font-serif px-6 space-y-6">
            {certType === 'BONAFIDE' && (
              <p className="text-justify">
                This is to officially certify that Master / Miss <strong className="font-sans font-bold underline decoration-blue-500 underline-offset-4">{student.fullName}</strong>,
                son / daughter of Mr. <strong className="font-sans font-bold">{parent?.fatherName || 'Guardian'}</strong>,
                bearing Admission Number <strong className="font-mono font-bold">{student.admissionNo}</strong> and Roll Number <strong className="font-mono font-bold">{student.rollNo}</strong>,
                is a bonafide regular student of this institution currently enrolled in <strong className="font-sans font-bold">{studentClass?.name}</strong> during the academic session <strong>{settings.currentAcademicSession}</strong>.
              </p>
            )}

            {certType === 'CHARACTER' && (
              <p className="text-justify">
                This is to certify that Master / Miss <strong className="font-sans font-bold underline decoration-blue-500 underline-offset-4">{student.fullName}</strong>,
                bearing Admission Number <strong className="font-mono font-bold">{student.admissionNo}</strong>,
                has been a student of <strong className="font-sans font-bold">{studentClass?.name}</strong>. During their academic tenure at {settings.schoolName},
                they have maintained exemplary moral conduct, diligent academic discipline, and active participation in co-curricular pursuits.
                To the best of our knowledge, they bear a <strong>Good Moral Character</strong>.
              </p>
            )}

            {certType === 'TRANSFER' && (
              <div className="space-y-4 text-sm font-sans">
                <p className="font-serif text-base text-justify">
                  This School Leaving Certificate is issued upon formal clearance of all institution dues and return of library resources.
                </p>

                <div className="grid grid-cols-2 gap-3 p-4 bg-slate-50 border border-slate-200 rounded-lg text-xs">
                  <div><strong>Student Name:</strong> {student.fullName}</div>
                  <div><strong>Admission Number:</strong> {student.admissionNo}</div>
                  <div><strong>Date of Admission:</strong> {student.admissionDate}</div>
                  <div><strong>Class at Leaving:</strong> {studentClass?.name}</div>
                  <div><strong>Academic Progress:</strong> Commendable / Promoted</div>
                  <div><strong>Dues Cleared Up To:</strong> Current Academic Month</div>
                  <div><strong>Reason for Leaving:</strong> Parental Relocation / Higher Studies</div>
                  <div><strong>General Conduct:</strong> Very Good</div>
                </div>
              </div>
            )}

            <p className="text-sm italic text-slate-600">
              We wish {student.gender === 'FEMALE' ? 'her' : 'him'} all success and excellence in future academic and career endeavors.
            </p>
          </div>

          {/* Official Signatures & Seal */}
          <div className="pt-16 px-6 grid grid-cols-3 gap-8 text-center text-xs text-slate-800">
            <div className="border-t-2 border-slate-700 pt-2">
              <p className="font-bold">Prepared By / Registrar</p>
              <p className="text-[10px] text-slate-500 font-mono">Academic Registry</p>
            </div>
            <div className="flex flex-col items-center justify-center">
              <div className="w-16 h-16 rounded-full border-2 border-dashed border-slate-400 flex items-center justify-center text-[10px] font-bold text-slate-400 uppercase text-center p-1">
                Official Institutional Seal
              </div>
            </div>
            <div className="border-t-2 border-slate-700 pt-2">
              <p className="font-bold">Principal / Head of School</p>
              <p className="text-[10px] text-slate-500">{settings.schoolName}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
