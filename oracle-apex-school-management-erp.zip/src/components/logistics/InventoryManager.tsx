import React, { useState } from 'react';
import {
  Boxes,
  Plus,
  AlertTriangle,
  Layers,
  Sparkles,
  Package
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { InventoryItem } from '../../types';
import { InteractiveReport, ColumnDef } from '../common/InteractiveReport';
import { ApexModal } from '../common/ApexModal';

export const InventoryManager: React.FC = () => {
  const { inventory, addInventoryItem, updateInventoryStock, settings } = useSchool();
  const [modalOpen, setModalOpen] = useState(false);

  const [newItem, setNewItem] = useState({
    name: '',
    category: 'LAB_EQUIPMENT' as any,
    quantity: 20,
    unit: 'Pieces',
    unitPrice: 450,
    location: 'Lab Room 3',
    reorderLevel: 5
  });

  const columns: ColumnDef<InventoryItem>[] = [
    {
      header: "Item Name",
      accessorKey: "name",
      cell: (i: InventoryItem) => (
        <div>
          <div className="font-bold text-slate-900">{i.name}</div>
          <div className="text-[11px] text-slate-500 font-mono">Location: {i.location}</div>
        </div>
      )
    },
    {
      header: "Category",
      accessorKey: "category",
      cell: (i: InventoryItem) => (
        <span className="font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded text-[11px]">
          {i.category}
        </span>
      )
    },
    {
      header: "Quantity in Stock",
      accessorKey: "quantity",
      cell: (i: InventoryItem) => {
        const isLow = i.quantity <= i.reorderLevel;
        return (
          <div className="flex items-center space-x-2">
            <span className={`font-mono font-bold text-sm ${isLow ? 'text-rose-700' : 'text-slate-900'}`}>
              {i.quantity} {i.unit}
            </span>
            {isLow && (
              <span className="px-1.5 py-0.5 bg-rose-100 text-rose-800 text-[10px] font-bold rounded flex items-center space-x-0.5">
                <AlertTriangle className="w-2.5 h-2.5" />
                <span>Low Stock</span>
              </span>
            )}
          </div>
        );
      }
    },
    {
      header: "Unit Cost",
      accessorKey: "unitPrice",
      align: "right",
      cell: (i: InventoryItem) => (
        <span className="font-mono font-bold text-slate-800">
          {settings.currencySymbol}{i.unitPrice.toLocaleString()}
        </span>
      )
    },
    {
      header: "Stock Adjustments",
      align: "center",
      cell: (i: InventoryItem) => (
        <div className="flex items-center justify-center space-x-1.5">
          <button
            onClick={() => updateInventoryStock(i.id, i.quantity + 5)}
            className="px-2 py-0.5 text-[11px] font-bold bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded border border-emerald-200"
          >
            +5 Stock
          </button>
          <button
            onClick={() => updateInventoryStock(i.id, Math.max(0, i.quantity - 1))}
            className="px-2 py-0.5 text-[11px] font-bold bg-rose-50 text-rose-700 hover:bg-rose-100 rounded border border-rose-200"
          >
            -1 Use
          </button>
        </div>
      )
    }
  ];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItem.name.trim()) {
      alert("Please provide Item Name.");
      return;
    }
    addInventoryItem(newItem);
    setModalOpen(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <Boxes className="w-5 h-5 text-blue-600" />
            <span>Store & Inventory Asset Master (Page 120)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Material Management: Lab supplies, stationery replenishment, reorder threshold alerts, and asset audit.
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="px-3.5 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center space-x-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>New Inventory Item</span>
        </button>
      </div>

      <InteractiveReport
        title="Inventory Store"
        data={inventory}
        columns={columns}
        searchPlaceholder="Search store by item name or category..."
        searchFilterKeys={['name', 'category', 'location']}
      />

      <ApexModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Add Store Inventory Item"
        subtitle="Catalog stock item in Oracle APEX TBL_INVENTORY"
      >
        <form onSubmit={handleSave} className="space-y-3 text-xs">
          <div>
            <label className="block font-semibold mb-1 text-slate-700">Item Name *</label>
            <input
              type="text"
              required
              value={newItem.name}
              onChange={e => setNewItem({ ...newItem, name: e.target.value })}
              placeholder="e.g. A4 Laser Paper Reams"
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Category *</label>
              <select
                value={newItem.category}
                onChange={e => setNewItem({ ...newItem, category: e.target.value as any })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                <option value="STATIONERY">Stationery & Office</option>
                <option value="LAB_EQUIPMENT">Science Lab Equipment</option>
                <option value="SPORTS">Sports & Athletics</option>
                <option value="FURNITURE">Campus Furniture</option>
                <option value="ELECTRONICS">IT & Electronics</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">Storage Location</label>
              <input
                type="text"
                value={newItem.location}
                onChange={e => setNewItem({ ...newItem, location: e.target.value })}
                placeholder="e.g. Storage Room 102"
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Initial Quantity</label>
              <input
                type="number"
                value={newItem.quantity}
                onChange={e => setNewItem({ ...newItem, quantity: Number(e.target.value) })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Unit (e.g. Box, Pc)</label>
              <input
                type="text"
                value={newItem.unit}
                onChange={e => setNewItem({ ...newItem, unit: e.target.value })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Reorder Alert Level</label>
              <input
                type="number"
                value={newItem.reorderLevel}
                onChange={e => setNewItem({ ...newItem, reorderLevel: Number(e.target.value) })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-bold bg-blue-600 hover:bg-blue-700 text-white rounded shadow-sm"
            >
              Save Stock Item
            </button>
          </div>
        </form>
      </ApexModal>
    </div>
  );
};
