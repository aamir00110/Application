import React, { useState } from 'react';
import {
  MessageSquare,
  Plus,
  CheckCircle,
  Clock,
  AlertCircle,
  User
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { Complaint } from '../../types';
import { InteractiveReport, ColumnDef } from '../common/InteractiveReport';
import { ApexModal } from '../common/ApexModal';

export const ComplaintsDesk: React.FC = () => {
  const { complaints, addComplaint, resolveComplaint, students, staff, currentUser } = useSchool();
  const [modalOpen, setModalOpen] = useState(false);

  const [newComplaint, setNewComplaint] = useState({
    complainantType: 'PARENT' as any,
    complainantName: 'Sarah Jenkins',
    title: '',
    description: '',
    category: 'ACADEMIC' as any
  });

  const columns: ColumnDef<Complaint>[] = [
    {
      header: "Grievance Title",
      accessorKey: "title",
      cell: (c: Complaint) => (
        <div>
          <div className="font-bold text-slate-900">{c.title}</div>
          <div className="text-[11px] text-slate-500 line-clamp-1">{c.description}</div>
        </div>
      )
    },
    {
      header: "Complainant",
      accessorKey: "complainantName",
      cell: (c: Complaint) => (
        <div>
          <div className="font-medium text-slate-800">{c.complainantName}</div>
          <div className="text-[10px] text-slate-500 font-mono">{c.complainantType}</div>
        </div>
      )
    },
    {
      header: "Category",
      accessorKey: "category",
      cell: (c: Complaint) => (
        <span className="font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded text-[11px]">
          {c.category}
        </span>
      )
    },
    {
      header: "Date Logged",
      accessorKey: "createdAt",
      cell: (c: Complaint) => <span className="font-mono text-slate-600">{c.createdAt}</span>
    },
    {
      header: "Status",
      accessorKey: "status",
      cell: (c: Complaint) => (
        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
          c.status === 'RESOLVED'
            ? 'bg-emerald-100 text-emerald-800'
            : c.status === 'IN_PROGRESS'
            ? 'bg-blue-100 text-blue-800'
            : 'bg-amber-100 text-amber-800'
        }`}>
          {c.status}
        </span>
      )
    },
    {
      header: "Action",
      align: "center",
      cell: (c: Complaint) => {
        if (c.status === 'RESOLVED') {
          return <span className="text-emerald-700 font-bold text-[10px]">Closed</span>;
        }

        return (
          <button
            onClick={() => resolveComplaint(c.id, "Investigated and resolved by school administration.")}
            className="px-2.5 py-1 text-[11px] font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded flex items-center space-x-1"
          >
            <CheckCircle className="w-3 h-3" />
            <span>Mark Resolved</span>
          </button>
        );
      }
    }
  ];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComplaint.title.trim()) {
      alert("Please provide Title.");
      return;
    }
    addComplaint(newComplaint);
    setModalOpen(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <MessageSquare className="w-5 h-5 text-blue-600" />
            <span>Grievances & Front Desk Help Desk (Page 130)</span>
          </h2>
          <p className="text-xs text-slate-500">
            Oracle APEX Feedback Ticketing: Parent complaints, maintenance work orders, disciplinary logs, and resolution tracking.
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="px-3.5 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center space-x-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>Lodge Grievance</span>
        </button>
      </div>

      <InteractiveReport
        title="Complaints Register"
        data={complaints}
        columns={columns}
        searchPlaceholder="Search complaints..."
        searchFilterKeys={['title', 'complainantName', 'category', 'status']}
      />

      <ApexModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Lodge New Grievance / Feedback Ticket"
        subtitle="Log issue in Oracle APEX TBL_COMPLAINTS"
      >
        <form onSubmit={handleSave} className="space-y-3 text-xs">
          <div>
            <label className="block font-semibold mb-1 text-slate-700">Subject / Title *</label>
            <input
              type="text"
              required
              value={newComplaint.title}
              onChange={e => setNewComplaint({ ...newComplaint, title: e.target.value })}
              placeholder="e.g. Bus Route 03 delay in morning pickup"
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-slate-700">Complainant Category</label>
              <select
                value={newComplaint.complainantType}
                onChange={e => setNewComplaint({ ...newComplaint, complainantType: e.target.value as any })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                <option value="PARENT">Parent / Guardian</option>
                <option value="STUDENT">Student</option>
                <option value="STAFF">Faculty / Staff</option>
                <option value="COMMUNITY">Community / Visitor</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-slate-700">Category *</label>
              <select
                value={newComplaint.category}
                onChange={e => setNewComplaint({ ...newComplaint, category: e.target.value as any })}
                className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500 bg-white"
              >
                <option value="ACADEMIC">Academic / Curriculum</option>
                <option value="TRANSPORT">Transport Logistics</option>
                <option value="FACILITY">Campus Facilities & Cleanliness</option>
                <option value="DISCIPLINE">Discipline / Behavioral</option>
                <option value="FINANCE">Fee / Billing Dispute</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700">Complainant Name *</label>
            <input
              type="text"
              required
              value={newComplaint.complainantName}
              onChange={e => setNewComplaint({ ...newComplaint, complainantName: e.target.value })}
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block font-semibold mb-1 text-slate-700">Detailed Description *</label>
            <textarea
              required
              rows={3}
              value={newComplaint.description}
              onChange={e => setNewComplaint({ ...newComplaint, description: e.target.value })}
              className="w-full px-3 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-bold bg-blue-600 hover:bg-blue-700 text-white rounded shadow-sm"
            >
              Lodge Grievance
            </button>
          </div>
        </form>
      </ApexModal>
    </div>
  );
};
