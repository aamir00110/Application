export type UserRole = 
  | 'SUPER_ADMIN'
  | 'SCHOOL_ADMIN'
  | 'PRINCIPAL'
  | 'TEACHER'
  | 'ACCOUNTANT'
  | 'RECEPTIONIST'
  | 'STUDENT'
  | 'PARENT';

export interface UserAccount {
  id: string;
  username: string;
  fullName: string;
  email: string;
  role: UserRole;
  avatarUrl?: string;
  phone?: string;
  linkedEntityId?: string; // studentId, teacherId, parentId
  isActive: boolean;
  lastLogin?: string;
  createdDate: string;
}

export interface SchoolSettings {
  schoolName: string;
  schoolCode: string;
  tagline: string;
  logoUrl: string;
  address: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
  phone: string;
  email: string;
  website: string;
  currentAcademicSession: string; // e.g. "2026-2027"
  currencySymbol: string; // e.g. "$" or "Rs" or "€"
  currencyCode: string; // e.g. "USD"
  gradingScheme: 'GPA_4_0' | 'PERCENTAGE' | 'LETTER_GRADE' | 'CAMBRIDGE';
  receiptPrefix: string; // e.g. "REC-2026-"
  admissionPrefix: string; // e.g. "ADM-2026-"
  attendanceThresholdPercent: number; // e.g. 75
}

export interface AcademicSession {
  id: string;
  name: string; // e.g. "2026-2027"
  startDate: string;
  endDate: string;
  isCurrent: boolean;
  status: 'UPCOMING' | 'ACTIVE' | 'ARCHIVED';
}

export interface SchoolClass {
  id: string;
  name: string; // e.g. "Grade 10"
  numericLevel: number; // 10
  description?: string;
  capacity: number;
}

export interface Section {
  id: string;
  classId: string;
  name: string; // e.g. "A", "B", "Rose"
  classTeacherId?: string;
  roomNumber?: string;
  capacity: number;
}

export interface Subject {
  id: string;
  code: string; // e.g. "MTH-10"
  name: string; // e.g. "Mathematics"
  classId: string;
  type: 'CORE' | 'ELECTIVE' | 'PRACTICAL';
  credits: number;
  totalMarks: number;
  passMarks: number;
}

export interface ClassSubjectTeacher {
  id: string;
  classId: string;
  sectionId: string;
  subjectId: string;
  teacherId: string;
  periodsPerWeek: number;
}

export interface TimetableSlot {
  id: string;
  classId: string;
  sectionId: string;
  dayOfWeek: 'MONDAY' | 'TUESDAY' | 'WEDNESDAY' | 'THURSDAY' | 'FRIDAY' | 'SATURDAY';
  periodNumber: number;
  startTime: string; // e.g. "08:30"
  endTime: string; // e.g. "09:15"
  subjectId: string;
  teacherId: string;
  roomNumber: string;
}

export interface Parent {
  id: string;
  fatherName: string;
  motherName: string;
  fatherOccupation: string;
  motherOccupation?: string;
  primaryPhone: string;
  secondaryPhone?: string;
  email: string;
  cnicBForm: string;
  address: string;
  emergencyContact: string;
  emergencyPhone: string;
}

export interface Student {
  id: string;
  admissionNo: string;
  rollNo: string;
  firstName: string;
  lastName: string;
  fullName: string;
  gender: 'MALE' | 'FEMALE' | 'OTHER';
  dateOfBirth: string;
  cnicBForm: string;
  bloodGroup: string;
  religion: string;
  admissionDate: string;
  classId: string;
  sectionId: string;
  academicSessionId: string;
  parentId: string;
  email?: string;
  phone?: string;
  address: string;
  city: string;
  previousSchool?: string;
  medicalConditions?: string;
  avatarUrl?: string;
  transportRequired: boolean;
  transportRouteId?: string;
  status: 'ACTIVE' | 'GRADUATED' | 'TRANSFERRED' | 'SUSPENDED';
  createdDate: string;
}

export interface TeacherStaff {
  id: string;
  employeeCode: string;
  employeeNo?: string;
  firstName: string;
  lastName: string;
  fullName: string;
  gender: 'MALE' | 'FEMALE' | 'OTHER';
  designation: string; // e.g. "Senior Science Teacher", "Headmistress", "Accountant"
  department: 'ACADEMICS' | 'ADMINISTRATION' | 'ACCOUNTS' | 'SPORTS' | 'SUPPORT';
  qualification: string;
  experienceYears?: number;
  dateOfJoining: string;
  dateOfBirth?: string;
  phone: string;
  email: string;
  address?: string;
  cnic?: string;
  basicSalary: number;
  avatarUrl?: string;
  status: 'ACTIVE' | 'ON_LEAVE' | 'RESIGNED' | 'TERMINATED' | string;
}

export type AttendanceStatus = 'PRESENT' | 'ABSENT' | 'LATE' | 'HALF_DAY' | 'EXCUSED' | 'ON_LEAVE';

export interface StudentAttendanceRecord {
  id: string;
  studentId: string;
  classId?: string;
  sectionId?: string;
  date: string; // YYYY-MM-DD
  status: AttendanceStatus;
  remarks?: string;
  recordedBy?: string;
}

export interface StaffAttendanceRecord {
  id: string;
  staffId: string;
  date: string; // YYYY-MM-DD
  status: AttendanceStatus;
  checkInTime?: string;
  checkOutTime?: string;
  remarks?: string;
}

export interface LeaveApplication {
  id: string;
  applicantType?: 'STUDENT' | 'STAFF' | string;
  applicantId?: string;
  staffId?: string;
  leaveType: 'SICK' | 'CASUAL' | 'EMERGENCY' | 'MATERNITY' | 'OTHER' | string;
  startDate: string;
  endDate: string;
  reason: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | string;
  appliedDate?: string;
  reviewedBy?: string;
  reviewRemarks?: string;
}

export interface ExamType {
  id: string;
  name: string; // e.g. "First Term Examination 2026", "Final Term 2026", "Monthly Test - Oct"
  academicSessionId: string;
  startDate: string;
  endDate: string;
  weightagePercent: number;
  status: 'UPCOMING' | 'ONGOING' | 'COMPLETED' | 'RESULTS_PUBLISHED';
}

export interface ExamSchedule {
  id: string;
  examTypeId: string;
  classId: string;
  subjectId: string;
  examDate: string;
  startTime: string;
  endTime: string;
  maxMarks: number;
  passMarks: number;
  roomNumber: string;
}

export interface StudentExamMark {
  id: string;
  examTypeId: string;
  studentId: string;
  classId: string;
  subjectId: string;
  marksObtained: number;
  maxMarks: number;
  passMarks: number;
  grade: string;
  gpa: number;
  isAbsent: boolean;
  remarks?: string;
}

export interface GradingScale {
  id: string;
  grade: string; // e.g. "A+", "A", "B", "C", "D", "F"
  minPercent: number;
  maxPercent: number;
  gpaPoint: number;
  description: string;
}

export interface FeeCategory {
  id: string;
  name: string; // e.g. "Tuition Fee", "Admission Fee", "Exam Fee", "Transport Fee", "Laboratory Fee"
  frequency: 'MONTHLY' | 'TERM_WISE' | 'ANNUAL' | 'ONE_TIME';
  description?: string;
}

export interface ClassFeeStructure {
  id: string;
  classId: string;
  feeCategoryId?: string;
  feeHead?: string;
  frequency?: string;
  amount: number;
  academicSessionId?: string;
}

export interface StudentFeeInvoice {
  id: string;
  invoiceNo: string; // e.g. "INV-2026-0012"
  studentId: string;
  classId: string;
  academicSessionId?: string;
  monthOrTerm: string; // e.g. "August 2026" or "Term 1"
  dueDate: string;
  issueDate?: string;
  totalAmount?: number;
  grossAmount?: number;
  discountAmount: number;
  fineAmount: number;
  netPayable: number;
  paidAmount: number;
  balanceAmount: number;
  status: 'PAID' | 'PARTIALLY_PAID' | 'UNPAID' | 'OVERDUE' | string;
  items?: {
    feeCategoryId?: string;
    categoryName?: string;
    feeHead?: string;
    amount: number;
  }[];
}

export interface FeePaymentReceipt {
  id: string;
  receiptNo: string; // e.g. "REC-2026-0045"
  invoiceId: string;
  studentId?: string;
  paymentDate: string;
  amountPaid: number;
  paymentMethod?: 'CASH' | 'ONLINE_TRANSFER' | 'CHEQUE' | 'CREDIT_CARD' | 'BANK_CHALLAN' | string;
  paymentMode?: string;
  referenceNo?: string;
  collectedBy: string;
  remarks?: string;
}

export interface SalaryPayment {
  id: string;
  voucherNo: string;
  staffId: string;
  monthYear?: string; // "August 2026"
  monthOrYear?: string;
  basicSalary: number;
  allowances: number;
  deductions: number;
  netSalary: number;
  paymentDate: string;
  paymentMethod?: 'BANK_TRANSFER' | 'CHEQUE' | 'CASH' | string;
  status: 'PAID' | 'PENDING' | 'GENERATED' | string;
  remarks?: string;
}

export interface ExpenseRecord {
  id: string;
  voucherNo: string;
  title: string;
  category: 'UTILITIES' | 'MAINTENANCE' | 'STATIONERY' | 'EVENTS' | 'SALARIES' | 'TRANSPORT' | 'LAB_EQUIPMENT' | 'MISCELLANEOUS';
  amount: number;
  expenseDate: string;
  paidTo: string;
  paymentMethod: 'CASH' | 'BANK_TRANSFER' | 'CHEQUE';
  approvedBy: string;
  description?: string;
}

export interface HomeworkAssignment {
  id: string;
  title: string;
  classId: string;
  sectionId: string;
  subjectId: string;
  teacherId: string;
  assignedDate: string;
  dueDate: string;
  description: string;
  attachments?: string[];
  maxPoints?: number;
}

export interface NoticeAnnouncement {
  id: string;
  title: string;
  content: string;
  targetAudience: 'ALL' | 'STUDENTS' | 'PARENTS' | 'TEACHERS' | 'STAFF';
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
  publishDate: string;
  expiryDate?: string;
  authorName: string;
  isPinned: boolean;
}

export interface SchoolEvent {
  id: string;
  title: string;
  category: 'ACADEMIC' | 'SPORTS' | 'CULTURAL' | 'EXAM' | 'HOLIDAY' | 'PARENT_MEET';
  startDate: string;
  endDate: string;
  location: string;
  description: string;
  targetAudience: string;
}

export interface LibraryBook {
  id: string;
  isbn: string;
  title: string;
  author: string;
  publisher: string;
  category: 'SCIENCE' | 'MATHEMATICS' | 'LITERATURE' | 'HISTORY' | 'COMPUTER' | 'ENCYCLOPEDIA' | 'GENERAL' | string;
  totalCopies: number;
  availableCopies: number;
  rackLocation?: string;
  shelfLocation?: string;
  price?: number;
}

export interface BookIssueReturn {
  id: string;
  bookId: string;
  borrowerType: 'STUDENT' | 'TEACHER';
  borrowerId: string;
  issueDate: string;
  dueDate: string;
  returnDate?: string;
  fineAmount: number;
  status: 'ISSUED' | 'RETURNED' | 'OVERDUE';
}

export interface TransportVehicle {
  id: string;
  vehicleNo: string; // e.g. "BUS-04"
  registrationNo: string;
  capacity: number;
  driverName: string;
  driverPhone: string;
  driverLicenseNo: string;
  status: 'ACTIVE' | 'MAINTENANCE';
}

export interface TransportRoute {
  id: string;
  routeName: string;
  startPoint?: string;
  endPoint?: string;
  stops?: string[];
  vehicleId?: string;
  vehicleNo?: string;
  driverName?: string;
  driverPhone?: string;
  capacity?: number;
  pickupPoints?: string;
  fare?: number;
  monthlyFee?: number;
  status?: string;
}

export interface InventoryItem {
  id: string;
  itemCode?: string;
  itemName?: string;
  name?: string;
  category: 'FURNITURE' | 'LAB_EQUIPMENT' | 'IT_HARDWARE' | 'SPORTS_GEAR' | 'STATIONERY' | string;
  quantity: number;
  unit: string;
  locationRoom?: string;
  location?: string;
  condition?: 'NEW' | 'GOOD' | 'NEEDS_REPAIR' | 'DAMAGED' | string;
  purchaseDate?: string;
  unitPrice?: number;
  reorderLevel?: number;
}

export interface ComplaintRecord {
  id: string;
  complainantType: 'STUDENT' | 'PARENT' | 'TEACHER' | 'STAFF' | 'COMMUNITY' | string;
  complainantName: string;
  complainantPhone?: string;
  title: string;
  description: string;
  category: 'ACADEMIC' | 'FACILITY' | 'TRANSPORT' | 'DISCIPLINE' | 'FEE' | 'FINANCE' | 'OTHER' | string;
  priority?: 'LOW' | 'MEDIUM' | 'HIGH' | string;
  status: 'PENDING' | 'INVESTIGATING' | 'IN_PROGRESS' | 'RESOLVED' | 'DISMISSED' | string;
  submittedDate?: string;
  createdAt?: string;
  resolutionRemarks?: string;
  resolvedDate?: string;
}

export interface StudentCertificate {
  id: string;
  certificateNo: string;
  studentId: string;
  type: 'BONAFIDE' | 'CHARACTER' | 'TRANSFER' | 'SPORTS_ACHIEVEMENT' | 'MERIT';
  issueDate: string;
  purpose: string;
  signedBy: string;
  remarks?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userName: string;
  userRole?: UserRole;
  action: string;
  module?: string;
  description?: string;
  entity?: string;
  details?: string;
  ipAddress?: string;
}

export type NavigationPage = 
  | 'dashboard'
  | 'students-list'
  | 'students-admission'
  | 'students-promotion'
  | 'parents-list'
  | 'academics-classes'
  | 'academics-subjects'
  | 'academics-timetable'
  | 'academics-homework'
  | 'staff-list'
  | 'staff-leaves'
  | 'attendance-student'
  | 'attendance-staff'
  | 'exams-setup'
  | 'exams-marks'
  | 'exams-report-cards'
  | 'fees-structure'
  | 'fees-collection'
  | 'fees-outstanding'
  | 'payroll-salary'
  | 'payroll-expenses'
  | 'logistics-library'
  | 'logistics-transport'
  | 'logistics-inventory'
  | 'logistics-complaints'
  | 'logistics-certificates'
  | 'logistics-notices'
  | 'admin-users'
  | 'admin-settings'
  | 'admin-audit-logs'
  | 'admin-sql-scripts';

// Type Aliases for component convenience
export type User = UserAccount;
export type AcademicClass = SchoolClass;
export type Homework = HomeworkAssignment;
export type FeeInvoice = StudentFeeInvoice;
export type FeeReceipt = FeePaymentReceipt;
export type FeeStructure = ClassFeeStructure;
export type Complaint = ComplaintRecord;
export type NoticeBoardItem = NoticeAnnouncement;
export type SchoolExpense = ExpenseRecord;
export type StaffPayroll = SalaryPayment;
export type Staff = TeacherStaff;
export type StaffLeave = LeaveApplication;
export type BookIssueRecord = BookIssueReturn;
